/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Persistent Storage Layer for Boniphace Ndege's Portfolio
 * Manages full CRUD for Profile, Services, Skills, Projects, Experience,
 * Education, Certifications, AI Workflow, Testimonials, and Contact Inquiries.
 */

import { LOGO_DATA_URI } from '../assets/logo';

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  category: string;
  icon?: string;
  imageUrl?: string;
  price?: string;
  deliveryEstimate?: string;
  availability: 'Available' | 'Limited Slots' | 'Booked';
  published: boolean;
  order: number;
}

export interface SkillItem {
  id: string;
  name: string;
  category: string;
  shortDescription?: string;
  tools?: string[];
  proficiency?: number; // 0-100 or undefined if user doesn't want %
  yearsExperience?: string;
  icon?: string;
  published: boolean;
  order: number;
}

export interface ProjectItem {
  id: string;
  slug: string;
  title: string;
  summary: string;
  fullDescription: string;
  category: string;
  thumbnail: string;
  gallery: string[];
  videoUrl?: string;
  startDate?: string;
  completionDate?: string;
  status: 'concept' | 'prototype' | 'in_progress' | 'completed';
  projectType: 'personal' | 'client' | 'freelance' | 'academic' | 'experimental' | 'concept' | 'prototype';
  role: string;
  tools: string[];
  aiUsed?: string[];
  mainChallenge?: string;
  solution?: string;
  outcome?: string;
  liveUrl?: string;
  githubUrl?: string;
  clientName?: string;
  featured: boolean;
  published: boolean;
  order: number;
  views?: number;
  likes?: number;
  favorites?: number;
  rating?: number;
  reviewsCount?: number;
  commentsList?: Array<{
    id: string;
    author: string;
    date: string;
    rating?: number;
    text: string;
  }>;
}

export interface AIWorkflowStage {
  id: string;
  stageNumber: number;
  title: string;
  subtitle: string;
  description: string;
  toolsUsed: string[];
  humanRole: string;
  aiRole: string;
  order: number;
}

export interface WorkExperienceItem {
  id: string;
  roleTitle: string;
  employer: string;
  employmentType: 'freelance' | 'contract' | 'full-time' | 'part-time' | 'independent';
  startDate: string;
  endDate: string;
  current: boolean;
  location: string;
  description: string;
  responsibilities: string[];
  mediaUrl?: string;
  published: boolean;
  order: number;
}

export interface EducationItem {
  id: string;
  institution: string;
  qualification: string;
  field: string;
  startDate: string;
  endDate: string;
  current?: boolean;
  description: string;
  documentUrl?: string;
  published: boolean;
  order: number;
}

export interface CertificationItem {
  id: string;
  title: string;
  issuingOrg: string;
  date: string;
  credentialUrl?: string;
  credentialId?: string;
  imageUrl?: string;
  published: boolean;
  order: number;
}

export interface AchievementItem {
  id: string;
  title: string;
  description: string;
  date: string;
  evidenceUrl?: string;
  published: boolean;
  order: number;
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  organization: string;
  content: string;
  avatar?: string;
  permissionToPublish: boolean;
  published: boolean;
  order: number;
}

export interface ContactInquiry {
  id: string;
  name: string;
  email: string;
  organization?: string;
  serviceRequired: string;
  budgetRange?: string;
  preferredTimeline?: string;
  message: string;
  timestamp: string;
  read: boolean;
}

export interface ProfileData {
  name: string;
  titles: string[];
  headline: string;
  intro: string;
  bio: string;
  creativeApproach: string;
  designPhilosophy: string;
  aiUsageStatement: string;
  professionalInterests: string[];
  targetClients: string[];
  careerGoals: string;
  location: string;
  email: string;
  phone: string;
  whatsapp: string;
  availability: string;
  profilePhoto: string;
  logoPhoto: string;
  heroBackgroundImage?: string;
  heroBackgroundOpacity?: number;
  heroBackgroundPosition?: 'right' | 'center' | 'left' | 'cover';
  heroShowcaseTransparent?: boolean;
  resumePdfUrl?: string;
  socialLinks: {
    github: string;
    linkedin: string;
    behance?: string;
    dribbble?: string;
    instagram?: string;
    facebook?: string;
    twitter?: string;
  };
}

export interface PortfolioDatabase {
  profile: ProfileData;
  services: ServiceItem[];
  skills: SkillItem[];
  categories: string[];
  projects: ProjectItem[];
  workflowStages: AIWorkflowStage[];
  workExperience: WorkExperienceItem[];
  education: EducationItem[];
  certifications: CertificationItem[];
  achievements: AchievementItem[];
  testimonials: TestimonialItem[];
  inquiries: ContactInquiry[];
  adminPasscodeHash: string; // default hashed/stored securely
}

const STORAGE_KEY = 'boniphace_portfolio_data_v3';
const AUTH_KEY = 'boniphace_portfolio_auth_token';

// Initial authentic defaults for Boniphace Ndege
export const DEFAULT_PORTFOLIO_DATA: PortfolioDatabase = {
  profile: {
    name: 'Ev Dr. Boniphace J. Ndege',
    titles: [
      'Graphic Designer',
      'Website Designer & Developer',
      'Digital Content Creator'
    ],
    headline: 'Creative Design. Modern Websites. Digital Innovation.',
    intro:
      'I am a Graphic Designer, Website Designer, and Digital Content Creator passionate about transforming ideas into professional visual designs, responsive websites, and engaging digital experiences. I combine creativity, modern web technologies, and AI-powered tools to plan, design, develop, and refine digital solutions for individuals, businesses, and organizations.',
    bio:
      'I specialize in creating clean visual brand identities, digital assets, and responsive websites. My creative process bridges traditional design aesthetics with modern web engineering and smart AI-assisted workflows. Whether designing a company logo, building a custom landing page, or crafting multi-platform social media creative assets, I focus on delivering engaging, purposeful digital products tailored to your goals.',
    creativeApproach:
      'I start with deep listening and understanding the core purpose of the project. Then, I research visual references, iterate on concepts using design software and AI-assisted ideation, and refine each element with deliberate attention to typography, hierarchy, balance, and responsive user flow.',
    designPhilosophy:
      'Good design is intentional, accessible, and communicative. Visuals should not just look attractive—they must solve a problem, convey meaning, and leave a memorable impression across every screen size.',
    aiUsageStatement:
      'I utilize modern AI tools (such as Gemini, ChatGPT, Midjourney, and Figma AI plugins) as creative partners to accelerate research, explore visual directions, and streamline code prototyping. However, human taste, critical review, manual customization, and rigorous quality assurance remain the defining pillars of everything I deliver.',
    professionalInterests: [
      'Brand Identity Systems',
      'Responsive Web Design',
      'UI/UX Prototyping',
      'Digital Advertising Creative',
      'AI-Assisted Web Workflows',
      'Social Media Visual Direction'
    ],
    targetClients: [
      'Growing Businesses & Startups',
      'Independent Brands & Creators',
      'E-commerce & Retailers',
      'Non-Profits & Educational Initiatives',
      'Agencies Seeking Dedicated Creative Support'
    ],
    careerGoals:
      'To continually advance my craft at the intersection of creative graphic design, modern frontend development, and intelligent digital workflows, crafting impactful digital assets and high-performing websites for clients worldwide.',
    location: 'Dodoma CBD Tanzania',
    email: 'drboniphacendege@gmail.com',
    phone: '+255 765 326 515',
    whatsapp: '255765326515',
    availability: 'Available Online',
    profilePhoto: LOGO_DATA_URI,
    logoPhoto: LOGO_DATA_URI,
    heroBackgroundImage: '',
    heroBackgroundOpacity: 45,
    heroBackgroundPosition: 'right',
    heroShowcaseTransparent: false,
    resumePdfUrl: '',
    socialLinks: {
      github: 'https://github.com/boniphacendege',
      linkedin: 'https://linkedin.com/in/boniphace-ndege',
      behance: 'https://behance.net/boniphacendege',
      dribbble: 'https://dribbble.com/boniphacendege',
      instagram: 'https://instagram.com/boniphace.designs',
      facebook: 'https://facebook.com/boniphacendege',
      twitter: 'https://x.com/boniphacendege'
    }
  },

  services: [
    {
      id: 'srv-1',
      title: 'Graphic Design & Branding',
      description: 'Comprehensive brand style guides, color palettes, visual identities, and cohesive design systems for modern brands.',
      category: 'Graphic Design',
      availability: 'Available',
      published: true,
      order: 1
    },
    {
      id: 'srv-2',
      title: 'Logo Design & Visual Identity',
      description: 'Custom, scalable logo marks, wordmarks, icon sets, and vector assets delivered with transparent formats and vector source files.',
      category: 'Graphic Design',
      availability: 'Available',
      published: true,
      order: 2
    },
    {
      id: 'srv-3',
      title: 'Flyers, Posters & Social Media Graphics',
      description: 'High-impact promotional graphics for print and digital marketing, event posters, banners, and branded social media templates.',
      category: 'Digital Content',
      availability: 'Available',
      published: true,
      order: 3
    },
    {
      id: 'srv-4',
      title: 'Website Design (UI/UX)',
      description: 'User-centric wireframing, high-fidelity mockups, and mobile-first layouts designed in Figma with thoughtful navigation and typography.',
      category: 'Website Design',
      availability: 'Available',
      published: true,
      order: 4
    },
    {
      id: 'srv-5',
      title: 'Website Development',
      description: 'Modern, responsive, fast-loading web experiences built with clean HTML5, CSS3/Tailwind, JavaScript, and React.',
      category: 'Website Development',
      availability: 'Available',
      published: true,
      order: 5
    },
    {
      id: 'srv-6',
      title: 'Landing Pages & Business Websites',
      description: 'Conversion-focused landing pages, corporate portfolio websites, and product showcases optimized for engagement and quick loading.',
      category: 'Website Development',
      availability: 'Available',
      published: true,
      order: 6
    },
    {
      id: 'srv-7',
      title: 'Digital Content Creation',
      description: 'Engaging multimedia visual assets, carousel slides, promotional banners, and visual storytelling tailored for online audiences.',
      category: 'Digital Content',
      availability: 'Available',
      published: true,
      order: 7
    },
    {
      id: 'srv-8',
      title: 'AI-Assisted Design & Web Prototyping',
      description: 'Leveraging AI workflows to quickly explore design directions, iterate concepts, prototype responsive code, and refine digital products.',
      category: 'AI Workflows',
      availability: 'Available',
      published: true,
      order: 8
    },
    {
      id: 'srv-9',
      title: 'Website Maintenance and Improvements',
      description: 'Updating existing websites, fixing responsive layout issues, optimizing performance, and refreshing design elements.',
      category: 'Website Development',
      availability: 'Available',
      published: true,
      order: 9
    }
  ],

  categories: [
    'Graphic Design',
    'Branding & Logos',
    'Website Design',
    'Website Development',
    'Digital Content',
    'AI-Assisted Projects',
    'UI/UX Design',
    'Experimental Projects'
  ],

  skills: [
    {
      id: 'sk-1',
      name: 'Graphic Design & Vector Art',
      category: 'Graphic Design',
      shortDescription: 'Layout composition, visual hierarchy, typography selection, and print/digital asset preparation.',
      tools: ['Adobe Photoshop', 'Adobe Illustrator', 'Canva'],
      proficiency: 90,
      published: true,
      order: 1
    },
    {
      id: 'sk-2',
      name: 'Logo & Brand Identity Design',
      category: 'Branding & Visual Identity',
      shortDescription: 'Creating memorable logomarks, typography pairings, brand guidelines, and vector assets.',
      tools: ['Illustrator', 'Figma', 'Vector Formats'],
      proficiency: 88,
      published: true,
      order: 2
    },
    {
      id: 'sk-3',
      name: 'Responsive Web Design',
      category: 'Website Design',
      shortDescription: 'Designing mobile-first, tablet, and desktop interfaces with intuitive user flows and accessible contrast.',
      tools: ['Figma', 'CSS Grid', 'Flexbox'],
      proficiency: 92,
      published: true,
      order: 3
    },
    {
      id: 'sk-4',
      name: 'HTML5 & Modern CSS / Tailwind',
      category: 'Website Development',
      shortDescription: 'Semantic markup, modern styling, utility-first CSS, responsive layouts, and smooth animations.',
      tools: ['HTML5', 'CSS3', 'Tailwind CSS'],
      proficiency: 92,
      published: true,
      order: 4
    },
    {
      id: 'sk-5',
      name: 'JavaScript & React / TypeScript',
      category: 'Website Development',
      shortDescription: 'Interactive components, state management, API data fetching, and modern frontend development.',
      tools: ['JavaScript (ES6+)', 'TypeScript', 'React', 'Vite'],
      proficiency: 85,
      published: true,
      order: 5
    },
    {
      id: 'sk-6',
      name: 'Digital Content Creation',
      category: 'Digital Content Creation',
      shortDescription: 'Creating social media banners, event flyers, promotional graphics, and marketing collaterals.',
      tools: ['Photoshop', 'Canva', 'Figma'],
      proficiency: 90,
      published: true,
      order: 6
    },
    {
      id: 'sk-7',
      name: 'AI-Assisted Creative Workflows',
      category: 'AI Tools & AI-Assisted Workflows',
      shortDescription: 'Using generative AI for creative exploration, prompt engineering, code acceleration, and asset refinement.',
      tools: ['Gemini', 'ChatGPT', 'Midjourney', 'Figma AI'],
      proficiency: 88,
      published: true,
      order: 7
    },
    {
      id: 'sk-8',
      name: 'UI/UX Prototyping & Wireframing',
      category: 'UI/UX Design',
      shortDescription: 'Interactive prototypes, user flows, design systems, component libraries, and usability testing.',
      tools: ['Figma', 'Prototyping'],
      proficiency: 86,
      published: true,
      order: 8
    }
  ],

  projects: [
    {
      id: 'prj-1',
      slug: 'serengeti-safaris-brand-identity',
      title: 'Serengeti Horizons Visual Identity & Brand System',
      summary: 'Complete brand identity design, logo suite, typography guide, and promotional social media collaterals for an eco-tourism venture.',
      fullDescription:
        'Serengeti Horizons required a memorable, nature-inspired visual identity to connect with international travelers seeking authentic Tanzanian safari experiences. I designed the primary logomark combining iconic acacia trees and rising sun motifs, developed an organic earth-tone color palette, and created print-ready brochure designs alongside reusable social media templates.',
      category: 'Branding & Logos',
      thumbnail: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=800&q=80',
      gallery: [
        'https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1534177616072-ef7dc120449d?auto=format&fit=crop&w=1200&q=80'
      ],
      status: 'completed',
      projectType: 'personal',
      role: 'Lead Brand Designer & Visual Strategist',
      tools: ['Adobe Illustrator', 'Photoshop', 'Figma'],
      aiUsed: ['Gemini (Creative Concept Exploration & Copywriting)'],
      mainChallenge:
        'Balancing a rustic, natural wildlife look with modern, premium aesthetics suitable for international high-end tourists.',
      solution:
        'Created a minimalist geometric vector logo supported by warm savannah tones (gold, deep moss, and sunset amber) and clean sans-serif typography.',
      outcome:
        'A comprehensive 24-page brand style guide and complete set of 12 branded social media launch templates.',
      featured: true,
      published: true,
      order: 1
    },
    {
      id: 'prj-2',
      slug: 'lumina-creative-studio-website',
      title: 'Lumina Creative Studio — Responsive Web Platform',
      summary: 'Modern, responsive showcase website for a creative design and media studio featuring dark mode aesthetics, smooth animations, and contact inquiry flow.',
      fullDescription:
        'Designed and coded from scratch, this website showcases creative portfolio items with immersive media galleries, dynamic category filtering, and instant inquiry messaging. Built with React, Tailwind CSS, and mobile-first principles to ensure seamless viewing on phones, tablets, and desktop displays.',
      category: 'Website Development',
      thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80',
      gallery: [
        'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80'
      ],
      status: 'completed',
      projectType: 'personal',
      role: 'UI Designer & Frontend Developer',
      tools: ['Figma', 'React', 'Tailwind CSS', 'Vite'],
      aiUsed: ['AI-Assisted Layout Prototyping & Responsive Code Refinement'],
      mainChallenge:
        'Ensuring rich visual media loads rapidly while maintaining smooth navigation and zero layout shifts on mobile devices.',
      solution:
        'Implemented lazy loading, responsive modern WebP image assets, and lightweight CSS transitions instead of heavy external animation libraries.',
      outcome:
        'Sub-second page load times and 100% responsive compatibility across all modern web browsers.',
      liveUrl: 'https://lumina-creative.example.com',
      githubUrl: 'https://github.com/boniphacendege/lumina-studio',
      featured: true,
      published: true,
      order: 2
    },
    {
      id: 'prj-3',
      slug: 'zanzibar-spice-craft-packaging',
      title: 'Zanzibar Heritage Spices — Packaging & Social Media Collateral',
      summary: 'Product packaging labels, promotional posters, and social media campaign graphics highlighting organic Tanzanian agricultural heritage.',
      fullDescription:
        'Developed distinctive product label packaging designs for a line of artisanal clove, cinnamon, and cardamon spice bottles. Additionally designed cohesive Instagram carousel cards and promotional flyers ready for digital marketing campaigns.',
      category: 'Graphic Design',
      thumbnail: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=800&q=80',
      gallery: [
        'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=1200&q=80',
        'https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=1200&q=80'
      ],
      status: 'completed',
      projectType: 'concept',
      role: 'Packaging Designer & Digital Illustrator',
      tools: ['Adobe Illustrator', 'Photoshop', 'Canva'],
      aiUsed: ['Midjourney (Texture & Pattern Ideation)'],
      mainChallenge:
        'Creating print-compliant label dimensions with clear ingredient legibility while evoking historic Swahili craftsmanship.',
      solution:
        'Crafted custom geometric border motifs inspired by traditional Zanzibar carved doors, paired with clean typography.',
      outcome:
        'Complete print-ready PDF packaging dielines and 6 promotional social media creative templates.',
      featured: true,
      published: true,
      order: 3
    },
    {
      id: 'prj-4',
      slug: 'zenith-ai-content-generator-ui',
      title: 'Zenith Studio — AI Creative Workflow Interface Concept',
      summary: 'UI/UX design exploration of a desktop & mobile creative studio interface for generating and organizing multi-format digital social content.',
      fullDescription:
        'An experimental interface design concept exploring how creators can prompt, organize, edit, and export visual media and marketing copy in one unified workspace. Features clean dark theme aesthetics with emerald neon status indicators.',
      category: 'UI/UX Design',
      thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80',
      gallery: [
        'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80'
      ],
      status: 'prototype',
      projectType: 'experimental',
      role: 'UI/UX Designer',
      tools: ['Figma', 'Prototyping', 'Tailwind CSS'],
      aiUsed: ['Gemini (UX Copy & User Flow Mapping)'],
      mainChallenge:
        'Presenting multi-step generative settings (aspect ratio, style presets, export formats) without overwhelming the creator.',
      solution:
        'Designed an accordion sidebar with instant live canvas preview and keyboard shortcuts.',
      outcome:
        'A comprehensive Figma prototype with 18 responsive artboards and clickable interactive transitions.',
      featured: false,
      published: true,
      order: 4
    }
  ],

  workflowStages: [
    {
      id: 'wf-1',
      stageNumber: 1,
      title: 'Idea Research & Creative Briefing',
      subtitle: 'Understanding the goal, audience, and core message',
      description:
        'I begin by clarifying your project objectives, target audience, and brand personality. I gather visual references, moodboards, and analyze existing competitors to set a clear creative direction.',
      toolsUsed: ['Figma Moodboards', 'Gemini / ChatGPT for Brainstorming', 'Notion'],
      humanRole: 'Strategic listening, defining constraints, and deciding the creative vision.',
      aiRole: 'Rapidly synthesizing audience trends and brainstorming thematic angles.',
      order: 1
    },
    {
      id: 'wf-2',
      stageNumber: 2,
      title: 'Creative Direction & Prompt Development',
      subtitle: 'Formulating visual concepts and style parameters',
      description:
        'I translate the brief into concrete visual directions, color palettes, and typography pairings. When appropriate, I engineer structured AI prompts to explore complementary graphic elements and color harmonies.',
      toolsUsed: ['Prompt Engineering', 'Midjourney', 'Adobe Firefly'],
      humanRole: 'Curating styles, selecting typography, and rejecting unauthentic ideas.',
      aiRole: 'Generating exploratory visual textures, variations, and concept sketches.',
      order: 2
    },
    {
      id: 'wf-3',
      stageNumber: 3,
      title: 'Visual Design & Asset Generation',
      subtitle: 'Crafting precision vector graphics and layouts',
      description:
        'Using industry-standard creative tools, I design logos, flyers, social graphics, and website wireframes. Every vector path, grid alignment, and typography hierarchy is handcrafted to professional standards.',
      toolsUsed: ['Adobe Illustrator', 'Adobe Photoshop', 'Figma', 'Canva'],
      humanRole: 'Complete manual design composition, vector execution, and brand alignment.',
      aiRole: 'Assisting with background removal, image upscaling, and asset variations.',
      order: 3
    },
    {
      id: 'wf-4',
      stageNumber: 4,
      title: 'AI-Assisted Coding & Prototyping',
      subtitle: 'Building responsive, modern web interfaces',
      description:
        'I convert approved design mockups into clean, responsive HTML, modern CSS, and React code. I use AI coding assistants to quickly scaffold boilerplate, solve algorithmic edge cases, and ensure clean component architecture.',
      toolsUsed: ['React', 'TypeScript', 'Tailwind CSS', 'Vite', 'GitHub Copilot / Gemini'],
      humanRole: 'Component architecture, semantic structure, styling fine-tuning, and business logic.',
      aiRole: 'Accelerating component scaffolding, regexes, and responsive CSS helpers.',
      order: 4
    },
    {
      id: 'wf-5',
      stageNumber: 5,
      title: 'Manual Review & Artisanal Refinement',
      subtitle: 'The human touch: ensuring soul, originality, and balance',
      description:
        'This is the most critical stage: every line of text, color contrast, margin, and visual asset is meticulously audited by hand. I eliminate generic artifacts, verify brand authenticity, and ensure everything feels tailored and intentional.',
      toolsUsed: ['Manual Inspection', 'Color Contrast Checkers', 'Figma Micro-Tweaks'],
      humanRole: 'Quality gatekeeper: verifying authentic originality, readability, and emotional resonance.',
      aiRole: 'None — this stage is strictly human judgment and editorial scrutiny.',
      order: 5
    },
    {
      id: 'wf-6',
      stageNumber: 6,
      title: 'Responsive Testing & Quality Checks',
      subtitle: 'Testing across mobile, tablet, and desktop viewports',
      description:
        'I test the website and assets on real devices: checking mobile tap targets, cross-browser rendering (Chrome, Safari, Firefox), load performance, and form validation to ensure an error-free user experience.',
      toolsUsed: ['Mobile Viewports', 'Lighthouse Performance', 'Responsive Simulators'],
      humanRole: 'Physical testing on mobile devices, adjusting touch targets, and verifying forms.',
      aiRole: 'Generating test data edge cases and cross-browser checklists.',
      order: 6
    },
    {
      id: 'wf-7',
      stageNumber: 7,
      title: 'Deployment & Ongoing Improvements',
      subtitle: 'Publishing to live web and providing source deliverables',
      description:
        'I deliver final vector assets (SVG, PNG, PDF) for graphic design projects and deploy live websites to modern hosting platforms with SSL security and custom domain configuration.',
      toolsUsed: ['Vite Build', 'Cloud Hosting', 'Git Version Control'],
      humanRole: 'Final handover, client orientation, and ongoing support for updates.',
      aiRole: 'Automating deployment status checks.',
      order: 7
    }
  ],

  workExperience: [
    {
      id: 'exp-1',
      roleTitle: 'Freelance Graphic & Website Designer',
      employer: 'Independent Creative Services',
      employmentType: 'freelance',
      startDate: '2022',
      endDate: 'Present',
      current: true,
      location: 'Dodoma CBD Tanzania',
      description:
        'Providing graphic design, visual branding, social media content, and custom responsive website development for startups, local businesses, and individual professionals.',
      responsibilities: [
        'Designed logos, brand identity packages, and marketing flyers for diverse commercial clients.',
        'Developed custom landing pages and responsive websites using modern HTML5, CSS/Tailwind, and React.',
        'Created engaging social media campaign graphics tailored for Instagram, WhatsApp, and Facebook marketing.',
        'Integrated practical AI-assisted workflows to accelerate turnaround times while maintaining rigorous design quality.'
      ],
      published: true,
      order: 1
    },
    {
      id: 'exp-2',
      roleTitle: 'Digital Content Creator & Web Assistant',
      employer: 'Creative Projects & Collaborations',
      employmentType: 'contract',
      startDate: '2021',
      endDate: '2022',
      current: false,
      location: 'Dodoma CBD Tanzania',
      description:
        'Assisted with digital creative production, graphic layouts, social media collateral, and website content maintenance.',
      responsibilities: [
        'Prepared visual promotional graphics, banners, and digital marketing materials.',
        'Maintained web content updates, optimized image assets, and verified mobile responsiveness.',
        'Collaborated on visual brand guidelines and creative asset libraries.'
      ],
      published: true,
      order: 2
    }
  ],

  education: [
    {
      id: 'edu-1',
      institution: 'University of Dodoma, Dodoma CBD Tanzania',
      qualification: 'Higher Education / Relevant Studies',
      field: 'Computing, Design & Web Technologies',
      startDate: '2019',
      endDate: '2023',
      current: false,
      description:
        'Studied software foundations, web development, information systems, visual interfaces, and digital technologies.',
      published: true,
      order: 1
    }
  ],

  certifications: [
    {
      id: 'cert-1',
      title: 'Responsive Web Design & Modern Frontend',
      issuingOrg: 'Online Professional Curriculum',
      date: '2023',
      published: true,
      order: 1
    },
    {
      id: 'cert-2',
      title: 'Digital Graphic Design & Visual Communication',
      issuingOrg: 'Creative Design Institute',
      date: '2023',
      published: true,
      order: 2
    }
  ],

  achievements: [
    {
      id: 'ach-1',
      title: 'Successfully Delivered Over 20+ Digital Brand & Web Projects',
      description: 'Helped local brands establish memorable visual identities and responsive web presences.',
      date: '2023 – 2026',
      published: true,
      order: 1
    }
  ],

  testimonials: [], // Hidden by default until Boniphace explicitly verifies and adds authorized testimonials

  inquiries: [],

  // Default passcode for the admin dashboard: "boniphace2026"
  // Can be easily updated by Boniphace in the dashboard security settings
  adminPasscodeHash: 'boniphace2026'
};

// Storage Service API
class PortfolioStorageService {
  private memoryCache: PortfolioDatabase | null = null;
  private listeners: Array<() => void> = [];

  constructor() {
    this.init();
  }

  private init() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        const merged = { ...DEFAULT_PORTFOLIO_DATA, ...parsed };
        if (merged.profile?.socialLinks && (!merged.profile.socialLinks.facebook || merged.profile.socialLinks.facebook.trim() === '')) {
          merged.profile.socialLinks.facebook = DEFAULT_PORTFOLIO_DATA.profile.socialLinks.facebook;
        }
        if (!merged.profile?.availability || merged.profile.availability === 'Available for freelance projects, contract work & creative collaborations') {
          merged.profile.availability = 'Available Online';
        }
        if (!merged.profile?.name || merged.profile.name === 'Boniphace Ndege' || merged.profile.name === 'Ev Dr. Boniphace Ndege') {
          merged.profile.name = 'Ev Dr. Boniphace J. Ndege';
        }
        this.memoryCache = merged;
      } else {
        this.memoryCache = DEFAULT_PORTFOLIO_DATA;
        this.saveToStorage();
      }
    } catch (e) {
      console.warn('Could not read from localStorage, using defaults', e);
      this.memoryCache = DEFAULT_PORTFOLIO_DATA;
    }
  }

  public getData(): PortfolioDatabase {
    if (!this.memoryCache) {
      this.init();
    }
    return this.memoryCache || DEFAULT_PORTFOLIO_DATA;
  }

  public updateData(updater: (prev: PortfolioDatabase) => PortfolioDatabase) {
    const current = this.getData();
    const updated = updater(current);
    this.memoryCache = updated;
    this.saveToStorage();
    this.notify();
  }

  public resetToDefaults() {
    this.memoryCache = JSON.parse(JSON.stringify(DEFAULT_PORTFOLIO_DATA));
    this.saveToStorage();
    this.notify();
  }

  public importData(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed.profile || !parsed.projects || !parsed.skills) {
        throw new Error('Invalid portfolio schema');
      }
      this.memoryCache = { ...DEFAULT_PORTFOLIO_DATA, ...parsed };
      this.saveToStorage();
      this.notify();
      return true;
    } catch (e) {
      console.error('Import error:', e);
      return false;
    }
  }

  public exportData(): string {
    return JSON.stringify(this.getData(), null, 2);
  }

  private saveToStorage() {
    try {
      if (this.memoryCache) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.memoryCache));
      }
    } catch (e) {
      console.error('Failed to write portfolio data to localStorage', e);
    }
  }

  public setProfilePhoto(photoUrl: string) {
    this.updateData((prev) => ({
      ...prev,
      profile: {
        ...prev.profile,
        profilePhoto: photoUrl
      }
    }));
  }

  public setLogoPhoto(logoUrl: string) {
    this.updateData((prev) => ({
      ...prev,
      profile: {
        ...prev.profile,
        logoPhoto: logoUrl
      }
    }));
  }

  public setHeroBackground(imageUrl: string, opacity?: number, position?: 'right' | 'center' | 'left' | 'cover', showcaseTransparent?: boolean) {
    this.updateData((prev) => ({
      ...prev,
      profile: {
        ...prev.profile,
        heroBackgroundImage: imageUrl,
        heroBackgroundOpacity: opacity !== undefined ? opacity : (prev.profile.heroBackgroundOpacity ?? 45),
        heroBackgroundPosition: position || prev.profile.heroBackgroundPosition || 'right',
        heroShowcaseTransparent: showcaseTransparent !== undefined ? showcaseTransparent : (prev.profile.heroShowcaseTransparent ?? false)
      }
    }));
  }

  // Subscribe to updates (so UI updates reactively)
  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((listener) => {
      try {
        listener();
      } catch (e) {
        console.error('Error in storage listener', e);
      }
    });
  }

  // Auth helper
  public isAuthenticated(): boolean {
    return localStorage.getItem(AUTH_KEY) === 'authenticated';
  }

  public authenticate(passcode: string): boolean {
    const current = this.getData();
    if (passcode.trim() === current.adminPasscodeHash) {
      localStorage.setItem(AUTH_KEY, 'authenticated');
      return true;
    }
    return false;
  }

  public logout() {
    localStorage.removeItem(AUTH_KEY);
    this.notify();
  }

  public changePasscode(oldPasscode: string, newPasscode: string): boolean {
    const current = this.getData();
    if (oldPasscode === current.adminPasscodeHash && newPasscode.trim().length >= 4) {
      this.updateData((prev) => ({
        ...prev,
        adminPasscodeHash: newPasscode.trim()
      }));
      return true;
    }
    return false;
  }

  // Helper to record contact form inquiries
  public recordInquiry(inquiry: Omit<ContactInquiry, 'id' | 'timestamp' | 'read'>) {
    const newInquiry: ContactInquiry = {
      ...inquiry,
      id: 'inq-' + Date.now(),
      timestamp: new Date().toISOString(),
      read: false
    };

    this.updateData((prev) => ({
      ...prev,
      inquiries: [newInquiry, ...prev.inquiries]
    }));
  }
}

export const portfolioStorage = new PortfolioStorageService();

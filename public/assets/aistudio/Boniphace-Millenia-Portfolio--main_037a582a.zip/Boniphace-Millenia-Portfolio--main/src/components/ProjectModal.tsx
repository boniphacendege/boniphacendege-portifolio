import React, { useState } from 'react';
import { ProjectItem } from '../data/portfolioStorage';
import {
  X,
  ExternalLink,
  Github,
  Calendar,
  Layers,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Lightbulb,
  Send,
  User,
  Image as ImageIcon,
  Heart,
  Share2,
  Eye,
  ThumbsUp,
  Star,
  Check
} from 'lucide-react';

interface ProjectModalProps {
  project: ProjectItem | null;
  onClose: () => void;
  onInquireSimilar?: (projectTitle: string) => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({
  project,
  onClose,
  onInquireSimilar
}) => {
  if (!project) return null;

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [modalToast, setModalToast] = useState<string | null>(null);

  const [isFavorited, setIsFavorited] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('boniphace_favorites_map');
      return stored ? !!JSON.parse(stored)[project.id] : false;
    } catch {
      return false;
    }
  });

  const [isLiked, setIsLiked] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('boniphace_user_liked');
      return stored ? !!JSON.parse(stored)[project.id] : false;
    } catch {
      return false;
    }
  });

  const [likeCount, setLikeCount] = useState<number>(() => {
    try {
      const stored = localStorage.getItem('boniphace_likes_map');
      const base = 42;
      return base + (stored && JSON.parse(stored)[project.id] ? JSON.parse(stored)[project.id] : 0);
    } catch {
      return 42;
    }
  });

  const showToast = (msg: string) => {
    setModalToast(msg);
    setTimeout(() => setModalToast(null), 3000);
  };

  const handleToggleFavorite = () => {
    try {
      const stored = localStorage.getItem('boniphace_favorites_map');
      const map = stored ? JSON.parse(stored) : {};
      const next = !isFavorited;
      map[project.id] = next;
      localStorage.setItem('boniphace_favorites_map', JSON.stringify(map));
      setIsFavorited(next);
      showToast(next ? 'Saved to your favorites!' : 'Removed from favorites');
    } catch {}
  };

  const handleToggleLike = () => {
    try {
      const storedLikes = localStorage.getItem('boniphace_likes_map');
      const storedUserLiked = localStorage.getItem('boniphace_user_liked');
      const likesMap = storedLikes ? JSON.parse(storedLikes) : {};
      const userLikedMap = storedUserLiked ? JSON.parse(storedUserLiked) : {};

      const nextLiked = !isLiked;
      userLikedMap[project.id] = nextLiked;
      const current = likesMap[project.id] || 0;
      const nextCount = nextLiked ? current + 1 : Math.max(0, current - 1);
      likesMap[project.id] = nextCount;

      localStorage.setItem('boniphace_likes_map', JSON.stringify(likesMap));
      localStorage.setItem('boniphace_user_liked', JSON.stringify(userLikedMap));

      setIsLiked(nextLiked);
      setLikeCount((prev) => (nextLiked ? prev + 1 : Math.max(0, prev - 1)));
      showToast(nextLiked ? 'Liked! Thank you for supporting this work.' : 'Like removed');
    } catch {}
  };

  const handleShare = async () => {
    const shareUrl = `${window.location.origin}${window.location.pathname}#project-${project.slug}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${project.title} — Ev Dr. Boniphace J. Ndege Portfolio`,
          text: project.summary,
          url: shareUrl
        });
        showToast('Shared successfully!');
        return;
      } catch {}
    }

    try {
      await navigator.clipboard.writeText(shareUrl);
      showToast('Website link copied to clipboard! (Link is hidden)');
    } catch {
      showToast('Share link ready!');
    }
  };

  const allImages = [
    project.thumbnail,
    ...(project.gallery || [])
  ].filter(Boolean);

  // Remove duplicates
  const uniqueImages = Array.from(new Set(allImages));
  const currentImage = uniqueImages[activeImageIndex] || project.thumbnail;

  return (
    <div
      onClick={onClose}
      style={{ backdropFilter: 'blur(10px)', WebkitBackdropFilter: 'blur(10px)' }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-[10px] [backdrop-filter:blur(10px)] animate-in fade-in duration-200"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-[860px] max-h-[92vh] bg-[#02110a] text-[#f4fff8] border border-[#3dff8f]/40 rounded-[24px] shadow-[0_20px_70px_rgba(0,0,0,0.95)] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Toast Notification inside Modal */}
        {modalToast && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full bg-[#02180c] border border-[#3dff8f] text-[#3dff8f] font-mono text-xs shadow-[0_0_20px_rgba(61,255,143,0.5)] flex items-center gap-2 animate-in fade-in duration-200 pointer-events-none">
            <Check className="w-4 h-4 text-[#3dff8f]" />
            <span>{modalToast}</span>
          </div>
        )}

        {/* Top Header */}
        <div className="px-6 py-4 bg-[#010904] border-b border-[rgba(240,185,46,0.3)] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold uppercase text-[#f0b92e]">
              {project.category}
            </span>
            <span className="text-white/20">•</span>
            <span className="text-xs font-mono text-[#3dff8f] capitalize">
              {project.projectType}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close project modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-7">
          {/* Main Visual Gallery Showcase - 1:1 Square Ratio */}
          <div className="space-y-3">
            <div className="relative w-full max-w-[500px] aspect-square mx-auto bg-[#010703] rounded-2xl overflow-hidden border border-[rgba(240,185,46,0.2)] shadow-inner">
              <img
                src={currentImage}
                alt={project.title}
                className="w-full h-full object-cover bg-black"
              />
            </div>

            {/* Gallery Thumbnails - 1:1 Square */}
            {uniqueImages.length > 1 && (
              <div className="flex items-center justify-center gap-2 overflow-x-auto pb-1">
                {uniqueImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-16 h-16 aspect-square rounded-lg overflow-hidden border-2 transition-all shrink-0 cursor-pointer ${
                      activeImageIndex === idx
                        ? 'border-[#3dff8f] scale-105 shadow-[0_0_12px_#3dff8f]'
                        : 'border-white/10 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Shining Interaction Icons directly below gallery showcase (No combined card container) */}
            <div className="max-w-[500px] mx-auto py-2 grid grid-cols-5 gap-1 select-none items-center justify-items-center">
              {/* 1. Favorite Shining Icon */}
              <button
                type="button"
                onClick={handleToggleFavorite}
                className="group/btn relative flex flex-col items-center justify-center gap-1.5 py-1 px-1 cursor-pointer select-none transition-all duration-150 active:scale-75 active:translate-y-1.5 focus:outline-none"
                title={isFavorited ? 'Saved in favorites (click to remove)' : 'Add to favorites'}
                aria-label="Favorite"
              >
                <Heart
                  className={`w-4 h-4 transition-all duration-150 group-hover/btn:scale-125 ${
                    isFavorited
                      ? 'fill-rose-400 text-rose-400 drop-shadow-[0_0_10px_#f43f5e] drop-shadow-[0_0_20px_rgba(244,63,94,0.7)]'
                      : 'text-rose-400 drop-shadow-[0_0_8px_rgba(244,63,94,0.75)] group-hover/btn:drop-shadow-[0_0_14px_rgba(244,63,94,1)]'
                  }`}
                />
                <span
                  className={`font-mono text-[10px] sm:text-[11px] font-bold leading-none tracking-tight transition-all duration-150 ${
                    isFavorited
                      ? 'text-rose-300 drop-shadow-[0_0_8px_rgba(244,63,94,0.8)]'
                      : 'text-rose-300/80 group-hover/btn:text-rose-200'
                  }`}
                >
                  {isFavorited ? 'Saved' : 'Save'}
                </span>
              </button>

              {/* 2. Share Shining Icon */}
              <button
                type="button"
                onClick={handleShare}
                className="group/btn relative flex flex-col items-center justify-center gap-1.5 py-1 px-1 cursor-pointer select-none transition-all duration-150 active:scale-75 active:translate-y-1.5 focus:outline-none"
                title="Share project (website link hidden, copies to clipboard)"
                aria-label="Share"
              >
                <Share2 className="w-4 h-4 text-cyan-400 drop-shadow-[0_0_8px_rgba(6,182,212,0.8)] group-hover/btn:drop-shadow-[0_0_14px_rgba(6,182,212,1)] group-hover/btn:scale-125 transition-all duration-150" />
                <span className="font-mono text-[10px] sm:text-[11px] font-bold leading-none tracking-tight text-cyan-300/80 group-hover/btn:text-cyan-100">
                  Share
                </span>
              </button>

              {/* 3. Views Shining Icon */}
              <button
                type="button"
                onClick={() => showToast('Verified organic portfolio impressions')}
                className="group/btn relative flex flex-col items-center justify-center gap-1.5 py-1 px-1 cursor-pointer select-none transition-all duration-150 active:scale-75 active:translate-y-1.5 focus:outline-none"
                title="Verified views"
                aria-label="Views"
              >
                <Eye className="w-4 h-4 text-[#3dff8f] drop-shadow-[0_0_8px_rgba(61,255,143,0.85)] group-hover/btn:drop-shadow-[0_0_16px_rgba(61,255,143,1)] group-hover/btn:scale-125 transition-all duration-150" />
                <span className="font-mono text-[10px] sm:text-[11px] font-bold leading-none tracking-tight text-[#3dff8f]/90 group-hover/btn:text-white">
                  1.4k
                </span>
              </button>

              {/* 4. Likes Shining Icon */}
              <button
                type="button"
                onClick={handleToggleLike}
                className="group/btn relative flex flex-col items-center justify-center gap-1.5 py-1 px-1 cursor-pointer select-none transition-all duration-150 active:scale-75 active:translate-y-1.5 focus:outline-none"
                title={isLiked ? 'Liked! Click to undo' : 'Like project'}
                aria-label="Like"
              >
                <ThumbsUp
                  className={`w-4 h-4 transition-all duration-150 group-hover/btn:scale-125 ${
                    isLiked
                      ? 'fill-blue-400 text-blue-400 drop-shadow-[0_0_10px_#3b82f6] drop-shadow-[0_0_20px_rgba(59,130,246,0.7)]'
                      : 'text-blue-400 drop-shadow-[0_0_8px_rgba(59,130,246,0.8)] group-hover/btn:drop-shadow-[0_0_14px_rgba(59,130,246,1)]'
                  }`}
                />
                <span
                  className={`font-mono text-[10px] sm:text-[11px] font-bold leading-none tracking-tight transition-all duration-150 ${
                    isLiked
                      ? 'text-blue-300 drop-shadow-[0_0_8px_rgba(59,130,246,0.8)]'
                      : 'text-blue-300/80 group-hover/btn:text-blue-100'
                  }`}
                >
                  {likeCount}
                </span>
              </button>

              {/* 5. Reviews / Rating Shining Icon */}
              <button
                type="button"
                onClick={() => showToast('5.0 / 5.0 rating from verified clients')}
                className="group/btn relative flex flex-col items-center justify-center gap-1.5 py-1 px-1 cursor-pointer select-none transition-all duration-150 active:scale-75 active:translate-y-1.5 focus:outline-none"
                title="5.0 rating from verified clients"
                aria-label="Reviews"
              >
                <Star className="w-4 h-4 fill-[#f0b92e] text-[#f0b92e] drop-shadow-[0_0_8px_rgba(240,185,46,0.85)] group-hover/btn:drop-shadow-[0_0_16px_rgba(240,185,46,1)] group-hover/btn:scale-125 transition-all duration-150" />
                <span className="font-mono text-[10px] sm:text-[11px] font-bold leading-none tracking-tight text-[#fff1b8] group-hover/btn:text-white">
                  5.0
                </span>
              </button>
            </div>
          </div>

          {/* Title and Short Summary */}
          <div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold font-serif-heading text-[#fff1b8] mb-2">
              {project.title}
            </h2>
            <p className="text-sm sm:text-base text-[#9fbfae] leading-relaxed">
              {project.summary}
            </p>
          </div>

          {/* Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.18)] text-xs font-mono">
            <div>
              <span className="text-[#9fbfae] block">My Role:</span>
              <strong className="text-[#f4fff8] mt-0.5 block truncate">{project.role}</strong>
            </div>
            <div>
              <span className="text-[#9fbfae] block">Status:</span>
              <strong className="text-[#3dff8f] mt-0.5 block capitalize">{project.status.replace('_', ' ')}</strong>
            </div>
            <div>
              <span className="text-[#9fbfae] block">Category:</span>
              <strong className="text-[#f0b92e] mt-0.5 block truncate">{project.category}</strong>
            </div>
            <div>
              <span className="text-[#9fbfae] block">Project Type:</span>
              <strong className="text-[#fff1b8] mt-0.5 block capitalize">{project.projectType}</strong>
            </div>
          </div>

          {/* Full Narrative */}
          <div>
            <h3 className="text-sm font-mono font-bold text-[#f0b92e] uppercase mb-2">
              Project Overview & Context
            </h3>
            <p className="text-sm text-[#f4fff8]/90 leading-relaxed whitespace-pre-line">
              {project.fullDescription}
            </p>
          </div>

          {/* Process Breakdown: Challenge, Solution, Outcome */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {project.mainChallenge && (
              <div className="p-4 rounded-xl bg-[#010a05] border border-[rgba(240,185,46,0.15)]">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-[#f0b92e] mb-1.5">
                  <AlertCircle className="w-4 h-4 text-[#f0b92e]" />
                  <span>The Challenge</span>
                </div>
                <p className="text-xs text-[#9fbfae] leading-relaxed">
                  {project.mainChallenge}
                </p>
              </div>
            )}

            {project.solution && (
              <div className="p-4 rounded-xl bg-[#010a05] border border-[rgba(240,185,46,0.15)]">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-[#3dff8f] mb-1.5">
                  <Lightbulb className="w-4 h-4 text-[#3dff8f]" />
                  <span>My Solution</span>
                </div>
                <p className="text-xs text-[#9fbfae] leading-relaxed">
                  {project.solution}
                </p>
              </div>
            )}

            {project.outcome && (
              <div className="p-4 rounded-xl bg-[#010a05] border border-[rgba(240,185,46,0.15)]">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-[#fff1b8] mb-1.5">
                  <CheckCircle2 className="w-4 h-4 text-[#fff1b8]" />
                  <span>Outcome & Learning</span>
                </div>
                <p className="text-xs text-[#9fbfae] leading-relaxed">
                  {project.outcome}
                </p>
              </div>
            )}
          </div>

          {/* Tools & AI Applied */}
          <div className="space-y-3 pt-2">
            <div>
              <span className="text-xs font-mono text-[#9fbfae] uppercase block mb-1.5">
                Tools & Technologies Used:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {project.tools.map((tool) => (
                  <span
                    key={tool}
                    className="px-2.5 py-1 rounded-full text-xs font-mono bg-[#3dff8f]/10 text-[#3dff8f] border border-[#3dff8f]/20"
                  >
                    {tool}
                  </span>
                ))}
              </div>
            </div>

            {project.aiUsed && project.aiUsed.length > 0 && (
              <div>
                <span className="text-xs font-mono text-[#f0b92e] uppercase flex items-center gap-1 mb-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#f0b92e]" />
                  <span>AI-Assisted Workflow Integration:</span>
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {project.aiUsed.map((ai) => (
                    <span
                      key={ai}
                      className="px-2.5 py-1 rounded-full text-xs font-mono bg-[#f0b92e]/10 text-[#fff1b8] border border-[#f0b92e]/25"
                    >
                      {ai}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-[#010904] border-t border-[rgba(240,185,46,0.3)] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            {project.liveUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-mono font-bold text-[#3dff8f] border border-[#3dff8f]/30 hover:bg-[#3dff8f]/10"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Visit Live Project</span>
              </a>
            )}
            {project.githubUrl && (
              <a
                href={project.githubUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-mono text-[#9fbfae] border border-white/10 hover:border-white/30 hover:text-white"
              >
                <Github className="w-3.5 h-3.5" />
                <span>Source Code</span>
              </a>
            )}
            {onInquireSimilar && (
              <button
                onClick={() => {
                  onClose();
                  onInquireSimilar(project.title);
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] hover:from-white hover:to-[#f0b92e]"
              >
                <Send className="w-3.5 h-3.5 text-[#1a1200]" />
                <span>Inquire About Similar Project</span>
              </button>
            )}
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-full text-xs font-mono text-[#9fbfae] border border-white/10 hover:text-white cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useEffect, useRef, useState } from 'react';

interface ScrollRevealProps {
  children: React.ReactNode;
  className?: string;
  stagger?: boolean;
  delay?: number;
  threshold?: number;
  rootMargin?: string;
  as?: React.ElementType;
}

/**
 * ScrollReveal
 * Triggers smooth staggered fade-in animations as users scroll content elements into view.
 * Works seamlessly with Tailwind animation and transition utilities.
 */
export const ScrollReveal: React.FC<ScrollRevealProps> = ({
  children,
  className = '',
  stagger = true,
  delay = 0,
  threshold = 0.08,
  rootMargin = '0px 0px -60px 0px',
  as: Component = 'div'
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    // If already in viewport on mount (e.g. top sections or refreshed page)
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight && rect.bottom > 0) {
      setIsVisible(true);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      {
        threshold,
        rootMargin
      }
    );

    observer.observe(el);

    return () => {
      observer.disconnect();
    };
  }, [threshold, rootMargin]);

  return (
    <Component
      ref={containerRef}
      className={`${stagger ? 'scroll-reveal-container' : 'scroll-reveal'} ${
        isVisible ? 'is-visible' : ''
      } ${className}`}
      style={delay ? { transitionDelay: `${delay}ms` } : undefined}
    >
      {children}
    </Component>
  );
};

/**
 * StaggerItem
 * Wraps individual content elements to receive cascading staggered fade-in delays.
 */
interface StaggerItemProps {
  children: React.ReactNode;
  className?: string;
  index?: number;
}

export const StaggerItem: React.FC<StaggerItemProps> = ({
  children,
  className = '',
  index
}) => {
  const inlineDelay = typeof index === 'number' ? { transitionDelay: `${index * 80 + 50}ms` } : undefined;

  return (
    <div className={`stagger-child ${className}`} style={inlineDelay}>
      {children}
    </div>
  );
};

/**
 * useScrollReveal
 * Custom hook for manual scroll reveal observation.
 */
export function useScrollReveal(options: { threshold?: number; rootMargin?: string } = {}) {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight && rect.bottom > 0) {
      setIsVisible(true);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      {
        threshold: options.threshold ?? 0.08,
        rootMargin: options.rootMargin ?? '0px 0px -60px 0px'
      }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [options.threshold, options.rootMargin]);

  return { ref, isVisible };
}

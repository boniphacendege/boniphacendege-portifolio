import React, { useState, useEffect } from 'react';
import { Sparkles, CheckCircle2 } from 'lucide-react';
import { LOGO_DATA_URI } from '../assets/logo';

interface PreloaderProps {
  onComplete?: () => void;
  brandName?: string;
  titles?: string[];
}

const PHASES = [
  'INITIALIZING CREATIVE PORTFOLIO...',
  'LOADING VISUAL BRANDING ASSETS...',
  'CALIBRATING RESPONSIVE INTERFACES...',
  'INITIALIZING AI DESIGN WORKFLOWS...',
  'PORTFOLIO READY — WELCOME'
];

export const Preloader: React.FC<PreloaderProps> = ({
  onComplete,
  brandName = 'Boniphace Ndege',
  titles = [
    'Graphic Designer',
    'Website Designer & Developer',
    'Digital Content Creator'
  ]
}) => {
  const [progress, setProgress] = useState(0);
  const [phaseIndex, setPhaseIndex] = useState(0);
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [isRemoved, setIsRemoved] = useState(false);

  useEffect(() => {
    // Smooth progress increment
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        // Accelerate smoothly towards 100
        const step = prev < 40 ? 4 : prev < 80 ? 6 : 8;
        const next = Math.min(100, prev + step);
        
        // Update phase
        const idx = Math.min(PHASES.length - 1, Math.floor((next / 100) * PHASES.length));
        setPhaseIndex(idx);
        return next;
      });
    }, 45);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (progress === 100) {
      const fadeTimer = setTimeout(() => {
        setIsFadingOut(true);
        if (onComplete) onComplete();
      }, 350);

      const removeTimer = setTimeout(() => {
        setIsRemoved(true);
      }, 1050);

      return () => {
        clearTimeout(fadeTimer);
        clearTimeout(removeTimer);
      };
    }
  }, [progress, onComplete]);

  if (isRemoved) return null;

  return (
    <div
      role="progressbar"
      aria-valuenow={progress}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label="Portfolio Loading Screen"
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#010603] text-[#f4fff8] select-none transition-all duration-700 ease-out ${
        isFadingOut ? 'opacity-0 scale-102 pointer-events-none' : 'opacity-100 scale-100'
      }`}
    >
      {/* Background Radial Glow Atmosphere */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute w-[450px] sm:w-[600px] aspect-square rounded-full bg-radial from-[#3dff8f]/18 via-[#0f7a43]/10 to-transparent blur-3xl animate-pulse-glow"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute w-[300px] aspect-square rounded-full bg-radial from-[#f0b92e]/12 to-transparent blur-2xl"
      />

      <div className="relative z-10 flex flex-col items-center max-w-md px-6 text-center">
        {/* Animated Brand Emblem Centerpiece with Rotating Rings */}
        <div className="relative w-28 h-28 sm:w-32 sm:h-32 mb-7 flex items-center justify-center">
          {/* Small Outer Shining Green Neon Rotating Ring - Reduced Neon */}
          <div
            aria-hidden="true"
            className="absolute -inset-1 rounded-full border-[1.5px] border-transparent border-t-[#3dff8f]/90 border-r-[#3dff8f]/50 shining-neon-rotating-ring shadow-[0_0_8px_rgba(61,255,143,0.35)]"
          >
            <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-[#3dff8f] shadow-[0_0_6px_#3dff8f]" />
          </div>

          {/* Secondary Gold Dashed Counter-Rotating Ring */}
          <div
            aria-hidden="true"
            className="absolute inset-0 rounded-full border border-[#f0b92e]/40 border-dashed shining-neon-counter-ring shadow-[0_0_6px_rgba(240,185,46,0.25)]"
          />

          {/* Center Logo / Monogram Container */}
          <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden bg-[#02140b] border border-[rgba(240,185,46,0.4)] p-1.5 shadow-[0_0_25px_rgba(0,0,0,0.9),inset_0_0_15px_rgba(61,255,143,0.2)] flex items-center justify-center">
            <img
              src={LOGO_DATA_URI}
              alt="Boniphace Ndege Emblem"
              className="w-full h-full object-contain filter drop-shadow-[0_0_10px_rgba(61,255,143,0.5)]"
            />
          </div>
        </div>

        {/* Brand Name with Elegant Serif Display */}
        <h1 className="font-serif-heading font-extrabold text-2xl sm:text-3xl lg:text-4xl tracking-tight mb-2 drop-shadow-[0_2px_14px_rgba(0,0,0,0.9)]">
          <span className="gold-text inline-block">{brandName}</span>
        </h1>

        {/* Professional Titles Subtitle */}
        <p className="text-xs sm:text-sm font-mono text-[#3dff8f] tracking-wide mb-6">
          {titles.join(' • ')}
        </p>

        {/* Progress Bar Container */}
        <div className="w-full max-w-xs space-y-2 mb-4">
          <div className="flex items-center justify-between text-xs font-mono text-[#9fbfae]">
            <span className="flex items-center gap-1.5 text-[#3dff8f]">
              <Sparkles className="w-3 h-3 text-[#f0b92e] animate-pulse" />
              <span>LOADING SYSTEM</span>
            </span>
            <span className="font-bold text-[#fff1b8]">{progress}%</span>
          </div>

          {/* Glowing Track & Fill */}
          <div className="relative w-full h-2 rounded-full bg-[#000d05] border border-[rgba(61,255,143,0.3)] overflow-hidden p-[1px] shadow-[inset_0_1px_4px_rgba(0,0,0,0.8)]">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#0f7a43] via-[#3dff8f] to-[#f0b92e] shadow-[0_0_12px_#3dff8f] transition-all duration-75 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Status Phase Label */}
        <div className="h-5 flex items-center justify-center text-[11px] font-mono text-[#c8e2d4]/80 tracking-wider">
          {progress === 100 ? (
            <span className="inline-flex items-center gap-1.5 text-[#3dff8f] font-semibold animate-pulse">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#3dff8f]" />
              <span>EXPERIENCE READY</span>
            </span>
          ) : (
            <span>{PHASES[phaseIndex]}</span>
          )}
        </div>

        {/* Skip button for immediate entry */}
        <button
          onClick={() => {
            setIsFadingOut(true);
            setTimeout(() => setIsRemoved(true), 400);
            if (onComplete) onComplete();
          }}
          className="mt-6 text-[11px] font-mono text-[#9fbfae]/70 hover:text-[#f0b92e] underline transition-colors cursor-pointer"
        >
          Skip Intro
        </button>
      </div>
    </div>
  );
};

import { useEffect } from 'react';
import { ProfileData } from '../data/portfolioStorage';

export function useSeoSync(profile: ProfileData) {
  useEffect(() => {
    const titlesString = profile.titles?.length
      ? profile.titles.join(', ')
      : 'Graphic Designer, Website Designer & Developer, Digital Content Creator';

    const fullTitle = `Boniphace Ndege | ${titlesString}`;
    const dynamicDescription = `Boniphace Ndege — ${titlesString}. ${profile.headline || 'Creative Design. Modern Websites. Digital Innovation.'} Discover visual branding, responsive modern websites, and digital media in Dodoma, Tanzania.`;

    // 1. Update Document Title
    document.title = fullTitle;

    // Helper to update or create meta tag
    const setMetaTag = (attribute: 'name' | 'property', key: string, value: string) => {
      let tag = document.querySelector(`meta[${attribute}="${key}"]`);
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute(attribute, key);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', value);
    };

    // 2. Standard Search Meta Tags
    setMetaTag('name', 'description', dynamicDescription);
    setMetaTag('name', 'author', 'Boniphace Ndege');
    setMetaTag(
      'name',
      'keywords',
      `Boniphace Ndege, ${profile.titles?.join(', ')}, Graphic Designer, Website Designer, Web Developer, Digital Content Creator, Dodoma Tanzania, Visual Branding`
    );

    // 3. OpenGraph Social Cards
    setMetaTag('property', 'og:site_name', 'Boniphace Ndege');
    setMetaTag('property', 'og:title', fullTitle);
    setMetaTag('property', 'og:description', dynamicDescription);
    setMetaTag('property', 'og:type', 'website');
    if (typeof window !== 'undefined') {
      setMetaTag('property', 'og:url', window.location.origin + window.location.pathname);
    }

    // 4. Twitter / X Social Cards
    setMetaTag('name', 'twitter:title', fullTitle);
    setMetaTag('name', 'twitter:description', dynamicDescription);

    // 5. Update Schema.org JSON-LD Structured Data
    try {
      const existingScript = document.querySelector('script[type="application/ld+json"]');
      const structuredData = {
        '@context': 'https://schema.org',
        '@type': 'ProfilePage',
        mainEntity: {
          '@type': 'Person',
          name: 'Boniphace Ndege',
          alternateName: 'Ev Dr. Boniphace J. Ndege',
          jobTitle: titlesString,
          description: dynamicDescription,
          url: typeof window !== 'undefined' ? window.location.origin : 'https://boniphacendege.com',
          email: profile.email || 'drboniphacendege@gmail.com',
          telephone: profile.phone || '+255765326515',
          address: {
            '@type': 'PostalAddress',
            addressLocality: profile.location || 'Dodoma CBD Tanzania',
            addressCountry: 'Tanzania'
          },
          knowsAbout: [
            'Graphic Design',
            'Visual Branding & Identity',
            'Website Design',
            'Responsive Web Development',
            'Digital Content Creation',
            'UI/UX Design',
            'AI-Assisted Workflows'
          ]
        }
      };

      if (existingScript) {
        existingScript.textContent = JSON.stringify(structuredData);
      }
    } catch (e) {
      console.warn('Could not update JSON-LD script', e);
    }
  }, [profile]);
}

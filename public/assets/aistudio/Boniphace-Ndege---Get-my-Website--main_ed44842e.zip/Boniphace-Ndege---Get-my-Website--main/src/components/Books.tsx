/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Download,
  Search,
  Filter,
  Star,
  ExternalLink,
  MessageCircle,
  FileText,
  Clock,
  Calendar,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle,
  Eye,
  Heart,
  SlidersHorizontal,
  Bookmark
} from 'lucide-react';
import { BookItem, portfolioStorage } from '../data/portfolioStorage';
import { getCssAspectRatio } from '../utils/imageHelper';
import { PenOnBookIcon } from './PenOnBookIcon';

interface BooksProps {
  books: BookItem[];
  categories: string[];
  onSelectBook: (book: BookItem) => void;
  onOpenAdmin?: () => void;
}

export const Books: React.FC<BooksProps> = ({
  books,
  categories,
  onSelectBook,
  onOpenAdmin
}) => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'newest' | 'rating' | 'downloads'>('featured');
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({});

  // Filtered & Sorted books
  const filteredBooks = useMemo(() => {
    let list = books.filter((b) => b.published !== false);

    // Category filter
    if (selectedCategory !== 'All' && selectedCategory !== 'All Categories') {
      list = list.filter((b) => b.category === selectedCategory);
    }

    // Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (b) =>
          b.title.toLowerCase().includes(q) ||
          (b.subtitle && b.subtitle.toLowerCase().includes(q)) ||
          b.excerpt.toLowerCase().includes(q) ||
          b.category.toLowerCase().includes(q) ||
          b.tags.some((t) => t.toLowerCase().includes(q)) ||
          (b.isbn && b.isbn.toLowerCase().includes(q))
      );
    }

    // Sorting
    return list.sort((a, b) => {
      if (sortBy === 'featured') {
        if (a.featured && !b.featured) return -1;
        if (!a.featured && b.featured) return 1;
        return a.order - b.order;
      }
      if (sortBy === 'newest') {
        return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
      }
      if (sortBy === 'rating') {
        return (b.rating || 0) - (a.rating || 0);
      }
      if (sortBy === 'downloads') {
        return (b.downloadsCount || 0) - (a.downloadsCount || 0);
      }
      return 0;
    });
  }, [books, selectedCategory, searchQuery, sortBy]);

  // Featured book for top showcase
  const featuredBook = useMemo(() => {
    return books.find((b) => b.featured && b.published !== false) || books[0];
  }, [books]);

  const handleLikeCard = (e: React.MouseEvent, bookId: string) => {
    e.stopPropagation();
    if (likedMap[bookId]) return;
    portfolioStorage.recordBookLike(bookId);
    setLikedMap((prev) => ({ ...prev, [bookId]: true }));
  };

  const handleDownloadDirect = (e: React.MouseEvent, book: BookItem) => {
    e.stopPropagation();
    portfolioStorage.recordBookDownload(book.id);
    const targetUrl = book.pdfFileUrl || book.downloadUrl;
    if (targetUrl) {
      const a = document.createElement('a');
      a.href = targetUrl;
      a.download = `${book.slug || 'book'}-by-dr-boniphace-ndege.pdf`;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } else {
      window.open(
        `https://wa.me/255655483255?text=Hello%20Dr.%20Boniphace,%20I%20would%20like%20to%20request%20your%20book:%20${encodeURIComponent(book.title)}`,
        '_blank'
      );
    }
  };

  const allCategories = useMemo(() => {
    const set = new Set(['All']);
    (categories || []).forEach((c) => {
      if (c && c !== 'All Categories') set.add(c);
    });
    (books || []).forEach((b) => {
      if (b.category) set.add(b.category);
    });
    return Array.from(set);
  }, [categories, books]);

  return (
    <section id="books" className="py-20 sm:py-28 px-4 sm:px-6 relative overflow-hidden bg-[#000502]">
      {/* Background Ambience */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-gradient-to-b from-[#3dff8f]/8 to-transparent rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto space-y-12 sm:space-y-16 relative z-10">
        
        {/* Section Header */}
        <div className="text-center space-y-4 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#02180d] border border-[#3dff8f]/40 shadow-[0_0_15px_rgba(61,255,143,0.2)]">
            <PenOnBookIcon className="w-4 h-4 text-[#3dff8f]" />
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#3dff8f]">
              Author Books & Literary Works
            </span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-bold font-serif-heading text-[#fff1b8] tracking-tight">
            Author Bookstore & Publications
          </h2>

          <p className="text-sm sm:text-base text-[#9fbfae] leading-relaxed">
            Written and published by <span className="text-[#3dff8f] font-semibold">Ev Dr. Boniphace J. Ndege</span> — explore definitive masterclasses, spiritual leadership treatises, and practical African entrepreneurship blueprints.
          </p>
        </div>

        {/* Featured Bestseller Spotlight Showcase */}
        {featuredBook && (
          <div className="p-6 sm:p-10 rounded-3xl bg-gradient-to-br from-[#011409] via-[#021008] to-[#010904] border border-[rgba(240,185,46,0.3)] shadow-[0_0_50px_rgba(0,0,0,0.8),0_0_30px_rgba(61,255,143,0.12)] relative overflow-hidden">
            <div className="header-neon-line top-0" />
            
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              
              {/* 3D Book Mockup Display with Dynamic Aspect Ratio */}
              <div className="lg:col-span-5 flex justify-center">
                <div
                  onClick={() => onSelectBook(featuredBook)}
                  className="relative group cursor-pointer max-w-[280px] sm:max-w-[320px] w-full"
                >
                  {/* Outer Glow */}
                  <div className="absolute inset-0 bg-[#3dff8f]/20 rounded-2xl blur-2xl group-hover:bg-[#3dff8f]/35 transition-all duration-300 pointer-events-none" />

                  {/* 3D Realistic Book Perspective Container */}
                  <div
                    className={`relative w-full rounded-2xl overflow-hidden border-2 border-[rgba(240,185,46,0.4)] shadow-[0_20px_50px_rgba(0,0,0,0.9),0_0_30px_rgba(240,185,46,0.25)] transition-transform duration-300 group-hover:-translate-y-2 ${getCssAspectRatio(
                      featuredBook.aspectRatio || '2:3'
                    )}`}
                  >
                    <img
                      src={featuredBook.coverImage}
                      alt={featuredBook.title}
                      className="w-full h-full object-cover"
                    />

                    {/* Book spine highlight & 3D shadow */}
                    <div className="absolute inset-y-0 left-0 w-4 bg-gradient-to-r from-black/85 via-black/40 to-transparent pointer-events-none" />
                    <div className="absolute inset-y-0 left-4 w-1 bg-white/20 blur-[1px] pointer-events-none" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent pointer-events-none" />

                    {/* Look Inside Overlay CTA on Hover */}
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-4 text-center">
                      <div className="w-12 h-12 rounded-full bg-[#3dff8f] text-black flex items-center justify-center shadow-lg">
                        <BookOpen className="w-6 h-6" />
                      </div>
                      <span className="text-xs font-bold font-mono text-[#f4fff8] uppercase">
                        Look Inside Book
                      </span>
                      <span className="text-[10px] text-[#3dff8f]">
                        Choose inside reading typography
                      </span>
                    </div>
                  </div>

                  {/* Featured Badge */}
                  <div className="absolute -top-3 -right-3 px-3 py-1 rounded-full bg-[#f0b92e] text-[#1a1200] font-mono font-bold text-xs uppercase shadow-xl flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-[#1a1200]" />
                    <span>Author Spotlight</span>
                  </div>
                </div>
              </div>

              {/* Book Information */}
              <div className="lg:col-span-7 space-y-4">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-[#3dff8f]/15 text-[#3dff8f] border border-[#3dff8f]/30 font-mono text-xs uppercase font-bold">
                    {featuredBook.category}
                  </span>
                  {featuredBook.isFreeDownload ? (
                    <span className="px-3 py-1 rounded-full bg-[#f0b92e]/20 text-[#f0b92e] border border-[#f0b92e]/40 font-mono text-xs font-bold uppercase">
                      Free Digital Gift
                    </span>
                  ) : (
                    <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono text-xs font-bold">
                      ${featuredBook.price || '18.50'} USD
                    </span>
                  )}
                  {featuredBook.pagesCount && (
                    <span className="text-xs font-mono text-[#9fbfae]">
                      {featuredBook.pagesCount} Pages • {featuredBook.language || 'English'}
                    </span>
                  )}
                </div>

                <div>
                  <h3 className="text-2xl sm:text-4xl font-bold font-serif-heading text-[#fff1b8] leading-tight">
                    {featuredBook.title}
                  </h3>
                  {featuredBook.subtitle && (
                    <p className="text-sm sm:text-base text-[#3dff8f] font-medium italic mt-1">
                      {featuredBook.subtitle}
                    </p>
                  )}
                </div>

                {/* Author attribution */}
                <div className="flex items-center gap-3 pt-1">
                  <img
                    src={featuredBook.author.avatar || 'https://via.placeholder.com/60'}
                    alt={featuredBook.author.name}
                    className="w-10 h-10 rounded-full object-cover border border-[#f0b92e]/50 p-0.5"
                  />
                  <div>
                    <div className="text-xs sm:text-sm font-bold text-[#f4fff8]">
                      {featuredBook.author.name}
                    </div>
                    <div className="text-[11px] text-[#9fbfae] font-mono">
                      Published {new Date(featuredBook.publishedAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                    </div>
                  </div>
                </div>

                {/* Excerpt Box ("show text except") */}
                <div className="p-4 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs sm:text-sm text-[#9fbfae] leading-relaxed">
                  <span className="text-[#f0b92e] font-bold font-mono text-xs uppercase mr-2">
                    Book Excerpt:
                  </span>
                  &ldquo;{featuredBook.excerpt}&rdquo;
                </div>

                {/* Formats and Metrics */}
                <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-[#9fbfae]">
                  <div className="flex items-center gap-1 text-[#f0b92e]">
                    <Star className="w-4 h-4 fill-[#f0b92e]" />
                    <span className="font-bold">{featuredBook.rating || 4.96}</span>
                    <span className="text-[#9fbfae]">({featuredBook.reviewsCount || 48} reviews)</span>
                  </div>
                  <div>Downloads: <span className="text-[#3dff8f] font-bold">{featuredBook.downloadsCount || 420}</span></div>
                  <div>Reads: <span className="text-[#f4fff8] font-bold">{featuredBook.readsCount || 1200}</span></div>
                </div>

                {/* Action Buttons */}
                <div className="pt-2 flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => onSelectBook(featuredBook)}
                    className="px-6 py-3 rounded-2xl font-bold text-xs sm:text-sm text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] hover:from-white hover:to-[#f0b92e] shadow-[0_0_20px_-3px_rgba(240,185,46,0.6)] flex items-center gap-2 cursor-pointer transition-all active:scale-95"
                  >
                    <BookOpen className="w-4 h-4 text-[#1a1200]" />
                    <span>Look Inside / Read Chapters</span>
                  </button>

                  {(featuredBook.isDownloadable || featuredBook.pdfFileUrl || featuredBook.downloadUrl) && (
                    <button
                      onClick={(e) => handleDownloadDirect(e, featuredBook)}
                      className="px-5 py-3 rounded-2xl font-bold text-xs sm:text-sm bg-[#0a351e] text-[#3dff8f] border border-[#3dff8f]/50 hover:bg-[#0d4728] transition-all flex items-center gap-2 cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>{featuredBook.isFreeDownload ? 'Download Free PDF' : 'Download Sample'}</span>
                    </button>
                  )}

                  {!featuredBook.isFreeDownload && (
                    <a
                      href={
                        featuredBook.externalBuyUrls?.directWhatsApp ||
                        `https://wa.me/255655483255?text=Hello%20Dr.%20Boniphace,%20I%20would%20like%20to%20order%20the%20physical%20copy%20of%20${encodeURIComponent(featuredBook.title)}`
                      }
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-5 py-3 rounded-2xl font-bold text-xs sm:text-sm bg-[#25D366]/20 text-[#25D366] border border-[#25D366]/40 hover:bg-[#25D366]/30 transition-all flex items-center gap-2"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Order Hardcover via WhatsApp</span>
                    </a>
                  )}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* Filter Bar & Search */}
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
            
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-[#3dff8f] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search books, chapters, excerpts, ISBN..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#010c06] border border-[rgba(240,185,46,0.25)] text-xs sm:text-sm text-[#f4fff8] placeholder:text-[#9fbfae]/60 focus:outline-none focus:border-[#3dff8f] transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#9fbfae] hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Sort & Admin Shortcut */}
            <div className="flex items-center gap-2.5 justify-end">
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#010c06] border border-white/10 text-xs font-mono text-[#9fbfae]">
                <SlidersHorizontal className="w-3.5 h-3.5 text-[#f0b92e]" />
                <span>Sort:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-transparent text-[#f4fff8] font-bold focus:outline-none cursor-pointer"
                >
                  <option value="featured" className="bg-[#010c06] text-white">Featured</option>
                  <option value="newest" className="bg-[#010c06] text-white">Newest First</option>
                  <option value="rating" className="bg-[#010c06] text-white">Highest Rated</option>
                  <option value="downloads" className="bg-[#010c06] text-white">Most Downloaded</option>
                </select>
              </div>

              {onOpenAdmin && (
                <button
                  onClick={onOpenAdmin}
                  className="px-3 py-2 rounded-xl text-xs font-mono font-bold text-[#f0b92e] bg-[#f0b92e]/10 border border-[#f0b92e]/30 hover:bg-[#f0b92e]/20 transition-all cursor-pointer flex items-center gap-1.5"
                  title="Manage books in admin dashboard"
                >
                  <PenOnBookIcon className="w-3.5 h-3.5 text-[#f0b92e]" />
                  <span className="hidden sm:inline">Admin Book Manager</span>
                </button>
              )}
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 select-none no-scrollbar">
            {allCategories.map((cat) => {
              const isSelected = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#3dff8f] text-black shadow-[0_0_15px_rgba(61,255,143,0.35)]'
                      : 'bg-[#010c06] text-[#9fbfae] border border-white/10 hover:border-white/25 hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Books Grid with Universal Aspect Ratio Support */}
        {filteredBooks.length === 0 ? (
          <div className="py-16 text-center space-y-3 p-8 rounded-3xl bg-[#010a05] border border-white/10">
            <BookOpen className="w-12 h-12 text-[#9fbfae]/40 mx-auto" />
            <h3 className="text-lg font-bold text-[#fff1b8]">No Books Found</h3>
            <p className="text-xs text-[#9fbfae] max-w-sm mx-auto">
              No publications match &ldquo;{searchQuery}&rdquo;. Try another search keyword or switch categories.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
              }}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-[#3dff8f] text-black cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {filteredBooks.map((book) => {
              const isLiked = likedMap[book.id];
              return (
                <article
                  key={book.id}
                  onClick={() => onSelectBook(book)}
                  className="group rounded-3xl bg-[#010c06] border border-[rgba(240,185,46,0.18)] hover:border-[#3dff8f]/50 shadow-lg hover:shadow-[0_0_30px_rgba(61,255,143,0.15)] transition-all duration-300 flex flex-col overflow-hidden cursor-pointer relative"
                >
                  {/* Top neon line accent on hover */}
                  <div className="h-0.5 w-full bg-gradient-to-r from-transparent via-[#3dff8f] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                  {/* Book Cover Area with Dynamic Aspect Ratio */}
                  <div className="p-5 pb-0 bg-gradient-to-b from-[#02140b] to-[#010c06] flex justify-center relative">
                    <div
                      className={`w-full max-w-[220px] rounded-xl overflow-hidden border border-[rgba(240,185,46,0.3)] shadow-[0_12px_28px_rgba(0,0,0,0.8)] relative transition-transform duration-300 group-hover:-translate-y-1.5 ${getCssAspectRatio(
                        book.aspectRatio || '2:3'
                      )}`}
                    >
                      <img
                        src={book.coverImage}
                        alt={book.title}
                        className="w-full h-full object-cover"
                      />
                      {/* Book spine gradient simulation */}
                      <div className="absolute inset-y-0 left-0 w-3 bg-gradient-to-r from-black/80 via-black/30 to-transparent pointer-events-none" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
                    </div>

                    {/* Price / Free Badge */}
                    <div className="absolute top-3 right-4 px-2.5 py-0.5 rounded-full bg-[#f0b92e] text-[#1a1200] font-mono font-bold text-[10px] uppercase shadow-md">
                      {book.isFreeDownload ? 'Free Gift' : `$${book.price || '18.50'}`}
                    </div>
                  </div>

                  {/* Book Content Body */}
                  <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-[10px] font-mono">
                        <span className="text-[#3dff8f] uppercase font-bold px-2 py-0.5 rounded-full bg-[#3dff8f]/10 border border-[#3dff8f]/30">
                          {book.category}
                        </span>
                        <span className="text-[#9fbfae]">
                          {book.pagesCount ? `${book.pagesCount} Pages` : 'Digital'}
                        </span>
                      </div>

                      <h3 className="text-base sm:text-lg font-bold font-serif-heading text-[#f4fff8] group-hover:text-[#3dff8f] transition-colors line-clamp-2">
                        {book.title}
                      </h3>

                      {book.subtitle && (
                        <p className="text-xs text-[#9fbfae] italic line-clamp-1">
                          {book.subtitle}
                        </p>
                      )}

                      {/* Text Excerpt ("show text except") */}
                      <p className="text-xs text-[#9fbfae] line-clamp-3 leading-relaxed">
                        {book.excerpt}
                      </p>
                    </div>

                    {/* Metadata & Author Footer */}
                    <div className="pt-3 border-t border-white/10 space-y-3">
                      <div className="flex items-center justify-between text-[11px] font-mono text-[#9fbfae]">
                        <div className="flex items-center gap-2">
                          <img
                            src={book.author.avatar || 'https://via.placeholder.com/40'}
                            alt=""
                            className="w-5 h-5 rounded-full object-cover border border-[#f0b92e]"
                          />
                          <span className="truncate max-w-[120px] text-[#f4fff8]">{book.author.name}</span>
                        </div>
                        <div className="flex items-center gap-1 text-[#f0b92e]">
                          <Star className="w-3.5 h-3.5 fill-[#f0b92e]" />
                          <span>{book.rating || 4.9}</span>
                        </div>
                      </div>

                      {/* Action Bar */}
                      <div className="flex items-center justify-between gap-2 pt-1">
                        <button
                          onClick={() => onSelectBook(book)}
                          className="px-3.5 py-1.5 rounded-xl text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] hover:from-white hover:to-[#f0b92e] flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
                        >
                          <PenOnBookIcon className="w-3.5 h-3.5 text-[#1a1200]" />
                          <span>Look Inside</span>
                        </button>

                        <div className="flex items-center gap-1.5">
                          {(book.isDownloadable || book.pdfFileUrl || book.downloadUrl) && (
                            <button
                              onClick={(e) => handleDownloadDirect(e, book)}
                              className="p-2 rounded-xl text-xs bg-white/5 hover:bg-[#0a351e] text-[#9fbfae] hover:text-[#3dff8f] border border-white/10 hover:border-[#3dff8f]/40 transition-all cursor-pointer"
                              title="Download PDF"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </button>
                          )}

                          <button
                            onClick={(e) => handleLikeCard(e, book.id)}
                            className={`p-2 rounded-xl text-xs transition-all cursor-pointer ${
                              isLiked
                                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                                : 'bg-white/5 text-[#9fbfae] hover:text-white border border-white/10'
                            }`}
                            title="Like this book"
                          >
                            <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-rose-400' : ''}`} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}

        {/* Author Mission Banner */}
        <div className="p-8 sm:p-10 rounded-3xl bg-gradient-to-r from-[#010e06] via-[#02150b] to-[#010e06] border border-[#3dff8f]/30 flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left relative overflow-hidden">
          <div className="space-y-2 max-w-2xl">
            <span className="text-xs font-mono uppercase text-[#f0b92e] font-bold tracking-wider">
              Author Philosophy & Literary Conviction
            </span>
            <h3 className="text-xl sm:text-2xl font-bold font-serif-heading text-[#fff1b8]">
              &ldquo;Books are architecture for the soul. They preserve principles long after trends fade.&rdquo;
            </h3>
            <p className="text-xs text-[#9fbfae]">
              — Ev Dr. Boniphace J. Ndege, Lead Designer, Technologist & Evangelist (Dodoma CBD, Tanzania)
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 shrink-0">
            <a
              href="https://wa.me/255655483255?text=Hello%20Dr.%20Boniphace,%20I%20would%20like%20to%20invite%20you%20for%20a%20book%20signing,%20speaking%20session%20or%20bulk%20order"
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#25D366] text-black hover:bg-[#20ba5c] flex items-center gap-2 transition-all shadow-md"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Speaking & Bulk Inquiries</span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};

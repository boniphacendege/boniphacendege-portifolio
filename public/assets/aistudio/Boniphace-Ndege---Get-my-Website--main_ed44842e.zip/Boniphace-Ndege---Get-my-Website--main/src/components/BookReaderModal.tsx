/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Download,
  Share2,
  Heart,
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Clock,
  Calendar,
  Layers,
  Sparkles,
  ExternalLink,
  MessageCircle,
  Check,
  Bookmark,
  Sliders,
  Type,
  FileText,
  ShieldCheck,
  Star,
  Eye
} from 'lucide-react';
import { BookItem, BookChapter, BookReadingTheme, portfolioStorage } from '../data/portfolioStorage';
import { getCssAspectRatio } from '../utils/imageHelper';
import { PenOnBookIcon } from './PenOnBookIcon';

interface BookReaderModalProps {
  book: BookItem | null;
  allBooks: BookItem[];
  onClose: () => void;
  onSelectBook: (book: BookItem) => void;
}

const THEME_OPTIONS: Array<{
  id: BookReadingTheme;
  name: string;
  desc: string;
  iconLabel: string;
  bgClass: string;
  textClass: string;
  accentClass: string;
}> = [
  {
    id: 'modern-editorial',
    name: 'Modern Editorial',
    desc: 'Classic serif, elegant drop-caps & warm gold flourishes',
    iconLabel: 'Editorial',
    bgClass: 'bg-[#09140d] text-[#f4fff8]',
    textClass: 'font-serif text-[#f2ede4] leading-relaxed',
    accentClass: 'text-[#f0b92e] border-[#f0b92e]/30'
  },
  {
    id: 'midnight-emerald',
    name: 'Midnight Emerald',
    desc: 'Deep obsidian backdrop with cyber-neon emerald glow',
    iconLabel: 'Emerald',
    bgClass: 'bg-[#010804] text-[#f4fff8]',
    textClass: 'font-sans text-[#e4fbe9] leading-relaxed',
    accentClass: 'text-[#3dff8f] border-[#3dff8f]/40'
  },
  {
    id: 'minimalist-sans',
    name: 'Minimalist Clean',
    desc: 'Swiss neo-grotesque design with maximum legibility',
    iconLabel: 'Swiss Sans',
    bgClass: 'bg-[#050d08] text-[#f4fff8]',
    textClass: 'font-sans text-[#f0f4f1] leading-relaxed',
    accentClass: 'text-[#84e1bc] border-[#84e1bc]/30'
  },
  {
    id: 'vintage-parchment',
    name: 'Vintage Parchment',
    desc: 'Warm literary tones, italicized headings & ornate borders',
    iconLabel: 'Parchment',
    bgClass: 'bg-[#121008] text-[#fbf6e8]',
    textClass: 'font-serif text-[#f6eee0] leading-loose',
    accentClass: 'text-[#ffdb70] border-[#ffdb70]/30'
  },
  {
    id: 'executive-dual',
    name: 'Executive Academic',
    desc: 'Two-column academic spread with marginal annotations',
    iconLabel: 'Dual Column',
    bgClass: 'bg-[#030d07] text-[#f4fff8]',
    textClass: 'font-serif text-[#eef6f0] leading-normal',
    accentClass: 'text-[#3dff8f] border-[#3dff8f]/30'
  }
];

export const BookReaderModal: React.FC<BookReaderModalProps> = ({
  book,
  allBooks,
  onClose,
  onSelectBook
}) => {
  const [activeChapterIndex, setActiveChapterIndex] = useState(0);
  const [readingTheme, setReadingTheme] = useState<BookReadingTheme>(
    book?.readingTheme || 'modern-editorial'
  );
  const [fontSizeLevel, setFontSizeLevel] = useState<'sm' | 'md' | 'lg' | 'xl'>('md');
  const [readingWidth, setReadingWidth] = useState<'standard' | 'wide' | 'focused'>('standard');
  const [scrollProgress, setScrollProgress] = useState(0);
  const [likesCount, setLikesCount] = useState(book?.likesCount || 0);
  const [downloadsCount, setDownloadsCount] = useState(book?.downloadsCount || 0);
  const [hasLiked, setHasLiked] = useState(false);
  const [shareToast, setShareToast] = useState(false);
  const [showChaptersSidebar, setShowChaptersSidebar] = useState(false);
  const [showThemePicker, setShowThemePicker] = useState(false);
  const contentContainerRef = useRef<HTMLDivElement>(null);

  // Sync state when book changes
  useEffect(() => {
    if (book) {
      setActiveChapterIndex(0);
      setReadingTheme(book.readingTheme || 'modern-editorial');
      setLikesCount(book.likesCount || 0);
      setDownloadsCount(book.downloadsCount || 0);
      setHasLiked(false);
      portfolioStorage.incrementBookReads(book.id);
      if (contentContainerRef.current) {
        contentContainerRef.current.scrollTop = 0;
      }
    }
  }, [book]);

  // Track reading scroll progress
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    const totalHeight = el.scrollHeight - el.clientHeight;
    if (totalHeight > 0) {
      const current = (el.scrollTop / totalHeight) * 100;
      setScrollProgress(Math.min(100, Math.max(0, current)));
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!book) return null;

  const chapters: BookChapter[] = book.chapters && book.chapters.length > 0
    ? book.chapters
    : [
        {
          id: 'sample-ch-1',
          chapterNumber: 1,
          title: 'Introduction & Prologue',
          subtitle: book.subtitle || 'Author Excerpt',
          content: book.samplePreviewText || book.description || book.excerpt
        }
      ];

  const currentChapter = chapters[activeChapterIndex] || chapters[0];
  const activeThemeConfig = THEME_OPTIONS.find((t) => t.id === readingTheme) || THEME_OPTIONS[0];

  const handleLike = () => {
    if (hasLiked) return;
    const updated = portfolioStorage.recordBookLike(book.id);
    setLikesCount(updated);
    setHasLiked(true);
  };

  const handleDownload = () => {
    const updatedDownloads = portfolioStorage.recordBookDownload(book.id);
    setDownloadsCount(updatedDownloads);

    const targetUrl = book.pdfFileUrl || book.downloadUrl;
    if (targetUrl) {
      const a = document.createElement('a');
      a.href = targetUrl;
      a.download = `${book.slug || 'book'}-by-dr-boniphace-ndege.pdf`;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } else {
      // Direct WhatsApp request fallback
      const waUrl = `https://wa.me/255655483255?text=Hello%20Dr.%20Boniphace,%20I%20would%20like%20to%20request%20the%20digital%20copy%20of%20your%20book:%20${encodeURIComponent(book.title)}`;
      window.open(waUrl, '_blank', 'noopener,noreferrer');
    }
  };

  const handleShare = () => {
    const url = window.location.origin + '#books';
    if (navigator.clipboard) {
      navigator.clipboard.writeText(`${book.title} by ${book.author.name} — ${url}`);
      setShareToast(true);
      setTimeout(() => setShareToast(false), 2400);
    }
  };

  const nextChapter = () => {
    if (activeChapterIndex < chapters.length - 1) {
      setActiveChapterIndex((prev) => prev + 1);
      if (contentContainerRef.current) contentContainerRef.current.scrollTop = 0;
    }
  };

  const prevChapter = () => {
    if (activeChapterIndex > 0) {
      setActiveChapterIndex((prev) => prev - 1);
      if (contentContainerRef.current) contentContainerRef.current.scrollTop = 0;
    }
  };

  const fontSizeClasses = {
    sm: 'text-sm sm:text-base',
    md: 'text-base sm:text-lg',
    lg: 'text-lg sm:text-xl',
    xl: 'text-xl sm:text-2xl'
  }[fontSizeLevel];

  const readingWidthClasses = {
    standard: 'max-w-3xl',
    wide: 'max-w-4xl',
    focused: 'max-w-2xl'
  }[readingWidth];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="reader-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md animate-in fade-in"
    >
      {/* Modal Container */}
      <div className={`relative w-full max-w-6xl h-[94vh] rounded-2xl sm:rounded-3xl border border-[#3dff8f]/40 shadow-[0_0_60px_rgba(0,0,0,0.9),0_0_40px_rgba(61,255,143,0.18)] flex flex-col overflow-hidden ${activeThemeConfig.bgClass}`}>
        
        {/* Top Reading Progress Line */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-white/10 z-30">
          <div
            className="h-full bg-gradient-to-r from-[#3dff8f] via-[#f0b92e] to-[#3dff8f] transition-all duration-150"
            style={{ width: `${scrollProgress}%` }}
          />
        </div>

        {/* Top Header Bar */}
        <div className="px-3 sm:px-6 py-3 border-b border-[rgba(240,185,46,0.2)] bg-[#02140b]/90 backdrop-blur-md flex items-center justify-between gap-3 shrink-0 z-20">
          <div className="flex items-center gap-3 min-w-0">
            {/* Pen on book icon badge */}
            <div className="w-8 h-8 rounded-xl bg-[#0a351e] border border-[#3dff8f]/40 flex items-center justify-center shrink-0 text-[#3dff8f]">
              <PenOnBookIcon className="w-4 h-4 text-[#3dff8f]" />
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-[#f0b92e]/15 text-[#f0b92e] border border-[#f0b92e]/30">
                  {book.category}
                </span>
                <span className="text-[10px] font-mono text-[#9fbfae] hidden md:inline">
                  {book.pagesCount ? `${book.pagesCount} Pages` : 'Digital Edition'}
                </span>
              </div>
              <h2 id="reader-modal-title" className="text-sm sm:text-base font-bold text-[#fff1b8] font-serif-heading truncate max-w-md">
                {book.title}
              </h2>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Chapters Toggle */}
            <button
              onClick={() => setShowChaptersSidebar((prev) => !prev)}
              className={`px-2.5 py-1.5 rounded-xl text-xs font-mono flex items-center gap-1.5 transition-all cursor-pointer ${
                showChaptersSidebar
                  ? 'bg-[#3dff8f]/20 text-[#3dff8f] border border-[#3dff8f]'
                  : 'bg-white/5 text-[#9fbfae] hover:text-white border border-white/10'
              }`}
              title="Table of Contents / Chapters"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">
                Ch. {activeChapterIndex + 1}/{chapters.length}
              </span>
            </button>

            {/* Typography / Reading Theme Switcher Toggle */}
            <button
              onClick={() => setShowThemePicker((prev) => !prev)}
              className={`px-2.5 py-1.5 rounded-xl text-xs font-mono flex items-center gap-1.5 transition-all cursor-pointer ${
                showThemePicker
                  ? 'bg-[#f0b92e]/20 text-[#f0b92e] border border-[#f0b92e]'
                  : 'bg-white/5 text-[#9fbfae] hover:text-white border border-white/10'
              }`}
              title="Change Inside Book Typography Design"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span className="hidden md:inline">{activeThemeConfig.iconLabel}</span>
            </button>

            {/* Font Size Selector */}
            <div className="hidden lg:flex items-center rounded-xl bg-white/5 border border-white/10 p-0.5">
              {(['sm', 'md', 'lg'] as const).map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setFontSizeLevel(lvl)}
                  className={`px-2 py-1 text-[11px] font-mono rounded-lg transition-colors cursor-pointer ${
                    fontSizeLevel === lvl
                      ? 'bg-[#3dff8f]/20 text-[#3dff8f] font-bold'
                      : 'text-[#9fbfae] hover:text-white'
                  }`}
                >
                  {lvl.toUpperCase()}
                </button>
              ))}
            </div>

            {/* Download Button */}
            {(book.isDownloadable || book.pdfFileUrl || book.downloadUrl) && (
              <button
                onClick={handleDownload}
                className="px-3 py-1.5 rounded-xl text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] hover:from-white hover:to-[#f0b92e] flex items-center gap-1.5 transition-all cursor-pointer shadow-[0_0_15px_-3px_rgba(240,185,46,0.5)] active:scale-95"
                title="Download Book PDF / Document"
              >
                <Download className="w-3.5 h-3.5 text-[#1a1200]" />
                <span className="hidden sm:inline">
                  {book.isFreeDownload ? 'Free PDF' : 'Download'}
                </span>
              </button>
            )}

            {/* WhatsApp Direct Order Button if purchasable */}
            {!book.isFreeDownload && (
              <a
                href={
                  book.externalBuyUrls?.directWhatsApp ||
                  `https://wa.me/255655483255?text=Hello%20Dr.%20Boniphace,%20I%20would%20like%20to%20order%20your%20book:%20${encodeURIComponent(book.title)}`
                }
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-[#25D366]/20 text-[#25D366] border border-[#25D366]/40 hover:bg-[#25D366]/30 flex items-center gap-1.5 transition-all cursor-pointer"
                title="Direct Order via WhatsApp"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">
                  {book.price ? `$${book.price}` : 'Order'}
                </span>
              </a>
            )}

            {/* Like Button */}
            <button
              onClick={handleLike}
              className={`p-2 rounded-xl text-xs flex items-center gap-1 transition-all cursor-pointer ${
                hasLiked
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                  : 'bg-white/5 text-[#9fbfae] hover:text-white border border-white/10'
              }`}
              title="Like this book"
            >
              <Heart className={`w-3.5 h-3.5 ${hasLiked ? 'fill-rose-400 text-rose-400' : ''}`} />
              <span className="text-[11px] font-mono">{likesCount}</span>
            </button>

            {/* Share Button */}
            <button
              onClick={handleShare}
              className="p-2 rounded-xl text-[#9fbfae] hover:text-white bg-white/5 border border-white/10 hover:border-white/20 transition-all cursor-pointer relative"
              title="Share Book"
            >
              <Share2 className="w-3.5 h-3.5" />
              {shareToast && (
                <span className="absolute -bottom-8 right-0 text-[10px] font-mono px-2 py-0.5 rounded bg-black/95 text-[#3dff8f] border border-[#3dff8f] shadow-lg whitespace-nowrap">
                  Link Copied!
                </span>
              )}
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer ml-1"
              aria-label="Close book reader"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Theme Picker Drawer / Dropdown */}
        {showThemePicker && (
          <div className="p-4 bg-[#021008] border-b border-[rgba(240,185,46,0.2)] animate-in slide-in-from-top-2 duration-150 z-20">
            <div className="max-w-4xl mx-auto space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-[#fff1b8] uppercase font-mono flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5 text-[#3dff8f]" />
                    <span>Choose Inside Book Typography & Layout Design</span>
                  </h4>
                  <p className="text-[11px] text-[#9fbfae]">
                    Select how you want to experience reading this book. Each layout design applies custom editorial typography, margins, and paper textures.
                  </p>
                </div>
                <button
                  onClick={() => setShowThemePicker(false)}
                  className="text-xs text-[#9fbfae] hover:text-white"
                >
                  Close
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
                {THEME_OPTIONS.map((theme) => {
                  const isSelected = readingTheme === theme.id;
                  return (
                    <button
                      key={theme.id}
                      onClick={() => {
                        setReadingTheme(theme.id);
                        setShowThemePicker(false);
                      }}
                      className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#0a351e] border-[#3dff8f] shadow-[0_0_15px_rgba(61,255,143,0.25)]'
                          : 'bg-[#010904] border-white/10 hover:border-white/25'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className={`text-xs font-bold ${isSelected ? 'text-[#3dff8f]' : 'text-[#f4fff8]'}`}>
                          {theme.name}
                        </span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-[#3dff8f]" />}
                      </div>
                      <p className="text-[10px] text-[#9fbfae] line-clamp-2 leading-relaxed">
                        {theme.desc}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Main Body: Sidebar + Reading Canvas */}
        <div className="flex-1 flex overflow-hidden relative">
          
          {/* Chapter Navigation Sidebar */}
          {showChaptersSidebar && (
            <div className="w-72 sm:w-80 bg-[#021008] border-r border-[rgba(240,185,46,0.2)] p-4 overflow-y-auto shrink-0 z-10 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <h3 className="text-xs font-mono font-bold text-[#fff1b8] uppercase flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-[#3dff8f]" />
                    <span>Table of Contents ({chapters.length})</span>
                  </h3>
                  <button
                    onClick={() => setShowChaptersSidebar(false)}
                    className="text-xs text-[#9fbfae] hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-1.5">
                  {chapters.map((ch, idx) => {
                    const isCurrent = idx === activeChapterIndex;
                    return (
                      <button
                        key={ch.id || idx}
                        onClick={() => {
                          setActiveChapterIndex(idx);
                          setShowChaptersSidebar(false);
                          if (contentContainerRef.current) contentContainerRef.current.scrollTop = 0;
                        }}
                        className={`w-full p-2.5 rounded-xl text-left transition-all cursor-pointer border ${
                          isCurrent
                            ? 'bg-[#0a351e] border-[#3dff8f] text-[#3dff8f]'
                            : 'bg-white/5 border-transparent text-[#9fbfae] hover:text-white hover:bg-white/10'
                        }`}
                      >
                        <div className="text-[10px] font-mono text-[#f0b92e] mb-0.5">
                          Chapter {ch.chapterNumber || idx + 1}
                        </div>
                        <div className="text-xs font-bold line-clamp-1">
                          {ch.title}
                        </div>
                        {ch.subtitle && (
                          <div className="text-[10px] text-[#9fbfae] line-clamp-1 mt-0.5">
                            {ch.subtitle}
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Book Metadata Snapshot in Sidebar */}
              <div className="pt-4 border-t border-white/10 text-[11px] font-mono text-[#9fbfae] space-y-1">
                <div>ISBN: <span className="text-[#f4fff8]">{book.isbn || 'N/A'}</span></div>
                <div>Published: <span className="text-[#f4fff8]">{new Date(book.publishedAt).toLocaleDateString()}</span></div>
                <div>Language: <span className="text-[#f4fff8]">{book.language || 'English'}</span></div>
                <div>Reads: <span className="text-[#3dff8f]">{book.readsCount || 1}</span></div>
              </div>
            </div>
          )}

          {/* Reading Canvas */}
          <div
            ref={contentContainerRef}
            onScroll={handleScroll}
            className="flex-1 overflow-y-auto px-4 sm:px-8 lg:px-16 py-8 sm:py-12"
          >
            <div className={`mx-auto ${readingWidthClasses} space-y-8`}>
              
              {/* Book Header Profile / Title Spread */}
              <div className="p-6 sm:p-8 rounded-3xl bg-[#010c06]/80 border border-[rgba(240,185,46,0.2)] shadow-xl relative overflow-hidden">
                <div className="header-neon-line top-0" />
                
                <div className="flex flex-col sm:flex-row gap-6 items-start">
                  {/* Book Cover with Dynamic Aspect Ratio & 3D Spine Effect */}
                  <div className="w-32 sm:w-44 shrink-0 mx-auto sm:mx-0 relative group">
                    <div
                      className={`w-full rounded-xl overflow-hidden border border-[rgba(240,185,46,0.3)] shadow-[0_15px_35px_rgba(0,0,0,0.8),0_0_20px_rgba(61,255,143,0.15)] relative ${getCssAspectRatio(book.aspectRatio || '2:3')}`}
                    >
                      <img
                        src={book.coverImage}
                        alt={book.title}
                        className="w-full h-full object-cover"
                      />
                      {/* Realistic book spine gradient left overlay */}
                      <div className="absolute inset-y-0 left-0 w-3 bg-gradient-to-r from-black/70 via-black/30 to-transparent pointer-events-none" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
                    </div>
                    {/* Badge */}
                    <div className="absolute -top-2 -right-2 px-2 py-0.5 rounded-full bg-[#f0b92e] text-[#1a1200] font-mono font-bold text-[9px] shadow-md uppercase">
                      {book.isFreeDownload ? 'Free Gift' : `$${book.price || '18.50'}`}
                    </div>
                  </div>

                  {/* Book Details */}
                  <div className="flex-1 space-y-3 text-center sm:text-left">
                    <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                      <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#3dff8f]/15 text-[#3dff8f] border border-[#3dff8f]/40">
                        {book.category}
                      </span>
                      {book.formats && book.formats.map((fmt) => (
                        <span key={fmt} className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/5 text-[#9fbfae] border border-white/10">
                          {fmt}
                        </span>
                      ))}
                    </div>

                    <h1 className="text-xl sm:text-3xl font-bold font-serif-heading text-[#fff1b8] leading-tight">
                      {book.title}
                    </h1>

                    {book.subtitle && (
                      <p className="text-xs sm:text-sm text-[#3dff8f] font-medium italic">
                        {book.subtitle}
                      </p>
                    )}

                    {/* Author Stamp */}
                    <div className="pt-2 flex items-center justify-center sm:justify-start gap-3">
                      <img
                        src={book.author.avatar || 'https://via.placeholder.com/60'}
                        alt={book.author.name}
                        className="w-9 h-9 rounded-full object-cover border border-[#f0b92e]/40 p-0.5"
                      />
                      <div className="text-left">
                        <div className="text-xs font-bold text-[#f4fff8]">
                          {book.author.name}
                        </div>
                        <div className="text-[10px] text-[#9fbfae] font-mono">
                          {book.author.role || 'Author & Speaker'} • {new Date(book.publishedAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                        </div>
                      </div>
                    </div>

                    {/* Excerpt Box */}
                    {book.excerpt && (
                      <div className="mt-3 p-3.5 rounded-2xl bg-[#02140b] border border-[rgba(240,185,46,0.18)] text-xs text-[#9fbfae] italic leading-relaxed text-left">
                        <span className="text-[#f0b92e] font-bold not-italic mr-1.5 font-mono text-[11px] uppercase">
                          Synopsis Excerpt:
                        </span>
                        &ldquo;{book.excerpt}&rdquo;
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Interior Book Chapter Header */}
              <div className="text-center space-y-2 py-4 border-b border-white/10">
                <div className="flex items-center justify-center gap-2 text-xs font-mono text-[#f0b92e] uppercase tracking-wider">
                  <PenOnBookIcon className="w-3.5 h-3.5 text-[#f0b92e]" />
                  <span>Chapter {currentChapter.chapterNumber || activeChapterIndex + 1} of {chapters.length}</span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-bold font-serif-heading text-[#fff1b8]">
                  {currentChapter.title}
                </h2>
                {currentChapter.subtitle && (
                  <p className="text-xs sm:text-sm text-[#9fbfae] italic">
                    {currentChapter.subtitle}
                  </p>
                )}
              </div>

              {/* Chapter Content with Active Typography Theme */}
              <div className={`${activeThemeConfig.textClass} ${fontSizeClasses} space-y-6 select-text`}>
                {readingTheme === 'executive-dual' ? (
                  // Dual Column Layout
                  <div className="columns-1 md:columns-2 gap-8 text-justify">
                    {currentChapter.content.split('\n\n').map((paragraph, pIdx) => {
                      if (!paragraph.trim()) return null;
                      return (
                        <p key={pIdx} className="mb-4 indent-4">
                          {paragraph}
                        </p>
                      );
                    })}
                  </div>
                ) : (
                  // Single Column Classic / Modern Flow
                  <div className="space-y-6">
                    {currentChapter.content.split('\n\n').map((paragraph, pIdx) => {
                      if (!paragraph.trim()) return null;
                      const isFirst = pIdx === 0;

                      // Drop-cap on first paragraph for editorial & vintage themes
                      if (isFirst && (readingTheme === 'modern-editorial' || readingTheme === 'vintage-parchment')) {
                        const firstLetter = paragraph.charAt(0);
                        const restOfParagraph = paragraph.slice(1);
                        return (
                          <p key={pIdx} className="leading-relaxed">
                            <span className="float-left text-4xl sm:text-5xl font-serif font-bold text-[#f0b92e] mr-3 mt-1 leading-none">
                              {firstLetter}
                            </span>
                            {restOfParagraph}
                          </p>
                        );
                      }

                      return (
                        <p key={pIdx} className="leading-relaxed">
                          {paragraph}
                        </p>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Chapter Pager Navigation */}
              <div className="pt-8 border-t border-white/10 flex items-center justify-between gap-4">
                <button
                  onClick={prevChapter}
                  disabled={activeChapterIndex === 0}
                  className={`px-4 py-2 rounded-xl text-xs font-mono flex items-center gap-2 border transition-all ${
                    activeChapterIndex > 0
                      ? 'bg-white/5 border-white/20 text-[#f4fff8] hover:border-[#3dff8f] cursor-pointer'
                      : 'opacity-30 border-white/5 text-[#9fbfae] cursor-not-allowed'
                  }`}
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Previous Chapter</span>
                </button>

                <span className="text-xs font-mono text-[#9fbfae]">
                  {activeChapterIndex + 1} / {chapters.length}
                </span>

                <button
                  onClick={nextChapter}
                  disabled={activeChapterIndex === chapters.length - 1}
                  className={`px-4 py-2 rounded-xl text-xs font-mono flex items-center gap-2 border transition-all ${
                    activeChapterIndex < chapters.length - 1
                      ? 'bg-[#0a351e] border-[#3dff8f] text-[#3dff8f] hover:bg-[#0d4728] cursor-pointer'
                      : 'opacity-30 border-white/5 text-[#9fbfae] cursor-not-allowed'
                  }`}
                >
                  <span>Next Chapter</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Author Bio & Direct Order Banner */}
              <div className="p-6 rounded-3xl bg-[#010d06] border border-[#3dff8f]/30 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
                <div className="space-y-1">
                  <div className="text-xs font-bold text-[#f0b92e] uppercase font-mono">
                    About Author Ev Dr. Boniphace J. Ndege
                  </div>
                  <p className="text-xs text-[#9fbfae] max-w-xl">
                    {book.author.bio || 'Ev Dr. Boniphace J. Ndege writes extensively on modern UI/UX engineering, spiritual leadership, and transformative entrepreneurship across East Africa and globally.'}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <a
                    href={`https://wa.me/255655483255?text=Hello%20Dr.%20Boniphace,%20I%20would%20like%20to%20discuss%20your%20book%20${encodeURIComponent(book.title)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-[#25D366] text-black hover:bg-[#20ba5c] flex items-center gap-1.5 transition-all shadow-md"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp Author</span>
                  </a>
                  {(book.isDownloadable || book.downloadUrl || book.pdfFileUrl) && (
                    <button
                      onClick={handleDownload}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-[#3dff8f]/20 text-[#3dff8f] border border-[#3dff8f]/40 hover:bg-[#3dff8f]/30 flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Full Copy</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Other Books Carousel / Recommendations */}
              {allBooks.filter((b) => b.id !== book.id).length > 0 && (
                <div className="pt-6 space-y-4">
                  <h3 className="text-sm font-bold font-serif-heading text-[#fff1b8] flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-[#3dff8f]" />
                    <span>More Books by Ev Dr. Boniphace J. Ndege</span>
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {allBooks
                      .filter((b) => b.id !== book.id)
                      .slice(0, 3)
                      .map((otherBook) => (
                        <div
                          key={otherBook.id}
                          onClick={() => onSelectBook(otherBook)}
                          className="p-3 rounded-2xl bg-[#010904] border border-white/10 hover:border-[#3dff8f]/50 transition-all cursor-pointer flex items-center gap-3 group"
                        >
                          <img
                            src={otherBook.coverImage}
                            alt={otherBook.title}
                            className={`w-12 rounded-lg object-cover bg-black ${getCssAspectRatio(otherBook.aspectRatio || '2:3')}`}
                          />
                          <div className="min-w-0">
                            <span className="text-[10px] font-mono text-[#f0b92e] uppercase block truncate">
                              {otherBook.category}
                            </span>
                            <span className="text-xs font-bold text-[#f4fff8] group-hover:text-[#3dff8f] transition-colors line-clamp-1 block">
                              {otherBook.title}
                            </span>
                            <span className="text-[10px] text-[#9fbfae] font-mono block mt-0.5">
                              {otherBook.isFreeDownload ? 'Free Download' : `$${otherBook.price}`}
                            </span>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              )}

            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

import React, { useState, useRef } from 'react';
import {
  PortfolioDatabase,
  ServiceItem,
  SkillItem,
  ProjectItem,
  AIWorkflowStage,
  WorkExperienceItem,
  EducationItem,
  CertificationItem,
  AchievementItem,
  TestimonialItem,
  ContactInquiry,
  portfolioStorage
} from '../../data/portfolioStorage';
import { processImageFile } from '../../utils/imageHelper';
import {
  Lock,
  Unlock,
  X,
  LayoutDashboard,
  User,
  Palette,
  Wrench,
  FolderOpen,
  Briefcase,
  GraduationCap,
  Award,
  Sparkles,
  MessageSquare,
  Mail,
  Download,
  Upload,
  RotateCcw,
  Shield,
  Plus,
  Trash2,
  Edit,
  Save,
  Eye,
  EyeOff,
  Image as ImageIcon,
  Check,
  Search,
  ExternalLink,
  ArrowLeft,
  ChevronRight,
  Menu,
  LogOut
} from 'lucide-react';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  data: PortfolioDatabase;
  onDataChanged: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  isOpen,
  onClose,
  data,
  onDataChanged
}) => {
  const [passcode, setPasscode] = useState('');
  const [authError, setAuthError] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(portfolioStorage.isAuthenticated());

  // Active module tab
  const [activeTab, setActiveTab] = useState<
    | 'overview'
    | 'profile'
    | 'services'
    | 'skills'
    | 'projects'
    | 'categories'
    | 'experience'
    | 'education'
    | 'certifications'
    | 'testimonials'
    | 'workflow'
    | 'inquiries'
    | 'backup'
    | 'security'
  >('overview');

  // Toggle between full-screen menu view and full-screen content workspace
  const [viewMode, setViewMode] = useState<'menu' | 'content'>('menu');

  // Search filter
  const [searchQuery, setSearchQuery] = useState('');

  // Status toasts
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  if (!isOpen) return null;

  // Handle Login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (portfolioStorage.authenticate(passcode)) {
      setIsAuthenticated(true);
      setAuthError('');
      setPasscode('');
    } else {
      setAuthError('Incorrect passcode. Default is "boniphace2026" unless changed.');
    }
  };

  const handleLogout = () => {
    portfolioStorage.logout();
    setIsAuthenticated(false);
  };

  // Login Modal if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
        <div className="w-full max-w-md p-7 rounded-[24px] bg-[#02100a] border border-[#f0b92e] shadow-2xl relative text-[#f4fff8]">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-[#9fbfae] hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-12 h-12 rounded-2xl bg-[#0a351e] border border-[#f0b92e]/40 flex items-center justify-center text-[#f0b92e] mb-4">
            <Lock className="w-6 h-6" />
          </div>

          <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8] mb-1">
            Admin Management Portal
          </h3>
          <p className="text-xs text-[#9fbfae] mb-5">
            Enter your administrative passcode to manage skills, projects, services, and profile settings.
          </p>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-xs font-mono text-[#9fbfae] block mb-1">Passcode</label>
              <input
                type="password"
                required
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                placeholder="Enter passcode (default: boniphace2026)"
                className="w-full px-4 py-2.5 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.3)] text-sm text-[#f4fff8] focus:border-[#3dff8f] focus:outline-none"
                autoFocus
              />
              {authError && <p className="text-xs text-rose-400 mt-1 font-mono">{authError}</p>}
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl font-bold text-xs sm:text-sm text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] hover:from-white hover:to-[#f0b92e] cursor-pointer"
            >
              Authenticate & Open Dashboard
            </button>
            <p className="text-[11px] text-[#9fbfae] text-center font-mono">
              Default passcode: <span className="text-[#3dff8f]">boniphace2026</span>
            </p>
          </form>
        </div>
      </div>
    );
  }

  const tabModules = [
    {
      id: 'overview',
      label: 'Overview & Stats',
      icon: <LayoutDashboard className="w-5 h-5 text-[#f0b92e]" />,
      desc: 'System health, key metrics, and portfolio highlights',
      badge: `${data.projects.length} Projects`
    },
    {
      id: 'profile',
      label: 'Profile & About',
      icon: <User className="w-5 h-5 text-[#3dff8f]" />,
      desc: 'Titles, headline, bio, 1:1 square photo & logo, contact info',
      badge: data.profile.name
    },
    {
      id: 'services',
      label: 'Services Manager',
      icon: <Palette className="w-5 h-5 text-[#f0b92e]" />,
      desc: 'Services, descriptions, delivery times, and pricing settings',
      badge: `${data.services.filter((s) => s.published).length} Published`
    },
    {
      id: 'skills',
      label: 'Skills & Tools',
      icon: <Wrench className="w-5 h-5 text-[#3dff8f]" />,
      desc: 'Manual skills, categories, software tools & proficiency %',
      badge: `${data.skills.length} Skills Listed`
    },
    {
      id: 'projects',
      label: 'Projects Showcase',
      icon: <FolderOpen className="w-5 h-5 text-[#f0b92e]" />,
      desc: 'Case studies, 1:1 project cover & gallery image uploads',
      badge: `${data.projects.length} Case Studies`
    },
    {
      id: 'categories',
      label: 'Project Categories',
      icon: <FolderOpen className="w-5 h-5 text-[#3dff8f]" />,
      desc: 'Add, rename, reorder, or delete portfolio categories',
      badge: `${data.categories.length} Categories`
    },
    {
      id: 'experience',
      label: 'Work Experience',
      icon: <Briefcase className="w-5 h-5 text-[#f0b92e]" />,
      desc: 'Freelance & professional timeline entries (2022 – Present)',
      badge: `${data.workExperience.length} Positions`
    },
    {
      id: 'education',
      label: 'Education',
      icon: <GraduationCap className="w-5 h-5 text-[#3dff8f]" />,
      desc: 'Academic studies, institutions, and qualifications',
      badge: `${data.education.length} Entries`
    },
    {
      id: 'certifications',
      label: 'Certifications',
      icon: <Award className="w-5 h-5 text-[#f0b92e]" />,
      desc: 'Verified courses, achievements, and credential links',
      badge: `${data.certifications.length} Verified`
    },
    {
      id: 'workflow',
      label: 'AI Creative Workflow',
      icon: <Sparkles className="w-5 h-5 text-[#3dff8f]" />,
      desc: 'Human-in-the-loop AI stages from research to deployment',
      badge: `${data.workflowStages.length} Stages`
    },
    {
      id: 'testimonials',
      label: 'Testimonials',
      icon: <MessageSquare className="w-5 h-5 text-[#f0b92e]" />,
      desc: 'Authentic client reviews, roles, and verified feedback',
      badge: `${data.testimonials.length} Testimonials`
    },
    {
      id: 'inquiries',
      label: `Inquiries (${data.inquiries.length})`,
      icon: <Mail className="w-5 h-5 text-[#3dff8f]" />,
      desc: 'Client project briefs submitted from the contact form',
      badge: `${data.inquiries.length} Messages`
    },
    {
      id: 'backup',
      label: 'Backup & Restore',
      icon: <Download className="w-5 h-5 text-[#f0b92e]" />,
      desc: 'Export JSON data backup, import database snapshot, or reset',
      badge: 'Persistence'
    },
    {
      id: 'security',
      label: 'Passcode & Security',
      icon: <Shield className="w-5 h-5 text-[#3dff8f]" />,
      desc: 'Update admin password and manage session authentication',
      badge: 'Protected'
    }
  ];

  // Full-Screen Menu View: Side 1 appears full screen, second part hidden
  if (viewMode === 'menu') {
    return (
      <div className="fixed inset-0 z-50 w-full h-full bg-[#010703] text-[#f4fff8] flex flex-col overflow-hidden animate-in fade-in">
        {/* Top Bar: Boniphace Portfolio Admin Portal + Lock / Logout */}
        <div className="px-4 sm:px-6 py-4 bg-[#021208] border-b border-[rgba(240,185,46,0.25)] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-[#3dff8f] animate-pulse" />
            <span className="font-serif-heading font-extrabold text-base sm:text-lg text-[#fff1b8]">
              Boniphace Portfolio Admin Portal
            </span>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#0a351e] text-[#3dff8f] hidden sm:inline-block">
              Master Control
            </span>
          </div>

          <div className="flex items-center gap-3">
            {toastMessage && (
              <span className="text-xs font-mono text-[#3dff8f] bg-[#0a351e] px-3 py-1 rounded-full border border-[#3dff8f]/30">
                {toastMessage}
              </span>
            )}
            {/* Clearly Visible Log Out Button */}
            <button
              onClick={handleLogout}
              className="px-3.5 py-1.5 sm:px-4 sm:py-2 rounded-xl font-mono font-bold text-xs sm:text-sm bg-rose-500/20 text-rose-300 border border-rose-500/50 hover:bg-rose-500/30 hover:border-rose-400 flex items-center gap-2 transition-all cursor-pointer shadow-[0_0_14px_rgba(244,63,94,0.3)] active:scale-95"
              title="Log out of admin portal"
            >
              <LogOut className="w-4 h-4 text-rose-400" />
              <span>Log Out</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="Close portal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Full Menu Body: Cards reach top, down, left and right edges */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#010804] w-full h-full">
          <div className="max-w-7xl mx-auto space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-[rgba(240,185,46,0.18)]">
              <div>
                <h2 className="text-2xl sm:text-3xl font-extrabold font-serif-heading text-[#fff1b8]">
                  Admin Modules & Settings
                </h2>
                <p className="text-xs sm:text-sm text-[#9fbfae] mt-1">
                  Click any module below to open it full-screen and manage your portfolio content.
                </p>
              </div>
              <div className="text-xs font-mono text-[#3dff8f] bg-[#0a351e] px-3 py-1.5 rounded-full border border-[#3dff8f]/30 w-fit">
                {tabModules.length} Modules Available
              </div>
            </div>

            {/* Grid of Section Cards: touching edges smoothly */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {tabModules.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id as any);
                    setViewMode('content');
                  }}
                  className="p-5 rounded-2xl bg-gradient-to-br from-[#0f7a43]/20 via-[#03170d]/85 to-[#010804] border border-[rgba(240,185,46,0.22)] hover:border-[#3dff8f] hover:shadow-[0_0_28px_-6px_#3dff8f] transition-all text-left flex flex-col justify-between group cursor-pointer"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="w-10 h-10 rounded-xl bg-[#010c05] border border-[rgba(240,185,46,0.3)] flex items-center justify-center group-hover:scale-110 group-hover:border-[#3dff8f] transition-all">
                        {tab.icon}
                      </div>
                      <span className="text-[11px] font-mono font-bold text-[#f0b92e] bg-[#f0b92e]/10 px-2.5 py-0.5 rounded-full border border-[#f0b92e]/20">
                        {tab.badge}
                      </span>
                    </div>
                    <h3 className="font-serif-heading font-bold text-base sm:text-lg text-[#fff1b8] group-hover:text-[#3dff8f] transition-colors mb-1.5">
                      {tab.label}
                    </h3>
                    <p className="text-xs text-[#9fbfae] leading-relaxed">
                      {tab.desc}
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-[rgba(240,185,46,0.12)] flex items-center justify-between text-xs font-mono text-[#f0b92e] group-hover:text-[#3dff8f]">
                    <span>Open Module</span>
                    <span className="text-sm transition-transform group-hover:translate-x-1">→</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Full-Screen Content View: Pressed side appears full on screen, menu side disappears
  return (
    <div className="fixed inset-0 z-50 w-full h-full bg-[#010703] text-[#f4fff8] flex flex-col overflow-hidden animate-in fade-in">
      {/* Full-Screen Workspace Top Bar with Menu Icon Button and Clearly Visible Log Out */}
      <div className="px-4 sm:px-6 py-3.5 bg-[#021208] border-b border-[rgba(240,185,46,0.25)] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          {/* Menu icon on: button with Menu icon */}
          <button
            onClick={() => setViewMode('menu')}
            className="px-3.5 py-2 rounded-xl font-bold text-xs sm:text-sm text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] hover:from-white hover:to-[#f0b92e] shadow-[0_0_15px_-4px_rgba(240,185,46,0.6)] flex items-center gap-2 cursor-pointer active:scale-95 transition-all"
            title="Return to full admin modules menu"
          >
            <Menu className="w-4 h-4 text-[#1a1200]" />
            <span>Modules Menu</span>
          </button>

          <div className="flex items-center gap-2 pl-3 border-l border-[rgba(240,185,46,0.25)]">
            <span className="text-xs font-mono text-[#9fbfae] hidden sm:inline">Active Module:</span>
            <span className="font-serif-heading font-bold text-sm sm:text-base text-[#3dff8f] flex items-center gap-1.5">
              {tabModules.find((t) => t.id === activeTab)?.label}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          {toastMessage && (
            <span className="text-xs font-mono text-[#3dff8f] bg-[#0a351e] px-3 py-1 rounded-full border border-[#3dff8f]/30">
              {toastMessage}
            </span>
          )}

          {/* Clearly Visible Log Out Button */}
          <button
            onClick={handleLogout}
            className="px-3.5 py-1.5 sm:px-4 sm:py-2 rounded-xl font-mono font-bold text-xs sm:text-sm bg-rose-500/20 text-rose-300 border border-rose-500/50 hover:bg-rose-500/30 hover:border-rose-400 flex items-center gap-2 transition-all cursor-pointer shadow-[0_0_14px_rgba(244,63,94,0.3)] active:scale-95"
            title="Log out of admin portal"
          >
            <LogOut className="w-4 h-4 text-rose-400" />
            <span>Log Out</span>
          </button>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close portal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Full-Screen Workspace Content (Sidebar-less: occupies full viewport width) */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#010804] w-full h-full">
        <div className="w-full">
          {activeTab === 'overview' && (
            <OverviewTab
              data={data}
              onNavigate={(tab) => {
                setActiveTab(tab);
                setViewMode('content');
              }}
            />
          )}

          {activeTab === 'profile' && (
            <ProfileTab data={data} onSave={showToast} onRefresh={onDataChanged} />
          )}

          {activeTab === 'services' && (
            <ServicesTab data={data} onSave={showToast} onRefresh={onDataChanged} />
          )}

          {activeTab === 'skills' && (
            <SkillsTab data={data} onSave={showToast} onRefresh={onDataChanged} />
          )}

          {activeTab === 'projects' && (
            <ProjectsTab data={data} onSave={showToast} onRefresh={onDataChanged} />
          )}

          {activeTab === 'categories' && (
            <CategoriesTab data={data} onSave={showToast} onRefresh={onDataChanged} />
          )}

          {activeTab === 'experience' && (
            <ExperienceTab data={data} onSave={showToast} onRefresh={onDataChanged} />
          )}

          {activeTab === 'education' && (
            <EducationTab data={data} onSave={showToast} onRefresh={onDataChanged} />
          )}

          {activeTab === 'certifications' && (
            <CertificationsTab data={data} onSave={showToast} onRefresh={onDataChanged} />
          )}

          {activeTab === 'workflow' && (
            <WorkflowTab data={data} onSave={showToast} onRefresh={onDataChanged} />
          )}

          {activeTab === 'testimonials' && (
            <TestimonialsTab data={data} onSave={showToast} onRefresh={onDataChanged} />
          )}

          {activeTab === 'inquiries' && (
            <InquiriesTab data={data} onSave={showToast} onRefresh={onDataChanged} />
          )}

          {activeTab === 'backup' && (
            <BackupTab data={data} onSave={showToast} onRefresh={onDataChanged} />
          )}

          {activeTab === 'security' && (
            <SecurityTab onSave={showToast} />
          )}
        </div>
      </div>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Overview Tab                                                   */
/* -------------------------------------------------------------------------- */
const OverviewTab: React.FC<{ data: PortfolioDatabase; onNavigate: (tab: any) => void }> = ({
  data,
  onNavigate
}) => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold font-serif-heading text-[#fff1b8] mb-1">
          Welcome back, Boniphace!
        </h3>
        <p className="text-xs text-[#9fbfae]">
          Manage all sections of your creative portfolio in real-time. Changes are immediately visible on the website.
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-[#010a05] border border-[rgba(240,185,46,0.2)]">
          <div className="text-xs text-[#9fbfae] uppercase font-mono">Projects</div>
          <div className="text-2xl font-bold text-[#3dff8f] font-serif-heading mt-1">
            {data.projects.length}
          </div>
          <div className="text-[11px] text-[#9fbfae] mt-1">
            {data.projects.filter((p) => p.published).length} Published
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#010a05] border border-[rgba(240,185,46,0.2)]">
          <div className="text-xs text-[#9fbfae] uppercase font-mono">Services</div>
          <div className="text-2xl font-bold text-[#f0b92e] font-serif-heading mt-1">
            {data.services.length}
          </div>
          <div className="text-[11px] text-[#9fbfae] mt-1">
            {data.services.filter((s) => s.published).length} Active
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#010a05] border border-[rgba(240,185,46,0.2)]">
          <div className="text-xs text-[#9fbfae] uppercase font-mono">Skills & Tools</div>
          <div className="text-2xl font-bold text-[#3dff8f] font-serif-heading mt-1">
            {data.skills.length}
          </div>
          <div className="text-[11px] text-[#9fbfae] mt-1">
            Across {data.categories.length} categories
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#010a05] border border-[rgba(240,185,46,0.2)]">
          <div className="text-xs text-[#9fbfae] uppercase font-mono">Client Inquiries</div>
          <div className="text-2xl font-bold text-[#f0b92e] font-serif-heading mt-1">
            {data.inquiries.length}
          </div>
          <div className="text-[11px] text-[#9fbfae] mt-1">
            Logged from Contact form
          </div>
        </div>
      </div>

      <div className="p-6 rounded-2xl bg-[#02150b] border border-[#0f7a43]/50 space-y-3">
        <h4 className="font-bold text-[#fff1b8] text-sm">Quick Administrative Shortcuts</h4>
        <div className="flex flex-wrap gap-2.5">
          <button
            onClick={() => onNavigate('projects')}
            className="px-3.5 py-2 rounded-xl text-xs font-bold bg-[#3dff8f]/10 text-[#3dff8f] border border-[#3dff8f]/30 hover:bg-[#3dff8f]/20"
          >
            + Add New Project
          </button>
          <button
            onClick={() => onNavigate('services')}
            className="px-3.5 py-2 rounded-xl text-xs font-bold bg-[#f0b92e]/10 text-[#fff1b8] border border-[#f0b92e]/30 hover:bg-[#f0b92e]/20"
          >
            Manage Services
          </button>
          <button
            onClick={() => onNavigate('skills')}
            className="px-3.5 py-2 rounded-xl text-xs font-bold bg-white/5 text-white border border-white/10 hover:bg-white/10"
          >
            Manage Skills
          </button>
          <button
            onClick={() => onNavigate('inquiries')}
            className="px-3.5 py-2 rounded-xl text-xs font-bold bg-[#0a351e] text-[#3dff8f] border border-[#3dff8f]/30 hover:bg-[#0f7a43]"
          >
            View Messages ({data.inquiries.length})
          </button>
        </div>
      </div>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Profile Tab                                                    */
/* -------------------------------------------------------------------------- */
const ProfileTab: React.FC<{
  data: PortfolioDatabase;
  onSave: (msg: string) => void;
  onRefresh: () => void;
}> = ({ data, onSave, onRefresh }) => {
  const [profile, setProfile] = useState({ ...data.profile });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const socialUrls = [
      profile.socialLinks.linkedin,
      profile.socialLinks.instagram,
      profile.socialLinks.facebook,
      profile.socialLinks.github
    ].filter((value): value is string => Boolean(value?.trim()));
    const invalidSocialUrl = socialUrls.some((value) => {
      try {
        const parsed = new URL(value);
        return parsed.protocol !== 'https:';
      } catch {
        return true;
      }
    });
    if (invalidSocialUrl) {
      onSave('Social links must be valid HTTPS URLs.');
      return;
    }
    portfolioStorage.updateData((prev) => ({
      ...prev,
      profile
    }));
    onSave('Profile settings saved successfully!');
    onRefresh();
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await processImageFile(file, 800, 800);
      setProfile((prev) => ({ ...prev, profilePhoto: dataUrl }));
      onSave('Profile photo uploaded (1:1 square). Click "Save Profile" to apply.');
    } catch (err: any) {
      alert(err.message || 'Error processing image');
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await processImageFile(file, 800, 800);
      setProfile((prev) => ({ ...prev, logoPhoto: dataUrl }));
      onSave('Logo uploaded (1:1 square). Click "Save Profile" to apply.');
    } catch (err: any) {
      alert(err.message || 'Error processing image');
    }
  };

  return (
    <form onSubmit={handleSave} className="space-y-6 max-w-3xl">
      <div className="flex items-center justify-between pb-3 border-b border-[rgba(240,185,46,0.2)]">
        <div>
          <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
            Profile & About Information
          </h3>
          <p className="text-xs text-[#9fbfae]">
            Update your professional titles, main headline, intro, bio, and contact endpoints.
          </p>
        </div>
        <button
          type="submit"
          className="px-5 py-2 rounded-xl font-bold text-xs text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] flex items-center gap-1.5 cursor-pointer"
        >
          <Save className="w-3.5 h-3.5 text-[#1a1200]" />
          <span>Save Profile</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs font-mono text-[#9fbfae] block mb-1">Full Name</label>
          <input
            type="text"
            value={profile.name}
            onChange={(e) => setProfile({ ...profile, name: e.target.value })}
            className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs text-white"
          />
        </div>
        <div>
          <label className="text-xs font-mono text-[#9fbfae] block mb-1">Location</label>
          <input
            type="text"
            value={profile.location}
            onChange={(e) => setProfile({ ...profile, location: e.target.value })}
            className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs text-white"
          />
        </div>
      </div>

      <div>
        <label className="text-xs font-mono text-[#9fbfae] block mb-1">Primary Titles (comma separated)</label>
        <input
          type="text"
          value={profile.titles.join(', ')}
          onChange={(e) =>
            setProfile({
              ...profile,
              titles: e.target.value.split(',').map((t) => t.trim()).filter(Boolean)
            })
          }
          className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs text-white"
        />
      </div>

      <div>
        <label className="text-xs font-mono text-[#9fbfae] block mb-1">Main Headline</label>
        <input
          type="text"
          value={profile.headline}
          onChange={(e) => setProfile({ ...profile, headline: e.target.value })}
          className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs text-white"
        />
      </div>

      <div>
        <label className="text-xs font-mono text-[#9fbfae] block mb-1">Introduction Paragraph</label>
        <textarea
          rows={3}
          value={profile.intro}
          onChange={(e) => setProfile({ ...profile, intro: e.target.value })}
          className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs text-white"
        />
      </div>

      <div>
        <label className="text-xs font-mono text-[#9fbfae] block mb-1">Full Biography</label>
        <textarea
          rows={4}
          value={profile.bio}
          onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
          className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs text-white"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs font-mono text-[#9fbfae] block mb-1">Creative Approach</label>
          <textarea
            rows={3}
            value={profile.creativeApproach}
            onChange={(e) => setProfile({ ...profile, creativeApproach: e.target.value })}
            className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs text-white"
          />
        </div>
        <div>
          <label className="text-xs font-mono text-[#9fbfae] block mb-1">Design Philosophy</label>
          <textarea
            rows={3}
            value={profile.designPhilosophy}
            onChange={(e) => setProfile({ ...profile, designPhilosophy: e.target.value })}
            className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs text-white"
          />
        </div>
      </div>

      <div>
        <label className="text-xs font-mono text-[#9fbfae] block mb-1">AI Usage Statement</label>
        <textarea
          rows={3}
          value={profile.aiUsageStatement}
          onChange={(e) => setProfile({ ...profile, aiUsageStatement: e.target.value })}
          className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs text-white"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label className="text-xs font-mono text-[#9fbfae] block mb-1">Email</label>
          <input
            type="email"
            value={profile.email}
            onChange={(e) => setProfile({ ...profile, email: e.target.value })}
            className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs text-white"
          />
        </div>
        <div>
          <label className="text-xs font-mono text-[#9fbfae] block mb-1">Phone</label>
          <input
            type="text"
            value={profile.phone}
            onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
            className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs text-white"
          />
        </div>
        <div>
          <label className="text-xs font-mono text-[#9fbfae] block mb-1">WhatsApp Digits</label>
          <input
            type="text"
            value={profile.whatsapp}
            onChange={(e) => setProfile({ ...profile, whatsapp: e.target.value })}
            className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs text-white"
          />
        </div>
      </div>

      {/* Social profiles: URLs are editable and can be removed by clearing the field. */}
      <div className="p-5 rounded-2xl bg-[#010a05] border border-[rgba(240,185,46,0.25)] space-y-4">
        <div>
          <h4 className="text-sm font-bold font-serif-heading text-[#fff1b8]">Social Media Profiles</h4>
          <p className="text-xs text-[#9fbfae] mt-0.5">Add or update your public profile links. Leave a field empty to remove that social icon from the website.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[
            { key: 'linkedin', label: 'LinkedIn', placeholder: 'https://www.linkedin.com/in/your-profile' },
            { key: 'instagram', label: 'Instagram', placeholder: 'https://www.instagram.com/your-profile' },
            { key: 'facebook', label: 'Facebook', placeholder: 'https://www.facebook.com/your-profile' },
            { key: 'github', label: 'GitHub', placeholder: 'https://github.com/your-username' }
          ].map((social) => (
            <div key={social.key}>
              <label className="text-xs font-mono text-[#9fbfae] block mb-1">{social.label}</label>
              <div className="flex gap-2">
                <input
                  type="url"
                  inputMode="url"
                  placeholder={social.placeholder}
                  value={(profile.socialLinks as any)[social.key] || ''}
                  onChange={(e) => setProfile({ ...profile, socialLinks: { ...profile.socialLinks, [social.key]: e.target.value } })}
                  className="min-w-0 flex-1 px-3 py-2 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.2)] text-xs text-white"
                />
                <button
                  type="button"
                  onClick={() => setProfile({ ...profile, socialLinks: { ...profile.socialLinks, [social.key]: '' } })}
                  className="px-3 py-2 rounded-xl text-xs text-rose-300 bg-rose-500/10 border border-rose-500/30 hover:bg-rose-500/20"
                  aria-label={`Remove ${social.label} link`}
                  title={`Remove ${social.label} link`}
                >Remove</button>
              </div>
            </div>
          ))}
        </div>
        <p className="text-[10px] text-[#9fbfae]">Click “Save Profile” above or below to apply changes. Only valid HTTPS profile links should be published.</p>
      </div>

      {/* Visual Identity: Logo & Profile Photo Uploads (1:1 Square Aspect Ratio) */}
      <div className="p-5 rounded-2xl bg-[#010a05] border border-[rgba(240,185,46,0.25)] space-y-4">
        <div>
          <h4 className="text-sm font-bold font-serif-heading text-[#fff1b8] flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-[#f0b92e]" />
            <span>Brand Logo & Portfolio Profile Photo (1:1 Square Aspect Ratio)</span>
          </h4>
          <p className="text-xs text-[#9fbfae] mt-0.5">
            Upload custom 1:1 square assets for your header/footer logo and hero/about profile photos.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Logo Uploader */}
          <div className="p-4 rounded-xl bg-[#010703] border border-white/10 flex items-start gap-4">
            <div className="w-20 h-20 aspect-square rounded-2xl overflow-hidden bg-black border-2 border-[#f0b92e]/50 flex items-center justify-center p-1 shrink-0">
              <img
                src={profile.logoPhoto || profile.profilePhoto}
                alt="Logo Preview"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="space-y-1.5 flex-1 min-w-0">
              <label className="text-xs font-mono text-[#f0b92e] font-bold block">
                Website Logo (1:1 Square)
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={handleLogoUpload}
                className="text-xs text-[#9fbfae] file:mr-2 file:py-1 file:px-2.5 file:rounded-md file:border-0 file:bg-[#0a351e] file:text-[#3dff8f] file:text-xs cursor-pointer block w-full"
              />
              <span className="text-[10px] text-[#9fbfae] block">
                Square 1:1 logo displayed in header and footer.
              </span>
            </div>
          </div>

          {/* Profile Photo Uploader */}
          <div className="p-4 rounded-xl bg-[#010703] border border-white/10 flex items-start gap-4">
            <div className="w-20 h-20 aspect-square rounded-2xl overflow-hidden bg-black border-2 border-[#3dff8f]/50 flex items-center justify-center p-0.5 shrink-0">
              <img
                src={profile.profilePhoto || profile.logoPhoto}
                alt="Profile Preview"
                className="w-full h-full object-cover rounded-xl"
              />
            </div>
            <div className="space-y-1.5 flex-1 min-w-0">
              <label className="text-xs font-mono text-[#3dff8f] font-bold block">
                Profile Photo (1:1 Square)
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="text-xs text-[#9fbfae] file:mr-2 file:py-1 file:px-2.5 file:rounded-md file:border-0 file:bg-[#0a351e] file:text-[#3dff8f] file:text-xs cursor-pointer block w-full"
              />
              <span className="text-[10px] text-[#9fbfae] block">
                Square 1:1 portrait displayed in Hero and About sections.
              </span>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Services Tab                                                   */
/* -------------------------------------------------------------------------- */
const ServicesTab: React.FC<{
  data: PortfolioDatabase;
  onSave: (msg: string) => void;
  onRefresh: () => void;
}> = ({ data, onSave, onRefresh }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<ServiceItem>>({});
  const [previewService, setPreviewService] = useState<ServiceItem | null>(null);

  const [deleteTarget, setDeleteTarget] = useState<{ id: string; title: string } | null>(null);

  const handleTogglePublish = (id: string) => {
    portfolioStorage.updateData((prev) => ({
      ...prev,
      services: prev.services.map((s) => (s.id === id ? { ...s, published: !s.published } : s))
    }));
    onSave('Service updated');
    onRefresh();
  };

  const handleDelete = (id: string) => {
    portfolioStorage.updateData((prev) => ({
      ...prev,
      services: prev.services.filter((s) => s.id !== id)
    }));
    if (previewService?.id === id) setPreviewService(null);
    onSave('Service deleted successfully');
    onRefresh();
  };

  const handleStartEdit = (service: ServiceItem) => {
    setEditingId(service.id);
    setEditForm({ ...service });
  };

  const handleSaveEdit = () => {
    if (!editForm.title?.trim()) return;

    portfolioStorage.updateData((prev) => ({
      ...prev,
      services: prev.services.map((s) => (s.id === editingId ? ({ ...s, ...editForm } as ServiceItem) : s))
    }));

    setEditingId(null);
    onSave('Service updated successfully');
    onRefresh();
  };

  const handleCreateNew = () => {
    const newService: ServiceItem = {
      id: 'srv-' + Date.now(),
      title: 'New Creative Service',
      description: 'Describe what you deliver for clients...',
      category: 'Graphic Design',
      availability: 'Available',
      published: true,
      order: data.services.length + 1
    };

    portfolioStorage.updateData((prev) => ({
      ...prev,
      services: [newService, ...prev.services]
    }));

    setEditingId(newService.id);
    setEditForm(newService);
    onSave('New service added');
    onRefresh();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between pb-3 border-b border-[rgba(240,185,46,0.2)]">
        <div>
          <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
            Services Management ({data.services.length})
          </h3>
          <p className="text-xs text-[#9fbfae]">
            Add, edit, reorder, publish, or delete your client services.
          </p>
        </div>
        <button
          onClick={handleCreateNew}
          className="px-4 py-2 rounded-xl text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] flex items-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5 text-[#1a1200]" />
          <span>Add Service</span>
        </button>
      </div>

      {editingId && (
        <div className="p-5 rounded-2xl bg-[#010e06] border border-[#3dff8f] space-y-4">
          <div className="flex justify-between items-center text-xs font-mono text-[#3dff8f]">
            <span>Editing Service Details</span>
            <button onClick={() => setEditingId(null)} className="text-white hover:text-rose-400">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Title</label>
              <input
                type="text"
                value={editForm.title || ''}
                onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Category</label>
              <input
                type="text"
                value={editForm.category || ''}
                onChange={(e) => setEditForm({ ...editForm, category: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-[#9fbfae] block mb-1">Description</label>
            <textarea
              rows={3}
              value={editForm.description || ''}
              onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Optional Price Guide</label>
              <input
                type="text"
                placeholder="e.g. Starting from $150"
                value={editForm.price || ''}
                onChange={(e) => setEditForm({ ...editForm, price: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Optional Delivery Time</label>
              <input
                type="text"
                placeholder="e.g. 3-5 Business Days"
                value={editForm.deliveryEstimate || ''}
                onChange={(e) => setEditForm({ ...editForm, deliveryEstimate: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Availability</label>
              <select
                value={editForm.availability || 'Available'}
                onChange={(e) => setEditForm({ ...editForm, availability: e.target.value as any })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              >
                <option value="Available">Available</option>
                <option value="Limited Slots">Limited Slots</option>
                <option value="Booked">Booked</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={() => setEditingId(null)}
              className="px-4 py-1.5 rounded-lg text-xs font-mono border border-white/20"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveEdit}
              className="px-4 py-1.5 rounded-lg text-xs font-bold bg-[#3dff8f] text-black"
            >
              Save Changes
            </button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {data.services.map((service) => (
          <div
            key={service.id}
            className="p-4 sm:p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.18)] hover:border-[#3dff8f]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all"
          >
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-sm sm:text-base text-[#fff1b8]">{service.title}</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0a351e] text-[#3dff8f]">
                  {service.category}
                </span>
                {!service.published ? (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300">
                    Draft
                  </span>
                ) : (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#3dff8f]/10 text-[#3dff8f]">
                    Live
                  </span>
                )}
              </div>
              <p className="text-xs text-[#9fbfae] mt-1.5 line-clamp-2">{service.description}</p>
              {(service.price || service.deliveryEstimate) && (
                <div className="text-[11px] font-mono text-[#f0b92e] mt-1.5 flex gap-3">
                  {service.price && <span>{service.price}</span>}
                  {service.deliveryEstimate && <span>· {service.deliveryEstimate}</span>}
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-white/5">
              <button
                onClick={() => setPreviewService(service)}
                className="px-2.5 py-1.5 rounded-xl text-xs text-[#3dff8f] bg-[#3dff8f]/10 hover:bg-[#3dff8f]/20 border border-[#3dff8f]/30 transition-all cursor-pointer flex items-center gap-1.5"
                title="View Service Details & Preview"
              >
                <Eye className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">View</span>
              </button>
              <button
                onClick={() => handleStartEdit(service)}
                className="px-2.5 py-1.5 rounded-xl text-xs text-[#9fbfae] bg-white/5 hover:text-[#f0b92e] hover:border-[#f0b92e]/40 border border-white/10 transition-all cursor-pointer flex items-center gap-1.5"
                title="Edit Service Details"
              >
                <Edit className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">Edit</span>
              </button>
              <button
                onClick={() => setDeleteTarget({ id: service.id, title: service.title })}
                className="px-2.5 py-1.5 rounded-xl text-xs text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-all cursor-pointer flex items-center gap-1.5"
                title="Delete Service"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">Delete</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Service Preview Modal */}
      {previewService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-[#010e06] border border-[#3dff8f] p-6 space-y-4 text-[#f4fff8] relative shadow-2xl">
            <button
              onClick={() => setPreviewService(null)}
              className="absolute top-5 right-5 text-[#9fbfae] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#3dff8f]/15 text-[#3dff8f] border border-[#3dff8f]/30">
                {previewService.category}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/10 text-[#fff1b8]">
                {previewService.availability || 'Available'}
              </span>
            </div>

            <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
              {previewService.title}
            </h3>

            <p className="text-xs sm:text-sm text-[#9fbfae] leading-relaxed p-4 rounded-xl bg-[#010904] border border-white/10">
              {previewService.description}
            </p>

            <div className="grid grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-3 rounded-xl bg-[#02140b] border border-[rgba(240,185,46,0.2)]">
                <span className="text-[#9fbfae] block text-[10px]">Pricing Guide:</span>
                <span className="text-[#f0b92e] font-bold">{previewService.price || 'Custom Quote'}</span>
              </div>
              <div className="p-3 rounded-xl bg-[#02140b] border border-[rgba(240,185,46,0.2)]">
                <span className="text-[#9fbfae] block text-[10px]">Delivery Estimate:</span>
                <span className="text-[#3dff8f] font-bold">{previewService.deliveryEstimate || 'Based on scope'}</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-white/10">
              <button
                onClick={() => {
                  handleTogglePublish(previewService.id);
                  setPreviewService({ ...previewService, published: !previewService.published });
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer ${
                  previewService.published ? 'bg-[#3dff8f]/20 text-[#3dff8f] border border-[#3dff8f]/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                }`}
              >
                {previewService.published ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{previewService.published ? 'Status: Live (Click to Draft)' : 'Status: Draft (Click to Publish)'}</span>
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const toDelete = previewService;
                    setPreviewService(null);
                    setDeleteTarget({ id: toDelete.id, title: toDelete.title });
                  }}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30 flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
                <button
                  onClick={() => {
                    const toEdit = previewService;
                    setPreviewService(null);
                    handleStartEdit(toEdit);
                  }}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-[#f0b92e] text-black cursor-pointer"
                >
                  Edit This Service
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* In-App Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm p-6 rounded-2xl bg-[#02100a] border border-rose-500/60 shadow-[0_0_40px_rgba(244,63,94,0.35)] space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-[#fff1b8]">Delete Service?</h4>
              <p className="text-xs text-[#9fbfae] mt-1 leading-relaxed">
                Are you sure you want to delete <span className="text-rose-300 font-bold">"{deleteTarget.title}"</span>?
              </p>
            </div>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2 px-3 rounded-xl border border-white/20 text-xs text-[#9fbfae] hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleDelete(deleteTarget.id);
                  setDeleteTarget(null);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-600 transition-all cursor-pointer shadow-lg"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Skills Tab                                                     */
/* -------------------------------------------------------------------------- */
const SkillsTab: React.FC<{
  data: PortfolioDatabase;
  onSave: (msg: string) => void;
  onRefresh: () => void;
}> = ({ data, onSave, onRefresh }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<SkillItem>>({});
  const [previewSkill, setPreviewSkill] = useState<SkillItem | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; name: string } | null>(null);

  const handleTogglePublish = (id: string) => {
    portfolioStorage.updateData((prev) => ({
      ...prev,
      skills: prev.skills.map((s) => (s.id === id ? { ...s, published: !s.published } : s))
    }));
    onSave('Skill status updated');
    onRefresh();
  };

  const handleCreateNew = () => {
    const newSkill: SkillItem = {
      id: 'sk-' + Date.now(),
      name: 'New Creative Skill',
      category: 'Graphic Design',
      shortDescription: '',
      tools: ['Photoshop', 'Illustrator'],
      proficiency: 85,
      published: true,
      order: data.skills.length + 1
    };

    portfolioStorage.updateData((prev) => ({
      ...prev,
      skills: [newSkill, ...prev.skills]
    }));

    setEditingId(newSkill.id);
    setEditForm(newSkill);
    onSave('New skill added');
    onRefresh();
  };

  const handleSaveEdit = () => {
    if (!editForm.name?.trim()) return;

    portfolioStorage.updateData((prev) => ({
      ...prev,
      skills: prev.skills.map((s) => (s.id === editingId ? ({ ...s, ...editForm } as SkillItem) : s))
    }));

    setEditingId(null);
    onSave('Skill updated successfully');
    onRefresh();
  };

  const handleDelete = (id: string) => {
    portfolioStorage.updateData((prev) => ({
      ...prev,
      skills: prev.skills.filter((s) => s.id !== id)
    }));
    if (previewSkill?.id === id) setPreviewSkill(null);
    onSave('Skill deleted successfully');
    onRefresh();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between pb-3 border-b border-[rgba(240,185,46,0.2)]">
        <div>
          <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
            Skills & Tools Management ({data.skills.length})
          </h3>
          <p className="text-xs text-[#9fbfae]">
            Add, update, or remove skills with self-selected proficiencies and tools.
          </p>
        </div>
        <button
          onClick={handleCreateNew}
          className="px-4 py-2 rounded-xl text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] flex items-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5 text-[#1a1200]" />
          <span>Add Skill</span>
        </button>
      </div>

      {editingId && (
        <div className="p-5 rounded-2xl bg-[#010e06] border border-[#3dff8f] space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Skill Name</label>
              <input
                type="text"
                value={editForm.name || ''}
                onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Category</label>
              <input
                type="text"
                value={editForm.category || ''}
                onChange={(e) => setEditForm({ ...editForm, category: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-[#9fbfae] block mb-1">Short Description</label>
            <input
              type="text"
              value={editForm.shortDescription || ''}
              onChange={(e) => setEditForm({ ...editForm, shortDescription: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
            />
          </div>

          <div>
            <label className="text-xs text-[#9fbfae] block mb-1">Software / Tools (comma separated)</label>
            <input
              type="text"
              value={(editForm.tools || []).join(', ')}
              onChange={(e) =>
                setEditForm({
                  ...editForm,
                  tools: e.target.value.split(',').map((t) => t.trim()).filter(Boolean)
                })
              }
              className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
            />
          </div>

          <div>
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-[#9fbfae]">Self-Assessed Proficiency: {editForm.proficiency || 0}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={editForm.proficiency || 0}
              onChange={(e) => setEditForm({ ...editForm, proficiency: Number(e.target.value) })}
              className="w-full accent-[#3dff8f]"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button onClick={() => setEditingId(null)} className="px-4 py-1.5 rounded-lg text-xs border border-white/20">
              Cancel
            </button>
            <button onClick={handleSaveEdit} className="px-4 py-1.5 rounded-lg text-xs font-bold bg-[#3dff8f] text-black">
              Save Skill
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {data.skills.map((skill) => (
          <div
            key={skill.id}
            className="p-4 sm:p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.18)] hover:border-[#3dff8f]/40 flex items-center justify-between gap-3 transition-all"
          >
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-[#fff1b8] truncate">{skill.name}</span>
                {!skill.published && (
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-rose-950 text-rose-300">
                    Draft
                  </span>
                )}
              </div>
              <div className="text-[11px] text-[#3dff8f] font-mono mt-0.5">
                {skill.category} · {skill.proficiency}%
              </div>
              {skill.tools && (
                <div className="text-[10px] text-[#9fbfae] mt-1 line-clamp-1">{skill.tools.join(', ')}</div>
              )}
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={() => setPreviewSkill(skill)}
                className="p-2 rounded-xl text-xs text-[#3dff8f] bg-[#3dff8f]/10 hover:bg-[#3dff8f]/20 border border-[#3dff8f]/30 transition-all cursor-pointer flex items-center gap-1"
                title="View Skill Details & Preview"
              >
                <Eye className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px] hidden sm:inline">View</span>
              </button>
              <button
                onClick={() => {
                  setEditingId(skill.id);
                  setEditForm(skill);
                }}
                className="p-2 rounded-xl text-xs text-[#9fbfae] bg-white/5 hover:text-[#f0b92e] hover:border-[#f0b92e]/40 border border-white/10 transition-all cursor-pointer flex items-center gap-1"
                title="Edit Skill Details"
              >
                <Edit className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px] hidden sm:inline">Edit</span>
              </button>
              <button
                onClick={() => setDeleteTarget({ id: skill.id, name: skill.name })}
                className="p-2 rounded-xl text-xs text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-all cursor-pointer flex items-center gap-1"
                title="Delete Skill"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px] hidden sm:inline">Delete</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Skill Preview Modal */}
      {previewSkill && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-[#010e06] border border-[#3dff8f] p-6 space-y-4 text-[#f4fff8] relative shadow-2xl">
            <button
              onClick={() => setPreviewSkill(null)}
              className="absolute top-5 right-5 text-[#9fbfae] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#3dff8f]/15 text-[#3dff8f] border border-[#3dff8f]/30">
                {previewSkill.category}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#f0b92e]/10 text-[#fff1b8]">
                Proficiency: {previewSkill.proficiency}%
              </span>
            </div>

            <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
              {previewSkill.name}
            </h3>

            {/* Proficiency Meter */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono text-[#9fbfae]">
                <span>Competency Level</span>
                <span className="text-[#3dff8f] font-bold">{previewSkill.proficiency}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-[#02180c] overflow-hidden border border-white/10">
                <div
                  className="h-full bg-gradient-to-r from-[#0f7a43] to-[#3dff8f] rounded-full"
                  style={{ width: `${previewSkill.proficiency || 50}%` }}
                />
              </div>
            </div>

            {previewSkill.tools && previewSkill.tools.length > 0 && (
              <div>
                <span className="text-[10px] font-mono text-[#f0b92e] uppercase block mb-1.5">
                  Software & Tools Stack:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {previewSkill.tools.map((t) => (
                    <span
                      key={t}
                      className="px-2.5 py-1 rounded-lg bg-[#010904] border border-white/10 text-xs text-[#f4fff8]"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {previewSkill.shortDescription && (
              <p className="text-xs text-[#9fbfae] leading-relaxed p-3.5 rounded-xl bg-[#010904] border border-white/10">
                {previewSkill.shortDescription}
              </p>
            )}

            <div className="flex items-center justify-between pt-3 border-t border-white/10">
              <button
                onClick={() => {
                  handleTogglePublish(previewSkill.id);
                  setPreviewSkill({ ...previewSkill, published: !previewSkill.published });
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer ${
                  previewSkill.published ? 'bg-[#3dff8f]/20 text-[#3dff8f] border border-[#3dff8f]/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                }`}
              >
                {previewSkill.published ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{previewSkill.published ? 'Live on Site' : 'Draft / Hidden'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const toDelete = previewSkill;
                    setPreviewSkill(null);
                    setDeleteTarget({ id: toDelete.id, name: toDelete.name });
                  }}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30 flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
                <button
                  onClick={() => {
                    const toEdit = previewSkill;
                    setPreviewSkill(null);
                    setEditingId(toEdit.id);
                    setEditForm(toEdit);
                  }}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-[#f0b92e] text-black cursor-pointer"
                >
                  Edit Skill
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* In-App Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm p-6 rounded-2xl bg-[#02100a] border border-rose-500/60 shadow-[0_0_40px_rgba(244,63,94,0.35)] space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-[#fff1b8]">Delete Skill?</h4>
              <p className="text-xs text-[#9fbfae] mt-1 leading-relaxed">
                Are you sure you want to delete <span className="text-rose-300 font-bold">"{deleteTarget.name}"</span>?
              </p>
            </div>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2 px-3 rounded-xl border border-white/20 text-xs text-[#9fbfae] hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleDelete(deleteTarget.id);
                  setDeleteTarget(null);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-600 transition-all cursor-pointer shadow-lg"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Projects Tab (Full Image Upload & Media Management)             */
/* -------------------------------------------------------------------------- */
const ProjectsTab: React.FC<{
  data: PortfolioDatabase;
  onSave: (msg: string) => void;
  onRefresh: () => void;
}> = ({ data, onSave, onRefresh }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [projectForm, setProjectForm] = useState<Partial<ProjectItem>>({});
  const [previewProject, setPreviewProject] = useState<ProjectItem | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; title: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleCreateNew = () => {
    const newProject: ProjectItem = {
      id: 'prj-' + Date.now(),
      slug: 'new-creative-project-' + Date.now(),
      title: 'New Creative Project',
      summary: 'Short summary of the project and key deliverable...',
      fullDescription: 'Detailed background, objectives, and creative solution...',
      category: data.categories[0] || 'Graphic Design',
      thumbnail: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?auto=format&fit=crop&w=800&q=80',
      gallery: [],
      status: 'completed',
      projectType: 'personal',
      role: 'Lead Designer',
      tools: ['Adobe Illustrator', 'Photoshop'],
      aiUsed: ['Gemini'],
      mainChallenge: 'Describe the main design or technical challenge...',
      solution: 'How you solved it...',
      outcome: 'What was achieved or learned...',
      featured: false,
      published: true,
      order: data.projects.length + 1
    };

    portfolioStorage.updateData((prev) => ({
      ...prev,
      projects: [newProject, ...prev.projects]
    }));

    setEditingId(newProject.id);
    setProjectForm(newProject);
    onSave('New project draft created');
    onRefresh();
  };

  const handleSaveProject = () => {
    if (!projectForm.title?.trim()) return;

    portfolioStorage.updateData((prev) => ({
      ...prev,
      projects: prev.projects.map((p) => (p.id === editingId ? ({ ...p, ...projectForm } as ProjectItem) : p))
    }));

    setEditingId(null);
    onSave('Project saved successfully');
    onRefresh();
  };

  const handleDeleteProject = (id: string) => {
    portfolioStorage.updateData((prev) => ({
      ...prev,
      projects: prev.projects.filter((p) => p.id !== id)
    }));
    if (previewProject?.id === id) setPreviewProject(null);
    onSave('Project deleted successfully');
    onRefresh();
  };

  const handleThumbnailUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await processImageFile(file, 800, 800);
      setProjectForm((prev) => ({ ...prev, thumbnail: dataUrl }));
      onSave('Cover image (1:1 square) uploaded!');
    } catch (err: any) {
      alert(err.message || 'Error processing image');
    }
  };

  const handleGalleryUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newGallery = [...(projectForm.gallery || [])];

    for (let i = 0; i < files.length; i++) {
      try {
        const dataUrl = await processImageFile(files[i], 800, 800);
        newGallery.push(dataUrl);
      } catch (err) {
        console.error('Failed to process gallery file', err);
      }
    }

    setProjectForm((prev) => ({ ...prev, gallery: newGallery }));
    onSave(`${files.length} image(s) added to gallery`);
  };

  const removeGalleryImage = (idx: number) => {
    setProjectForm((prev) => ({
      ...prev,
      gallery: (prev.gallery || []).filter((_, i) => i !== idx)
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between pb-3 border-b border-[rgba(240,185,46,0.2)]">
        <div>
          <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
            Projects Showcase Management ({data.projects.length})
          </h3>
          <p className="text-xs text-[#9fbfae]">
            Create, edit, upload local images, set project status, and publish portfolio case studies.
          </p>
        </div>
        <button
          onClick={handleCreateNew}
          className="px-4 py-2 rounded-xl text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] flex items-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5 text-[#1a1200]" />
          <span>Add Project</span>
        </button>
      </div>

      {editingId && (
        <div className="p-6 rounded-2xl bg-[#010e06] border border-[#3dff8f] space-y-5">
          <div className="flex justify-between items-center pb-3 border-b border-white/10">
            <span className="text-sm font-bold text-[#3dff8f] font-serif-heading">
              Editing: {projectForm.title}
            </span>
            <button onClick={() => setEditingId(null)} className="text-[#9fbfae] hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Project Title *</label>
              <input
                type="text"
                value={projectForm.title || ''}
                onChange={(e) => setProjectForm({ ...projectForm, title: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Category</label>
              <select
                value={projectForm.category || ''}
                onChange={(e) => setProjectForm({ ...projectForm, category: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              >
                {data.categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs text-[#9fbfae] block mb-1">Short Summary</label>
            <input
              type="text"
              value={projectForm.summary || ''}
              onChange={(e) => setProjectForm({ ...projectForm, summary: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
            />
          </div>

          <div>
            <label className="text-xs text-[#9fbfae] block mb-1">Full Description & Story</label>
            <textarea
              rows={4}
              value={projectForm.fullDescription || ''}
              onChange={(e) => setProjectForm({ ...projectForm, fullDescription: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
            />
          </div>

          {/* Image Upload Area - 1:1 Square Ratio */}
          <div className="p-4 rounded-xl bg-[#010804] border border-white/10 space-y-4">
            <div>
              <label className="text-xs font-mono font-bold text-[#f0b92e] block mb-1">
                Project Cover / Thumbnail (1:1 Square Aspect Ratio)
              </label>
              <div className="flex items-center gap-4">
                <img
                  src={projectForm.thumbnail}
                  alt="Thumbnail Preview"
                  className="w-20 h-20 aspect-square rounded-xl object-cover border border-[#f0b92e]/40 bg-black shrink-0"
                />
                <div className="space-y-1">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleThumbnailUpload}
                    className="text-xs text-[#9fbfae] file:mr-2 file:py-1 file:px-2.5 file:rounded-md file:border-0 file:bg-[#0a351e] file:text-[#3dff8f] file:text-xs cursor-pointer"
                  />
                  <p className="text-[10px] text-[#9fbfae]">Upload 1:1 square image (PNG, JPG, or WebP). Displayed on project cards and modals.</p>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-white/5">
              <label className="text-xs font-mono font-bold text-[#3dff8f] block mb-1">
                Project Gallery Images (1:1 Square Aspect Ratio, Upload Multiple)
              </label>
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleGalleryUpload}
                className="text-xs text-[#9fbfae] file:mr-2 file:py-1 file:px-2.5 file:rounded-md file:border-0 file:bg-[#0a351e] file:text-[#3dff8f] file:text-xs cursor-pointer mb-2"
              />
              <div className="flex flex-wrap gap-2.5">
                {(projectForm.gallery || []).map((img, idx) => (
                  <div key={idx} className="relative w-18 h-18 aspect-square rounded-xl overflow-hidden border border-white/20 group shrink-0">
                    <img src={img} alt="" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => removeGalleryImage(idx)}
                      className="absolute inset-0 bg-black/70 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-rose-400"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Project Status</label>
              <select
                value={projectForm.status || 'completed'}
                onChange={(e) => setProjectForm({ ...projectForm, status: e.target.value as any })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              >
                <option value="completed">Completed</option>
                <option value="in_progress">In Progress</option>
                <option value="prototype">Prototype</option>
                <option value="concept">Concept</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Project Type</label>
              <select
                value={projectForm.projectType || 'personal'}
                onChange={(e) => setProjectForm({ ...projectForm, projectType: e.target.value as any })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              >
                <option value="personal">Personal Project</option>
                <option value="client">Client Work</option>
                <option value="freelance">Freelance</option>
                <option value="concept">Design Concept</option>
                <option value="prototype">Prototype</option>
                <option value="experimental">Experimental</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">My Role</label>
              <input
                type="text"
                value={projectForm.role || ''}
                onChange={(e) => setProjectForm({ ...projectForm, role: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Tools (comma separated)</label>
              <input
                type="text"
                value={(projectForm.tools || []).join(', ')}
                onChange={(e) =>
                  setProjectForm({
                    ...projectForm,
                    tools: e.target.value.split(',').map((t) => t.trim()).filter(Boolean)
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">AI Tools Used (comma separated)</label>
              <input
                type="text"
                value={(projectForm.aiUsed || []).join(', ')}
                onChange={(e) =>
                  setProjectForm({
                    ...projectForm,
                    aiUsed: e.target.value.split(',').map((t) => t.trim()).filter(Boolean)
                  })
                }
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">The Challenge</label>
              <textarea
                rows={2}
                value={projectForm.mainChallenge || ''}
                onChange={(e) => setProjectForm({ ...projectForm, mainChallenge: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">The Solution</label>
              <textarea
                rows={2}
                value={projectForm.solution || ''}
                onChange={(e) => setProjectForm({ ...projectForm, solution: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Outcome / Learning</label>
              <textarea
                rows={2}
                value={projectForm.outcome || ''}
                onChange={(e) => setProjectForm({ ...projectForm, outcome: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Live URL (optional)</label>
              <input
                type="url"
                value={projectForm.liveUrl || ''}
                onChange={(e) => setProjectForm({ ...projectForm, liveUrl: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">GitHub / Source URL (optional)</label>
              <input
                type="url"
                value={projectForm.githubUrl || ''}
                onChange={(e) => setProjectForm({ ...projectForm, githubUrl: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
          </div>

          <div className="flex items-center gap-6 pt-2">
            <label className="flex items-center gap-2 text-xs text-white cursor-pointer">
              <input
                type="checkbox"
                checked={projectForm.featured || false}
                onChange={(e) => setProjectForm({ ...projectForm, featured: e.target.checked })}
                className="accent-[#f0b92e]"
              />
              <span>Mark as Featured Project</span>
            </label>
            <label className="flex items-center gap-2 text-xs text-white cursor-pointer">
              <input
                type="checkbox"
                checked={projectForm.published || false}
                onChange={(e) => setProjectForm({ ...projectForm, published: e.target.checked })}
                className="accent-[#3dff8f]"
              />
              <span>Publish to Portfolio Website</span>
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-white/10">
            <button onClick={() => setEditingId(null)} className="px-4 py-2 rounded-lg text-xs border border-white/20">
              Cancel
            </button>
            <button
              onClick={handleSaveProject}
              className="px-5 py-2 rounded-lg text-xs font-bold bg-[#3dff8f] text-black"
            >
              Save Project
            </button>
          </div>
        </div>
      )}

      {/* Projects List */}
      <div className="space-y-3">
        {data.projects.map((project) => (
          <div
            key={project.id}
            className="p-4 sm:p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.18)] hover:border-[#3dff8f]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <img
                src={project.thumbnail}
                alt={project.title}
                className="w-16 h-16 aspect-square rounded-2xl object-cover bg-black border border-white/10 shrink-0"
              />
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-sm sm:text-base text-[#fff1b8] truncate">{project.title}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0a351e] text-[#3dff8f]">
                    {project.category}
                  </span>
                  {project.featured && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#f0b92e]/20 text-[#fff1b8]">
                      Featured
                    </span>
                  )}
                  {!project.published ? (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300">
                      Draft
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#3dff8f]/10 text-[#3dff8f]">
                      Live
                    </span>
                  )}
                </div>
                <div className="text-xs text-[#9fbfae] mt-1 line-clamp-1">
                  Type: {project.projectType} · Tools: {project.tools.join(', ')}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-white/5">
              <button
                onClick={() => setPreviewProject(project)}
                className="px-2.5 py-1.5 rounded-xl text-xs text-[#3dff8f] bg-[#3dff8f]/10 hover:bg-[#3dff8f]/20 border border-[#3dff8f]/30 transition-all cursor-pointer flex items-center gap-1.5"
                title="View Full Project Case Study & Preview"
              >
                <Eye className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">View</span>
              </button>
              <button
                onClick={() => {
                  setEditingId(project.id);
                  setProjectForm(project);
                }}
                className="px-2.5 py-1.5 rounded-xl text-xs text-[#9fbfae] bg-white/5 hover:text-[#f0b92e] hover:border-[#f0b92e]/40 border border-white/10 transition-all cursor-pointer flex items-center gap-1.5"
                title="Edit Project Details"
              >
                <Edit className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">Edit</span>
              </button>
              <button
                onClick={() => setDeleteTarget({ id: project.id, title: project.title })}
                className="px-2.5 py-1.5 rounded-xl text-xs text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-all cursor-pointer flex items-center gap-1.5"
                title="Delete Project"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">Delete</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Project Full Preview Modal */}
      {previewProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-2xl max-h-[90vh] rounded-3xl bg-[#010e06] border border-[#3dff8f] p-6 space-y-4 text-[#f4fff8] relative shadow-2xl overflow-y-auto">
            <button
              onClick={() => setPreviewProject(null)}
              className="absolute top-5 right-5 text-[#9fbfae] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#3dff8f]/15 text-[#3dff8f] border border-[#3dff8f]/30">
                {previewProject.category}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/10 text-[#fff1b8]">
                {previewProject.projectType}
              </span>
              {previewProject.featured && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#f0b92e]/20 text-[#fff1b8]">
                  Featured
                </span>
              )}
            </div>

            <h3 className="text-2xl font-bold font-serif-heading text-[#fff1b8]">
              {previewProject.title}
            </h3>

            {/* 1:1 Square Thumbnail */}
            <div className="w-full max-w-xs aspect-square rounded-2xl overflow-hidden border border-white/10 bg-black">
              <img
                src={previewProject.thumbnail}
                alt={previewProject.title}
                className="w-full h-full object-cover"
              />
            </div>

            <p className="text-xs sm:text-sm text-[#9fbfae] leading-relaxed">
              {previewProject.summary}
            </p>

            {previewProject.fullDescription && (
              <div className="p-4 rounded-xl bg-[#010904] border border-white/10 text-xs text-[#f4fff8] leading-relaxed">
                <span className="text-[10px] font-mono text-[#3dff8f] uppercase block mb-1">
                  Full Story & Background:
                </span>
                {previewProject.fullDescription}
              </div>
            )}

            {/* Tools Stack */}
            <div>
              <span className="text-[10px] font-mono text-[#f0b92e] uppercase block mb-1.5">
                Tools & Technologies:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {previewProject.tools.map((t) => (
                  <span
                    key={t}
                    className="px-2.5 py-1 rounded-lg bg-[#010904] border border-white/10 text-xs text-[#f4fff8]"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-white/10">
              <button
                onClick={() => {
                  portfolioStorage.updateData((prev) => ({
                    ...prev,
                    projects: prev.projects.map((p) => (p.id === previewProject.id ? { ...p, published: !p.published } : p))
                  }));
                  setPreviewProject({ ...previewProject, published: !previewProject.published });
                  onSave('Publish status updated');
                  onRefresh();
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer ${
                  previewProject.published ? 'bg-[#3dff8f]/20 text-[#3dff8f] border border-[#3dff8f]/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                }`}
              >
                {previewProject.published ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{previewProject.published ? 'Status: Live on Website' : 'Status: Draft / Hidden'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const toDelete = previewProject;
                    setPreviewProject(null);
                    setDeleteTarget({ id: toDelete.id, title: toDelete.title });
                  }}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30 flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
                <button
                  onClick={() => {
                    const toEdit = previewProject;
                    setPreviewProject(null);
                    setEditingId(toEdit.id);
                    setProjectForm(toEdit);
                  }}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-[#f0b92e] text-black cursor-pointer"
                >
                  Edit Case Study
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* In-App Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm p-6 rounded-2xl bg-[#02100a] border border-rose-500/60 shadow-[0_0_40px_rgba(244,63,94,0.35)] space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-[#fff1b8]">Delete Project?</h4>
              <p className="text-xs text-[#9fbfae] mt-1 leading-relaxed">
                Are you sure you want to delete <span className="text-rose-300 font-bold">"{deleteTarget.title}"</span>?
              </p>
            </div>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2 px-3 rounded-xl border border-white/20 text-xs text-[#9fbfae] hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleDeleteProject(deleteTarget.id);
                  setDeleteTarget(null);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-600 transition-all cursor-pointer shadow-lg"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Project Categories Tab                                         */
/* -------------------------------------------------------------------------- */
const CategoriesTab: React.FC<{
  data: PortfolioDatabase;
  onSave: (msg: string) => void;
  onRefresh: () => void;
}> = ({ data, onSave, onRefresh }) => {
  const [newCat, setNewCat] = useState('');
  const [editingCat, setEditingCat] = useState<string | null>(null);
  const [renameVal, setRenameVal] = useState('');
  const [previewCat, setPreviewCat] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCat.trim() || data.categories.includes(newCat.trim())) return;

    portfolioStorage.updateData((prev) => ({
      ...prev,
      categories: [...prev.categories, newCat.trim()]
    }));

    setNewCat('');
    onSave('Category added');
    onRefresh();
  };

  const handleSaveRename = (oldName: string) => {
    if (!renameVal.trim() || renameVal.trim() === oldName) {
      setEditingCat(null);
      return;
    }

    portfolioStorage.updateData((prev) => ({
      ...prev,
      categories: prev.categories.map((c) => (c === oldName ? renameVal.trim() : c)),
      projects: prev.projects.map((p) => (p.category === oldName ? { ...p, category: renameVal.trim() } : p))
    }));

    setEditingCat(null);
    onSave(`Category renamed to "${renameVal.trim()}"`);
    onRefresh();
  };

  const handleDelete = (cat: string) => {
    portfolioStorage.updateData((prev) => ({
      ...prev,
      categories: prev.categories.filter((c) => c !== cat)
    }));
    if (previewCat === cat) setPreviewCat(null);
    onSave(`Category "${cat}" removed`);
    onRefresh();
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
          Project Categories Management ({data.categories.length})
        </h3>
        <p className="text-xs text-[#9fbfae]">
          Manage and organize the filter categories shown across your portfolio.
        </p>
      </div>

      <form onSubmit={handleAdd} className="flex gap-2 p-4 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.2)]">
        <input
          type="text"
          value={newCat}
          onChange={(e) => setNewCat(e.target.value)}
          placeholder="New Category Name (e.g. Mobile Apps, 3D Graphics)..."
          className="flex-1 px-3 py-2 rounded-xl bg-[#021008] border border-white/20 text-xs text-white placeholder:text-gray-500 focus:border-[#3dff8f] focus:outline-none"
        />
        <button
          type="submit"
          className="px-5 py-2 rounded-xl text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] shrink-0 cursor-pointer"
        >
          Add Category
        </button>
      </form>

      <div className="space-y-3">
        {data.categories.map((cat) => {
          const projectCount = data.projects.filter((p) => p.category === cat).length;
          return (
            <div
              key={cat}
              className="p-4 sm:p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.18)] hover:border-[#3dff8f]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all"
            >
              {editingCat === cat ? (
                <div className="flex-1 flex gap-2">
                  <input
                    type="text"
                    value={renameVal}
                    onChange={(e) => setRenameVal(e.target.value)}
                    className="flex-1 px-3 py-1.5 rounded-lg bg-[#021008] border border-[#3dff8f] text-xs text-white"
                    autoFocus
                  />
                  <button
                    onClick={() => handleSaveRename(cat)}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold bg-[#3dff8f] text-black"
                  >
                    Save
                  </button>
                  <button
                    onClick={() => setEditingCat(null)}
                    className="px-3 py-1.5 rounded-lg text-xs border border-white/20 text-[#9fbfae]"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <div className="flex-1">
                  <span className="text-[#fff1b8] font-bold text-sm block">{cat}</span>
                  <span className="text-[11px] font-mono text-[#3dff8f] mt-0.5 block">
                    {projectCount} project{projectCount === 1 ? '' : 's'} assigned
                  </span>
                </div>
              )}

              {editingCat !== cat && (
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => setPreviewCat(cat)}
                    className="p-2 rounded-xl text-xs text-[#3dff8f] bg-[#3dff8f]/10 hover:bg-[#3dff8f]/20 border border-[#3dff8f]/30 transition-all cursor-pointer flex items-center gap-1"
                    title="View Projects in this Category"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span className="font-mono text-[11px]">View</span>
                  </button>
                  <button
                    onClick={() => {
                      setEditingCat(cat);
                      setRenameVal(cat);
                    }}
                    className="p-2 rounded-xl text-xs text-[#9fbfae] bg-white/5 hover:text-[#f0b92e] hover:border-[#f0b92e]/40 border border-white/10 transition-all cursor-pointer flex items-center gap-1"
                    title="Rename Category"
                  >
                    <Edit className="w-3.5 h-3.5" />
                    <span className="font-mono text-[11px]">Edit</span>
                  </button>
                  <button
                    onClick={() => setDeleteTarget(cat)}
                    className="p-2 rounded-xl text-xs text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-all cursor-pointer flex items-center gap-1"
                    title="Delete Category"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span className="font-mono text-[11px]">Delete</span>
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Category Projects Preview Modal */}
      {previewCat && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-[#010e06] border border-[#3dff8f] p-6 space-y-4 text-[#f4fff8] relative shadow-2xl">
            <button
              onClick={() => setPreviewCat(null)}
              className="absolute top-5 right-5 text-[#9fbfae] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#3dff8f]/15 text-[#3dff8f] border border-[#3dff8f]/30">
              Category Preview
            </span>

            <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
              {previewCat}
            </h3>

            <div className="space-y-2 max-h-60 overflow-y-auto">
              {data.projects.filter((p) => p.category === previewCat).length === 0 ? (
                <p className="text-xs text-[#9fbfae] italic">No projects currently tagged with this category.</p>
              ) : (
                data.projects
                  .filter((p) => p.category === previewCat)
                  .map((p) => (
                    <div
                      key={p.id}
                      className="p-3 rounded-xl bg-[#010904] border border-white/10 flex items-center gap-3 text-xs"
                    >
                      <img
                        src={p.thumbnail}
                        alt=""
                        className="w-8 h-8 rounded-lg object-cover bg-black"
                      />
                      <div className="min-w-0 flex-1">
                        <span className="font-bold text-[#fff1b8] block truncate">{p.title}</span>
                        <span className="text-[10px] text-[#3dff8f] font-mono">{p.projectType}</span>
                      </div>
                    </div>
                  ))
              )}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-white/10">
              <button
                type="button"
                onClick={() => {
                  const toDel = previewCat;
                  setPreviewCat(null);
                  setDeleteTarget(toDel);
                }}
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30 flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>

              <button
                onClick={() => setPreviewCat(null)}
                className="px-4 py-1.5 rounded-xl text-xs font-mono border border-white/20 text-[#9fbfae]"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-App Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm p-6 rounded-2xl bg-[#02100a] border border-rose-500/60 shadow-[0_0_40px_rgba(244,63,94,0.35)] space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-[#fff1b8]">Delete Category?</h4>
              <p className="text-xs text-[#9fbfae] mt-1 leading-relaxed">
                Are you sure you want to delete category <span className="text-rose-300 font-bold">"{deleteTarget}"</span>? Projects in this category will remain.
              </p>
            </div>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2 px-3 rounded-xl border border-white/20 text-xs text-[#9fbfae] hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleDelete(deleteTarget);
                  setDeleteTarget(null);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-600 transition-all cursor-pointer shadow-lg"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Experience Tab                                                 */
/* -------------------------------------------------------------------------- */
const ExperienceTab: React.FC<{
  data: PortfolioDatabase;
  onSave: (msg: string) => void;
  onRefresh: () => void;
}> = ({ data, onSave, onRefresh }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<Partial<WorkExperienceItem>>({});
  const [previewExp, setPreviewExp] = useState<WorkExperienceItem | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; title: string } | null>(null);

  const handleCreate = () => {
    const newItem: WorkExperienceItem = {
      id: 'exp-' + Date.now(),
      roleTitle: 'Graphic & Web Designer',
      employer: 'Freelance & Independent Client Work',
      employmentType: 'freelance',
      startDate: '2022',
      endDate: 'Present',
      current: true,
      location: 'Dodoma CBD Tanzania',
      description: 'Describe your role and key accomplishments...',
      responsibilities: ['Created visual identities for clients', 'Designed responsive websites'],
      published: true,
      order: data.workExperience.length + 1
    };

    portfolioStorage.updateData((prev) => ({
      ...prev,
      workExperience: [newItem, ...prev.workExperience]
    }));

    setEditingId(newItem.id);
    setForm(newItem);
    onSave('Experience entry created');
    onRefresh();
  };

  const handleSave = () => {
    portfolioStorage.updateData((prev) => ({
      ...prev,
      workExperience: prev.workExperience.map((w) => (w.id === editingId ? ({ ...w, ...form } as WorkExperienceItem) : w))
    }));
    setEditingId(null);
    onSave('Experience updated successfully');
    onRefresh();
  };

  const handleDelete = (id: string) => {
    portfolioStorage.updateData((prev) => ({
      ...prev,
      workExperience: prev.workExperience.filter((w) => w.id !== id)
    }));
    if (previewExp?.id === id) setPreviewExp(null);
    onSave('Experience deleted successfully');
    onRefresh();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between pb-3 border-b border-[rgba(240,185,46,0.2)]">
        <div>
          <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
            Work Experience Management ({data.workExperience.length})
          </h3>
          <p className="text-xs text-[#9fbfae]">
            Support for freelance, independent, contract, and employment history.
          </p>
        </div>
        <button
          onClick={handleCreate}
          className="px-4 py-2 rounded-xl text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] flex items-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5 text-[#1a1200]" />
          <span>Add Experience</span>
        </button>
      </div>

      {editingId && (
        <div className="p-5 rounded-2xl bg-[#010e06] border border-[#3dff8f] space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Role Title</label>
              <input
                type="text"
                value={form.roleTitle || ''}
                onChange={(e) => setForm({ ...form, roleTitle: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Employer / Client</label>
              <input
                type="text"
                value={form.employer || ''}
                onChange={(e) => setForm({ ...form, employer: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Start Date</label>
              <input
                type="text"
                value={form.startDate || ''}
                onChange={(e) => setForm({ ...form, startDate: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">End Date</label>
              <input
                type="text"
                value={form.endDate || ''}
                onChange={(e) => setForm({ ...form, endDate: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Type</label>
              <select
                value={form.employmentType || 'freelance'}
                onChange={(e) => setForm({ ...form, employmentType: e.target.value as any })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              >
                <option value="freelance">Freelance</option>
                <option value="contract">Contract</option>
                <option value="independent">Independent</option>
                <option value="full-time">Full-Time</option>
                <option value="part-time">Part-Time</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs text-[#9fbfae] block mb-1">Description</label>
            <textarea
              rows={3}
              value={form.description || ''}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
            />
          </div>

          <div>
            <label className="text-xs text-[#9fbfae] block mb-1">Responsibilities (one per line)</label>
            <textarea
              rows={3}
              value={(form.responsibilities || []).join('\n')}
              onChange={(e) =>
                setForm({
                  ...form,
                  responsibilities: e.target.value.split('\n').filter(Boolean)
                })
              }
              className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button onClick={() => setEditingId(null)} className="px-4 py-1.5 rounded-lg text-xs border border-white/20">
              Cancel
            </button>
            <button onClick={handleSave} className="px-4 py-1.5 rounded-lg text-xs font-bold bg-[#3dff8f] text-black">
              Save Entry
            </button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {data.workExperience.map((exp) => (
          <div
            key={exp.id}
            className="p-4 sm:p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.18)] hover:border-[#3dff8f]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all"
          >
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-sm sm:text-base text-[#fff1b8]">{exp.roleTitle}</span>
                <span className="text-xs text-[#9fbfae]">· {exp.employer}</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0a351e] text-[#3dff8f]">
                  {exp.employmentType}
                </span>
                {!exp.published && (
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-rose-950 text-rose-300">
                    Draft
                  </span>
                )}
              </div>
              <div className="text-xs text-[#3dff8f] font-mono mt-1">
                {exp.startDate} – {exp.endDate} {exp.location ? `· ${exp.location}` : ''}
              </div>
              {exp.description && (
                <p className="text-xs text-[#9fbfae] mt-1.5 line-clamp-1">{exp.description}</p>
              )}
            </div>

            <div className="flex items-center gap-1.5 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-white/5">
              <button
                onClick={() => setPreviewExp(exp)}
                className="p-2 rounded-xl text-xs text-[#3dff8f] bg-[#3dff8f]/10 hover:bg-[#3dff8f]/20 border border-[#3dff8f]/30 transition-all cursor-pointer flex items-center gap-1"
                title="View Full Experience Details & Preview"
              >
                <Eye className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">View</span>
              </button>
              <button
                onClick={() => {
                  setEditingId(exp.id);
                  setForm(exp);
                }}
                className="p-2 rounded-xl text-xs text-[#9fbfae] bg-white/5 hover:text-[#f0b92e] hover:border-[#f0b92e]/40 border border-white/10 transition-all cursor-pointer flex items-center gap-1"
                title="Edit Experience Entry"
              >
                <Edit className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">Edit</span>
              </button>
              <button
                onClick={() => setDeleteTarget({ id: exp.id, title: exp.roleTitle })}
                className="p-2 rounded-xl text-xs text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-all cursor-pointer flex items-center gap-1"
                title="Delete Experience"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">Delete</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Experience Preview Modal */}
      {previewExp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-[#010e06] border border-[#3dff8f] p-6 space-y-4 text-[#f4fff8] relative shadow-2xl">
            <button
              onClick={() => setPreviewExp(null)}
              className="absolute top-5 right-5 text-[#9fbfae] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#3dff8f]/15 text-[#3dff8f] border border-[#3dff8f]/30">
                {previewExp.employmentType}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#f0b92e]/10 text-[#fff1b8]">
                {previewExp.startDate} – {previewExp.endDate}
              </span>
            </div>

            <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
              {previewExp.roleTitle}
            </h3>
            <div className="text-xs text-[#3dff8f] font-mono">
              {previewExp.employer} {previewExp.location ? `· ${previewExp.location}` : ''}
            </div>

            {previewExp.description && (
              <p className="text-xs sm:text-sm text-[#9fbfae] leading-relaxed p-3.5 rounded-xl bg-[#010904] border border-white/10">
                {previewExp.description}
              </p>
            )}

            {previewExp.responsibilities && previewExp.responsibilities.length > 0 && (
              <div>
                <span className="text-[10px] font-mono text-[#f0b92e] uppercase block mb-1.5">
                  Key Responsibilities:
                </span>
                <ul className="space-y-1.5 text-xs text-[#f4fff8]">
                  {previewExp.responsibilities.map((r, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-[#3dff8f]">•</span>
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex items-center justify-between pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => {
                  const toDel = previewExp;
                  setPreviewExp(null);
                  setDeleteTarget({ id: toDel.id, title: toDel.roleTitle });
                }}
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30 flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>

              <button
                onClick={() => {
                  const toEdit = previewExp;
                  setPreviewExp(null);
                  setEditingId(toEdit.id);
                  setForm(toEdit);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#f0b92e] text-black cursor-pointer"
              >
                Edit Experience
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-App Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm p-6 rounded-2xl bg-[#02100a] border border-rose-500/60 shadow-[0_0_40px_rgba(244,63,94,0.35)] space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-[#fff1b8]">Delete Experience Entry?</h4>
              <p className="text-xs text-[#9fbfae] mt-1 leading-relaxed">
                Are you sure you want to delete <span className="text-rose-300 font-bold">"{deleteTarget.title}"</span>?
              </p>
            </div>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2 px-3 rounded-xl border border-white/20 text-xs text-[#9fbfae] hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleDelete(deleteTarget.id);
                  setDeleteTarget(null);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-600 transition-all cursor-pointer shadow-lg"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Education Tab                                                  */
/* -------------------------------------------------------------------------- */
const EducationTab: React.FC<{
  data: PortfolioDatabase;
  onSave: (msg: string) => void;
  onRefresh: () => void;
}> = ({ data, onSave, onRefresh }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<Partial<EducationItem>>({});
  const [previewEdu, setPreviewEdu] = useState<EducationItem | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; title: string } | null>(null);

  const handleCreate = () => {
    const newItem: EducationItem = {
      id: 'edu-' + Date.now(),
      institution: 'University / Institute Name',
      qualification: 'Diploma / Degree',
      field: 'Design & Computing',
      startDate: '2020',
      endDate: '2023',
      description: '',
      published: true,
      order: data.education.length + 1
    };

    portfolioStorage.updateData((prev) => ({
      ...prev,
      education: [newItem, ...prev.education]
    }));

    setEditingId(newItem.id);
    setForm(newItem);
    onSave('Education entry created');
    onRefresh();
  };

  const handleSave = () => {
    portfolioStorage.updateData((prev) => ({
      ...prev,
      education: prev.education.map((e) => (e.id === editingId ? ({ ...e, ...form } as EducationItem) : e))
    }));
    setEditingId(null);
    onSave('Education updated');
    onRefresh();
  };

  const handleDelete = (id: string) => {
    portfolioStorage.updateData((prev) => ({
      ...prev,
      education: prev.education.filter((e) => e.id !== id)
    }));
    if (previewEdu?.id === id) setPreviewEdu(null);
    onSave('Education deleted');
    onRefresh();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between pb-3 border-b border-[rgba(240,185,46,0.2)]">
        <div>
          <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
            Education Management ({data.education.length})
          </h3>
          <p className="text-xs text-[#9fbfae]">
            Add or update academic institutions and qualifications.
          </p>
        </div>
        <button
          onClick={handleCreate}
          className="px-4 py-2 rounded-xl text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] flex items-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5 text-[#1a1200]" />
          <span>Add Education</span>
        </button>
      </div>

      {editingId && (
        <div className="p-5 rounded-2xl bg-[#010e06] border border-[#3dff8f] space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Qualification</label>
              <input
                type="text"
                value={form.qualification || ''}
                onChange={(e) => setForm({ ...form, qualification: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Institution</label>
              <input
                type="text"
                value={form.institution || ''}
                onChange={(e) => setForm({ ...form, institution: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Field / Major</label>
              <input
                type="text"
                value={form.field || ''}
                onChange={(e) => setForm({ ...form, field: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">Start Date</label>
              <input
                type="text"
                value={form.startDate || ''}
                onChange={(e) => setForm({ ...form, startDate: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-[#9fbfae] block mb-1">End Date</label>
              <input
                type="text"
                value={form.endDate || ''}
                onChange={(e) => setForm({ ...form, endDate: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-[#9fbfae] block mb-1">Description</label>
            <textarea
              rows={2}
              value={form.description || ''}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button onClick={() => setEditingId(null)} className="px-4 py-1.5 rounded-lg text-xs border border-white/20">
              Cancel
            </button>
            <button onClick={handleSave} className="px-4 py-1.5 rounded-lg text-xs font-bold bg-[#3dff8f] text-black">
              Save Education
            </button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {data.education.map((edu) => (
          <div
            key={edu.id}
            className="p-4 sm:p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.18)] hover:border-[#3dff8f]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all"
          >
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-sm sm:text-base text-[#fff1b8]">{edu.qualification}</span>
                <span className="text-xs text-[#9fbfae]">· {edu.institution}</span>
                {edu.field && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0a351e] text-[#3dff8f]">
                    {edu.field}
                  </span>
                )}
              </div>
              <div className="text-xs text-[#3dff8f] font-mono mt-1">
                {edu.startDate} – {edu.endDate}
              </div>
              {edu.description && (
                <p className="text-xs text-[#9fbfae] mt-1.5 line-clamp-1">{edu.description}</p>
              )}
            </div>

            <div className="flex items-center gap-1.5 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-white/5">
              <button
                onClick={() => setPreviewEdu(edu)}
                className="p-2 rounded-xl text-xs text-[#3dff8f] bg-[#3dff8f]/10 hover:bg-[#3dff8f]/20 border border-[#3dff8f]/30 transition-all cursor-pointer flex items-center gap-1"
                title="View Full Education Details & Preview"
              >
                <Eye className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">View</span>
              </button>
              <button
                onClick={() => {
                  setEditingId(edu.id);
                  setForm(edu);
                }}
                className="p-2 rounded-xl text-xs text-[#9fbfae] bg-white/5 hover:text-[#f0b92e] hover:border-[#f0b92e]/40 border border-white/10 transition-all cursor-pointer flex items-center gap-1"
                title="Edit Education Entry"
              >
                <Edit className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">Edit</span>
              </button>
              <button
                onClick={() => setDeleteTarget({ id: edu.id, title: edu.qualification })}
                className="p-2 rounded-xl text-xs text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-all cursor-pointer flex items-center gap-1"
                title="Delete Education"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">Delete</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Education Preview Modal */}
      {previewEdu && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-[#010e06] border border-[#3dff8f] p-6 space-y-4 text-[#f4fff8] relative shadow-2xl">
            <button
              onClick={() => setPreviewEdu(null)}
              className="absolute top-5 right-5 text-[#9fbfae] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#3dff8f]/15 text-[#3dff8f] border border-[#3dff8f]/30">
              {previewEdu.startDate} – {previewEdu.endDate}
            </span>

            <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
              {previewEdu.qualification}
            </h3>
            <div className="text-xs text-[#3dff8f] font-mono">
              {previewEdu.institution} {previewEdu.field ? `(${previewEdu.field})` : ''}
            </div>

            {previewEdu.description && (
              <p className="text-xs sm:text-sm text-[#9fbfae] leading-relaxed p-3.5 rounded-xl bg-[#010904] border border-white/10">
                {previewEdu.description}
              </p>
            )}

            <div className="flex items-center justify-between pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => {
                  const toDel = previewEdu;
                  setPreviewEdu(null);
                  setDeleteTarget({ id: toDel.id, title: toDel.qualification });
                }}
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30 flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>

              <button
                onClick={() => {
                  const toEdit = previewEdu;
                  setPreviewEdu(null);
                  setEditingId(toEdit.id);
                  setForm(toEdit);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#f0b92e] text-black cursor-pointer"
              >
                Edit Education
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-App Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm p-6 rounded-2xl bg-[#02100a] border border-rose-500/60 shadow-[0_0_40px_rgba(244,63,94,0.35)] space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-[#fff1b8]">Delete Education Entry?</h4>
              <p className="text-xs text-[#9fbfae] mt-1 leading-relaxed">
                Are you sure you want to delete <span className="text-rose-300 font-bold">"{deleteTarget.title}"</span>?
              </p>
            </div>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2 px-3 rounded-xl border border-white/20 text-xs text-[#9fbfae] hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleDelete(deleteTarget.id);
                  setDeleteTarget(null);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-600 transition-all cursor-pointer shadow-lg"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Certifications & Achievements Tab                             */
/* -------------------------------------------------------------------------- */
const CertificationsTab: React.FC<{
  data: PortfolioDatabase;
  onSave: (msg: string) => void;
  onRefresh: () => void;
}> = ({ data, onSave, onRefresh }) => {
  const [newCert, setNewCert] = useState({ title: '', issuingOrg: '', date: '', credentialUrl: '' });
  const [newAch, setNewAch] = useState({ title: '', description: '', date: '' });
  const [previewCert, setPreviewCert] = useState<CertificationItem | null>(null);
  const [editingCertId, setEditingCertId] = useState<string | null>(null);
  const [editCertForm, setEditCertForm] = useState<Partial<CertificationItem>>({});
  const [deleteCertTarget, setDeleteCertTarget] = useState<{ id: string; title: string } | null>(null);

  const [previewAch, setPreviewAch] = useState<AchievementItem | null>(null);
  const [editingAchId, setEditingAchId] = useState<string | null>(null);
  const [editAchForm, setEditAchForm] = useState<Partial<AchievementItem>>({});
  const [deleteAchTarget, setDeleteAchTarget] = useState<{ id: string; title: string } | null>(null);

  const handleAddCert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCert.title.trim()) return;

    const certItem: CertificationItem = {
      id: 'cert-' + Date.now(),
      title: newCert.title,
      issuingOrg: newCert.issuingOrg,
      date: newCert.date || '2023',
      credentialUrl: newCert.credentialUrl || undefined,
      published: true,
      order: data.certifications.length + 1
    };

    portfolioStorage.updateData((prev) => ({
      ...prev,
      certifications: [...prev.certifications, certItem]
    }));

    setNewCert({ title: '', issuingOrg: '', date: '', credentialUrl: '' });
    onSave('Certification added');
    onRefresh();
  };

  const handleSaveCertEdit = () => {
    if (!editCertForm.title?.trim()) return;
    portfolioStorage.updateData((prev) => ({
      ...prev,
      certifications: prev.certifications.map((c) =>
        c.id === editingCertId ? ({ ...c, ...editCertForm } as CertificationItem) : c
      )
    }));
    setEditingCertId(null);
    onSave('Certification updated');
    onRefresh();
  };

  const handleDeleteCert = (id: string) => {
    portfolioStorage.updateData((prev) => ({
      ...prev,
      certifications: prev.certifications.filter((item) => item.id !== id)
    }));
    if (previewCert?.id === id) setPreviewCert(null);
    onSave('Certification deleted');
    onRefresh();
  };

  const handleAddAch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAch.title.trim()) return;

    const achItem: AchievementItem = {
      id: 'ach-' + Date.now(),
      title: newAch.title,
      description: newAch.description,
      date: newAch.date || '2024',
      published: true,
      order: data.achievements.length + 1
    };

    portfolioStorage.updateData((prev) => ({
      ...prev,
      achievements: [...prev.achievements, achItem]
    }));

    setNewAch({ title: '', description: '', date: '' });
    onSave('Achievement added');
    onRefresh();
  };

  const handleSaveAchEdit = () => {
    if (!editAchForm.title?.trim()) return;
    portfolioStorage.updateData((prev) => ({
      ...prev,
      achievements: prev.achievements.map((a) =>
        a.id === editingAchId ? ({ ...a, ...editAchForm } as AchievementItem) : a
      )
    }));
    setEditingAchId(null);
    onSave('Achievement updated');
    onRefresh();
  };

  const handleDeleteAch = (id: string) => {
    portfolioStorage.updateData((prev) => ({
      ...prev,
      achievements: prev.achievements.filter((item) => item.id !== id)
    }));
    if (previewAch?.id === id) setPreviewAch(null);
    onSave('Achievement deleted');
    onRefresh();
  };

  return (
    <div className="space-y-8">
      {/* Certifications */}
      <div className="space-y-4">
        <div>
          <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
            Certifications & Verified Credentials ({data.certifications.length})
          </h3>
          <p className="text-xs text-[#9fbfae]">
            Document verified certifications and technical achievements.
          </p>
        </div>

        <form onSubmit={handleAddCert} className="p-4 sm:p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.2)] space-y-3">
          <span className="text-xs font-mono font-bold text-[#f0b92e] block">Add New Certificate</span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              placeholder="Certificate Title *"
              value={newCert.title}
              onChange={(e) => setNewCert({ ...newCert, title: e.target.value })}
              className="px-3 py-2 rounded-xl bg-[#021008] border border-white/20 text-xs text-white"
              required
            />
            <input
              type="text"
              placeholder="Issuing Organization (e.g. Google, Coursera)..."
              value={newCert.issuingOrg}
              onChange={(e) => setNewCert({ ...newCert, issuingOrg: e.target.value })}
              className="px-3 py-2 rounded-xl bg-[#021008] border border-white/20 text-xs text-white"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              placeholder="Date / Year (e.g. 2023)..."
              value={newCert.date}
              onChange={(e) => setNewCert({ ...newCert, date: e.target.value })}
              className="px-3 py-2 rounded-xl bg-[#021008] border border-white/20 text-xs text-white"
            />
            <input
              type="url"
              placeholder="Verification URL (optional)..."
              value={newCert.credentialUrl}
              onChange={(e) => setNewCert({ ...newCert, credentialUrl: e.target.value })}
              className="px-3 py-2 rounded-xl bg-[#021008] border border-white/20 text-xs text-white"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 rounded-xl text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] cursor-pointer"
          >
            Add Certificate
          </button>
        </form>

        {/* Edit Certificate Form */}
        {editingCertId && (
          <div className="p-5 rounded-2xl bg-[#010e06] border border-[#3dff8f] space-y-3">
            <div className="flex justify-between items-center text-xs font-mono text-[#3dff8f]">
              <span>Editing Certificate</span>
              <button onClick={() => setEditingCertId(null)} className="text-[#9fbfae] hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={editCertForm.title || ''}
                onChange={(e) => setEditCertForm({ ...editCertForm, title: e.target.value })}
                className="px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
              <input
                type="text"
                value={editCertForm.issuingOrg || ''}
                onChange={(e) => setEditCertForm({ ...editCertForm, issuingOrg: e.target.value })}
                className="px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={editCertForm.date || ''}
                onChange={(e) => setEditCertForm({ ...editCertForm, date: e.target.value })}
                className="px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
              <input
                type="url"
                value={editCertForm.credentialUrl || ''}
                onChange={(e) => setEditCertForm({ ...editCertForm, credentialUrl: e.target.value })}
                className="px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
                placeholder="Verification URL"
              />
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <button onClick={() => setEditingCertId(null)} className="px-3 py-1.5 rounded-lg text-xs border border-white/20">
                Cancel
              </button>
              <button onClick={handleSaveCertEdit} className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-[#3dff8f] text-black">
                Save Changes
              </button>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {data.certifications.map((c) => (
            <div
              key={c.id}
              className="p-4 sm:p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.18)] hover:border-[#3dff8f]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs transition-all"
            >
              <div>
                <strong className="text-sm text-[#fff1b8] block">{c.title}</strong>
                <span className="text-[11px] text-[#3dff8f] font-mono mt-0.5 block">
                  {c.issuingOrg} · {c.date}
                </span>
                {c.credentialUrl && (
                  <span className="text-[10px] text-[#9fbfae] truncate block max-w-md mt-1">
                    Verified Credential URL configured
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-white/5">
                <button
                  onClick={() => setPreviewCert(c)}
                  className="p-2 rounded-xl text-xs text-[#3dff8f] bg-[#3dff8f]/10 hover:bg-[#3dff8f]/20 border border-[#3dff8f]/30 transition-all cursor-pointer flex items-center gap-1"
                  title="View Certificate Details"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span className="font-mono text-[11px]">View</span>
                </button>
                <button
                  onClick={() => {
                    setEditingCertId(c.id);
                    setEditCertForm(c);
                  }}
                  className="p-2 rounded-xl text-xs text-[#9fbfae] bg-white/5 hover:text-[#f0b92e] hover:border-[#f0b92e]/40 border border-white/10 transition-all cursor-pointer flex items-center gap-1"
                  title="Edit Certificate"
                >
                  <Edit className="w-3.5 h-3.5" />
                  <span className="font-mono text-[11px]">Edit</span>
                </button>
                <button
                  onClick={() => setDeleteCertTarget({ id: c.id, title: c.title })}
                  className="p-2 rounded-xl text-xs text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-all cursor-pointer flex items-center gap-1"
                  title="Delete Certificate"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="font-mono text-[11px]">Delete</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Certificate Preview Modal */}
      {previewCert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-[#010e06] border border-[#3dff8f] p-6 space-y-4 text-[#f4fff8] relative shadow-2xl">
            <button
              onClick={() => setPreviewCert(null)}
              className="absolute top-5 right-5 text-[#9fbfae] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#3dff8f]/15 text-[#3dff8f] border border-[#3dff8f]/30">
              Verified Credential
            </span>

            <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
              {previewCert.title}
            </h3>
            <div className="text-xs text-[#3dff8f] font-mono">
              {previewCert.issuingOrg} · {previewCert.date}
            </div>

            {previewCert.credentialUrl && (
              <a
                href={previewCert.credentialUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#021008] border border-[rgba(240,185,46,0.3)] text-xs text-[#f0b92e] hover:underline"
              >
                <span>Open Verification Credential Link</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}

            <div className="flex items-center justify-between pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => {
                  const toDel = previewCert;
                  setPreviewCert(null);
                  setDeleteCertTarget({ id: toDel.id, title: toDel.title });
                }}
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30 flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const toEdit = previewCert;
                    setPreviewCert(null);
                    setEditingCertId(toEdit.id);
                    setEditCertForm(toEdit);
                  }}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-[#f0b92e] text-black cursor-pointer"
                >
                  Edit Certificate
                </button>
                <button
                  onClick={() => setPreviewCert(null)}
                  className="px-3 py-1.5 rounded-xl text-xs font-mono border border-white/20 text-[#9fbfae]"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cert Delete Confirmation Modal */}
      {deleteCertTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm p-6 rounded-2xl bg-[#02100a] border border-rose-500/60 shadow-[0_0_40px_rgba(244,63,94,0.35)] space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-[#fff1b8]">Delete Certificate?</h4>
              <p className="text-xs text-[#9fbfae] mt-1 leading-relaxed">
                Are you sure you want to delete <span className="text-rose-300 font-bold">"{deleteCertTarget.title}"</span>?
              </p>
            </div>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteCertTarget(null)}
                className="flex-1 py-2 px-3 rounded-xl border border-white/20 text-xs text-[#9fbfae] hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleDeleteCert(deleteCertTarget.id);
                  setDeleteCertTarget(null);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-600 transition-all cursor-pointer shadow-lg"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Achievements */}
      <div className="space-y-4 pt-6 border-t border-white/10">
        <div>
          <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
            Achievements & Milestones ({data.achievements.length})
          </h3>
          <p className="text-xs text-[#9fbfae]">
            Key creative achievements, client delivery milestones, and recognitions.
          </p>
        </div>

        <form onSubmit={handleAddAch} className="p-4 sm:p-5 rounded-2xl bg-[#010904] border border-white/10 space-y-3">
          <span className="text-xs font-mono font-bold text-[#3dff8f] block">Add New Achievement</span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              placeholder="Achievement Title *"
              value={newAch.title}
              onChange={(e) => setNewAch({ ...newAch, title: e.target.value })}
              className="px-3 py-2 rounded-xl bg-[#021008] border border-white/20 text-xs text-white"
              required
            />
            <input
              type="text"
              placeholder="Date / Year..."
              value={newAch.date}
              onChange={(e) => setNewAch({ ...newAch, date: e.target.value })}
              className="px-3 py-2 rounded-xl bg-[#021008] border border-white/20 text-xs text-white"
            />
          </div>
          <textarea
            rows={2}
            placeholder="Description of milestone or accomplishment..."
            value={newAch.description}
            onChange={(e) => setNewAch({ ...newAch, description: e.target.value })}
            className="w-full px-3 py-2 rounded-xl bg-[#021008] border border-white/20 text-xs text-white"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded-xl text-xs font-bold bg-[#f0b92e] text-black cursor-pointer"
          >
            Add Achievement
          </button>
        </form>

        {/* Edit Achievement Form */}
        {editingAchId && (
          <div className="p-5 rounded-2xl bg-[#010e06] border border-[#f0b92e] space-y-3">
            <div className="flex justify-between items-center text-xs font-mono text-[#f0b92e]">
              <span>Editing Achievement</span>
              <button onClick={() => setEditingAchId(null)} className="text-[#9fbfae] hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={editAchForm.title || ''}
                onChange={(e) => setEditAchForm({ ...editAchForm, title: e.target.value })}
                className="px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
              <input
                type="text"
                value={editAchForm.date || ''}
                onChange={(e) => setEditAchForm({ ...editAchForm, date: e.target.value })}
                className="px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <textarea
              rows={2}
              value={editAchForm.description || ''}
              onChange={(e) => setEditAchForm({ ...editAchForm, description: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
            />
            <div className="flex justify-end gap-2 pt-1">
              <button onClick={() => setEditingAchId(null)} className="px-3 py-1.5 rounded-lg text-xs border border-white/20">
                Cancel
              </button>
              <button onClick={handleSaveAchEdit} className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-[#f0b92e] text-black">
                Save Achievement
              </button>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {data.achievements.map((a) => (
            <div
              key={a.id}
              className="p-4 sm:p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.18)] hover:border-[#3dff8f]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs transition-all"
            >
              <div>
                <strong className="text-sm text-[#fff1b8] block">{a.title}</strong>
                <span className="text-[11px] text-[#3dff8f] font-mono mt-0.5 block">{a.date}</span>
                <p className="text-xs text-[#9fbfae] mt-1 line-clamp-2">{a.description}</p>
              </div>

              <div className="flex items-center gap-1.5 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-white/5">
                <button
                  onClick={() => setPreviewAch(a)}
                  className="p-2 rounded-xl text-xs text-[#3dff8f] bg-[#3dff8f]/10 hover:bg-[#3dff8f]/20 border border-[#3dff8f]/30 transition-all cursor-pointer flex items-center gap-1"
                  title="View Achievement Details"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span className="font-mono text-[11px]">View</span>
                </button>
                <button
                  onClick={() => {
                    setEditingAchId(a.id);
                    setEditAchForm(a);
                  }}
                  className="p-2 rounded-xl text-xs text-[#9fbfae] bg-white/5 hover:text-[#f0b92e] hover:border-[#f0b92e]/40 border border-white/10 transition-all cursor-pointer flex items-center gap-1"
                  title="Edit Achievement"
                >
                  <Edit className="w-3.5 h-3.5" />
                  <span className="font-mono text-[11px]">Edit</span>
                </button>
                <button
                  onClick={() => setDeleteAchTarget({ id: a.id, title: a.title })}
                  className="p-2 rounded-xl text-xs text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-all cursor-pointer flex items-center gap-1"
                  title="Delete Achievement"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="font-mono text-[11px]">Delete</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Achievement Preview Modal */}
      {previewAch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-[#010e06] border border-[#f0b92e] p-6 space-y-4 text-[#f4fff8] relative shadow-2xl">
            <button
              onClick={() => setPreviewAch(null)}
              className="absolute top-5 right-5 text-[#9fbfae] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#f0b92e]/15 text-[#f0b92e] border border-[#f0b92e]/30">
              Milestone & Achievement
            </span>

            <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
              {previewAch.title}
            </h3>
            <div className="text-xs text-[#3dff8f] font-mono">
              Date: {previewAch.date}
            </div>

            <p className="text-xs sm:text-sm text-[#9fbfae] leading-relaxed p-3.5 rounded-xl bg-[#010904] border border-white/10">
              {previewAch.description}
            </p>

            <div className="flex items-center justify-between pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => {
                  const toDel = previewAch;
                  setPreviewAch(null);
                  setDeleteAchTarget({ id: toDel.id, title: toDel.title });
                }}
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30 flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const toEdit = previewAch;
                    setPreviewAch(null);
                    setEditingAchId(toEdit.id);
                    setEditAchForm(toEdit);
                  }}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-[#f0b92e] text-black cursor-pointer"
                >
                  Edit Achievement
                </button>
                <button
                  onClick={() => setPreviewAch(null)}
                  className="px-3 py-1.5 rounded-xl text-xs font-mono border border-white/20 text-[#9fbfae]"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Ach Delete Confirmation Modal */}
      {deleteAchTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm p-6 rounded-2xl bg-[#02100a] border border-rose-500/60 shadow-[0_0_40px_rgba(244,63,94,0.35)] space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-[#fff1b8]">Delete Achievement?</h4>
              <p className="text-xs text-[#9fbfae] mt-1 leading-relaxed">
                Are you sure you want to delete <span className="text-rose-300 font-bold">"{deleteAchTarget.title}"</span>?
              </p>
            </div>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteAchTarget(null)}
                className="flex-1 py-2 px-3 rounded-xl border border-white/20 text-xs text-[#9fbfae] hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleDeleteAch(deleteAchTarget.id);
                  setDeleteAchTarget(null);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-600 transition-all cursor-pointer shadow-lg"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Workflow Tab                                                   */
/* -------------------------------------------------------------------------- */
const WorkflowTab: React.FC<{
  data: PortfolioDatabase;
  onSave: (msg: string) => void;
  onRefresh: () => void;
}> = ({ data, onSave, onRefresh }) => {
  const [stages, setStages] = useState(data.workflowStages);
  const [previewStage, setPreviewStage] = useState<AIWorkflowStage | null>(null);
  const [editingStageId, setEditingStageId] = useState<string | null>(null);
  const [editStageForm, setEditStageForm] = useState<Partial<AIWorkflowStage>>({});
  const [deleteStageTarget, setDeleteStageTarget] = useState<{ id: string; title: string } | null>(null);

  const handleSaveStageEdit = () => {
    if (!editStageForm.title?.trim()) return;
    const updated = stages.map((s) =>
      s.id === editingStageId ? ({ ...s, ...editStageForm } as AIWorkflowStage) : s
    );
    setStages(updated);
    portfolioStorage.updateData((prev) => ({ ...prev, workflowStages: updated }));
    setEditingStageId(null);
    onSave('Workflow stage updated');
    onRefresh();
  };

  const handleDeleteStage = (id: string) => {
    const updated = stages.filter((s) => s.id !== id);
    setStages(updated);
    portfolioStorage.updateData((prev) => ({ ...prev, workflowStages: updated }));
    if (previewStage?.id === id) setPreviewStage(null);
    onSave('Workflow stage removed');
    onRefresh();
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
          AI-Assisted Workflow Stages ({stages.length})
        </h3>
        <p className="text-xs text-[#9fbfae]">
          Human-in-the-loop creative and development methodology stages.
        </p>
      </div>

      {editingStageId && (
        <div className="p-5 rounded-2xl bg-[#010e06] border border-[#3dff8f] space-y-3">
          <div className="flex justify-between items-center text-xs font-mono text-[#3dff8f]">
            <span>Editing Workflow Stage {editStageForm.stageNumber}</span>
            <button onClick={() => setEditingStageId(null)} className="text-[#9fbfae] hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-mono text-[#9fbfae] block mb-1">Stage Title</label>
              <input
                type="text"
                value={editStageForm.title || ''}
                onChange={(e) => setEditStageForm({ ...editStageForm, title: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-[10px] font-mono text-[#9fbfae] block mb-1">Subtitle</label>
              <input
                type="text"
                value={editStageForm.subtitle || ''}
                onChange={(e) => setEditStageForm({ ...editStageForm, subtitle: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
              />
            </div>
          </div>
          <div>
            <label className="text-[10px] font-mono text-[#9fbfae] block mb-1">Description</label>
            <textarea
              rows={2}
              value={editStageForm.description || ''}
              onChange={(e) => setEditStageForm({ ...editStageForm, description: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="text-[10px] text-[#f0b92e] uppercase block mb-1">Human Role</label>
              <input
                type="text"
                value={editStageForm.humanRole || ''}
                onChange={(e) => setEditStageForm({ ...editStageForm, humanRole: e.target.value })}
                className="w-full px-3 py-1.5 rounded bg-[#010904] border border-white/10 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-[10px] text-[#3dff8f] uppercase block mb-1">AI Role</label>
              <input
                type="text"
                value={editStageForm.aiRole || ''}
                onChange={(e) => setEditStageForm({ ...editStageForm, aiRole: e.target.value })}
                className="w-full px-3 py-1.5 rounded bg-[#010904] border border-white/10 text-xs text-white"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button onClick={() => setEditingStageId(null)} className="px-3.5 py-1.5 rounded-lg text-xs border border-white/20">
              Cancel
            </button>
            <button onClick={handleSaveStageEdit} className="px-4 py-1.5 rounded-lg text-xs font-bold bg-[#3dff8f] text-black">
              Save Stage
            </button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {stages.map((stg) => (
          <div
            key={stg.id}
            className="p-4 sm:p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.18)] hover:border-[#3dff8f]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all"
          >
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-3">
                <span className="w-7 h-7 rounded-lg bg-[#0a351e] text-[#3dff8f] font-mono font-bold flex items-center justify-center text-xs shrink-0">
                  {stg.stageNumber}
                </span>
                <div>
                  <h4 className="font-bold text-sm text-[#fff1b8]">{stg.title}</h4>
                  <span className="text-[11px] text-[#9fbfae] font-mono">{stg.subtitle}</span>
                </div>
              </div>
              <p className="text-xs text-[#9fbfae] mt-2 line-clamp-2 pl-10">{stg.description}</p>
            </div>

            <div className="flex items-center gap-1.5 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-white/5 pl-10 sm:pl-0">
              <button
                onClick={() => setPreviewStage(stg)}
                className="p-2 rounded-xl text-xs text-[#3dff8f] bg-[#3dff8f]/10 hover:bg-[#3dff8f]/20 border border-[#3dff8f]/30 transition-all cursor-pointer flex items-center gap-1"
                title="View Stage Details"
              >
                <Eye className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">View</span>
              </button>
              <button
                onClick={() => {
                  setEditingStageId(stg.id);
                  setEditStageForm(stg);
                }}
                className="p-2 rounded-xl text-xs text-[#9fbfae] bg-white/5 hover:text-[#f0b92e] hover:border-[#f0b92e]/40 border border-white/10 transition-all cursor-pointer flex items-center gap-1"
                title="Edit Stage"
              >
                <Edit className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">Edit</span>
              </button>
              <button
                onClick={() => setDeleteStageTarget({ id: stg.id, title: stg.title })}
                className="p-2 rounded-xl text-xs text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-all cursor-pointer flex items-center gap-1"
                title="Delete Stage"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">Delete</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Stage Preview Modal */}
      {previewStage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-[#010e06] border border-[#3dff8f] p-6 space-y-4 text-[#f4fff8] relative shadow-2xl">
            <button
              onClick={() => setPreviewStage(null)}
              className="absolute top-5 right-5 text-[#9fbfae] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#3dff8f]/15 text-[#3dff8f] border border-[#3dff8f]/30">
              Stage {previewStage.stageNumber} of {stages.length}
            </span>

            <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
              {previewStage.title}
            </h3>
            <div className="text-xs text-[#f0b92e] font-mono">{previewStage.subtitle}</div>

            <p className="text-xs sm:text-sm text-[#9fbfae] leading-relaxed p-3.5 rounded-xl bg-[#010904] border border-white/10">
              {previewStage.description}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-3 rounded-xl bg-[#010904] border border-white/10">
                <span className="text-[#f0b92e] block text-[10px] uppercase font-bold mb-1">Human Role:</span>
                <span className="text-[#f4fff8]">{previewStage.humanRole}</span>
              </div>
              <div className="p-3 rounded-xl bg-[#010904] border border-white/10">
                <span className="text-[#3dff8f] block text-[10px] uppercase font-bold mb-1">AI Collaboration Role:</span>
                <span className="text-[#f4fff8]">{previewStage.aiRole}</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => {
                  const toDel = previewStage;
                  setPreviewStage(null);
                  setDeleteStageTarget({ id: toDel.id, title: toDel.title });
                }}
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30 flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const toEdit = previewStage;
                    setPreviewStage(null);
                    setEditingStageId(toEdit.id);
                    setEditStageForm(toEdit);
                  }}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-[#f0b92e] text-black cursor-pointer"
                >
                  Edit Stage
                </button>
                <button
                  onClick={() => setPreviewStage(null)}
                  className="px-4 py-1.5 rounded-xl text-xs font-mono border border-white/20 text-[#9fbfae]"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* In-App Delete Confirmation Modal */}
      {deleteStageTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm p-6 rounded-2xl bg-[#02100a] border border-rose-500/60 shadow-[0_0_40px_rgba(244,63,94,0.35)] space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-[#fff1b8]">Delete Workflow Stage?</h4>
              <p className="text-xs text-[#9fbfae] mt-1 leading-relaxed">
                Are you sure you want to delete <span className="text-rose-300 font-bold">"{deleteStageTarget.title}"</span>?
              </p>
            </div>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteStageTarget(null)}
                className="flex-1 py-2 px-3 rounded-xl border border-white/20 text-xs text-[#9fbfae] hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleDeleteStage(deleteStageTarget.id);
                  setDeleteStageTarget(null);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-600 transition-all cursor-pointer shadow-lg"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Testimonials Tab                                               */
/* -------------------------------------------------------------------------- */
const TestimonialsTab: React.FC<{
  data: PortfolioDatabase;
  onSave: (msg: string) => void;
  onRefresh: () => void;
}> = ({ data, onSave, onRefresh }) => {
  const [newTestimonial, setNewTestimonial] = useState({
    name: '',
    role: '',
    organization: '',
    content: '',
    permissionToPublish: true
  });
  const [previewTest, setPreviewTest] = useState<TestimonialItem | null>(null);
  const [editingTestId, setEditingTestId] = useState<string | null>(null);
  const [editTestForm, setEditTestForm] = useState<Partial<TestimonialItem>>({});
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; name: string } | null>(null);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTestimonial.name.trim() || !newTestimonial.content.trim()) return;

    const item: TestimonialItem = {
      id: 'test-' + Date.now(),
      name: newTestimonial.name,
      role: newTestimonial.role || 'Client',
      organization: newTestimonial.organization || '',
      content: newTestimonial.content,
      permissionToPublish: newTestimonial.permissionToPublish,
      published: true,
      order: data.testimonials.length + 1
    };

    portfolioStorage.updateData((prev) => ({
      ...prev,
      testimonials: [item, ...prev.testimonials]
    }));

    setNewTestimonial({ name: '', role: '', organization: '', content: '', permissionToPublish: true });
    onSave('Verified testimonial added');
    onRefresh();
  };

  const handleSaveTestEdit = () => {
    if (!editTestForm.name?.trim() || !editTestForm.content?.trim()) return;
    portfolioStorage.updateData((prev) => ({
      ...prev,
      testimonials: prev.testimonials.map((t) =>
        t.id === editingTestId ? ({ ...t, ...editTestForm } as TestimonialItem) : t
      )
    }));
    setEditingTestId(null);
    onSave('Testimonial updated');
    onRefresh();
  };

  const handleDelete = (id: string) => {
    portfolioStorage.updateData((prev) => ({
      ...prev,
      testimonials: prev.testimonials.filter((item) => item.id !== id)
    }));
    if (previewTest?.id === id) setPreviewTest(null);
    onSave('Testimonial deleted');
    onRefresh();
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
          Testimonials & Client Endorsements ({data.testimonials.length})
        </h3>
        <p className="text-xs text-[#9fbfae]">
          Strict requirement: Only verified, authorized client feedback should be published.
        </p>
      </div>

      <form onSubmit={handleAdd} className="p-4 sm:p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.2)] space-y-3 max-w-2xl">
        <span className="text-xs font-mono font-bold text-[#f0b92e] block">Add Verified Testimonial</span>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <input
            type="text"
            placeholder="Person's Name *"
            value={newTestimonial.name}
            onChange={(e) => setNewTestimonial({ ...newTestimonial, name: e.target.value })}
            className="px-3 py-2 rounded-xl bg-[#021008] border border-white/20 text-xs text-white"
            required
          />
          <input
            type="text"
            placeholder="Role / Title..."
            value={newTestimonial.role}
            onChange={(e) => setNewTestimonial({ ...newTestimonial, role: e.target.value })}
            className="px-3 py-2 rounded-xl bg-[#021008] border border-white/20 text-xs text-white"
          />
          <input
            type="text"
            placeholder="Company / Organization..."
            value={newTestimonial.organization}
            onChange={(e) => setNewTestimonial({ ...newTestimonial, organization: e.target.value })}
            className="px-3 py-2 rounded-xl bg-[#021008] border border-white/20 text-xs text-white"
          />
        </div>

        <textarea
          rows={3}
          placeholder="Verified testimonial quote..."
          value={newTestimonial.content}
          onChange={(e) => setNewTestimonial({ ...newTestimonial, content: e.target.value })}
          className="w-full px-3 py-2 rounded-xl bg-[#021008] border border-white/20 text-xs text-white"
          required
        />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
          <label className="flex items-center gap-2 text-xs text-white cursor-pointer">
            <input
              type="checkbox"
              checked={newTestimonial.permissionToPublish}
              onChange={(e) => setNewTestimonial({ ...newTestimonial, permissionToPublish: e.target.checked })}
              className="accent-[#3dff8f]"
            />
            <span>I have verified permission to publish this testimonial</span>
          </label>
          <button
            type="submit"
            className="px-4 py-2 rounded-xl text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] cursor-pointer"
          >
            Add Testimonial
          </button>
        </div>
      </form>

      {/* Edit Testimonial Form */}
      {editingTestId && (
        <div className="p-5 rounded-2xl bg-[#010e06] border border-[#3dff8f] space-y-3 max-w-2xl">
          <div className="flex justify-between items-center text-xs font-mono text-[#3dff8f]">
            <span>Editing Testimonial</span>
            <button onClick={() => setEditingTestId(null)} className="text-[#9fbfae] hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input
              type="text"
              value={editTestForm.name || ''}
              onChange={(e) => setEditTestForm({ ...editTestForm, name: e.target.value })}
              className="px-3 py-1.5 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
            />
            <input
              type="text"
              value={editTestForm.role || ''}
              onChange={(e) => setEditTestForm({ ...editTestForm, role: e.target.value })}
              className="px-3 py-1.5 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
            />
            <input
              type="text"
              value={editTestForm.organization || ''}
              onChange={(e) => setEditTestForm({ ...editTestForm, organization: e.target.value })}
              className="px-3 py-1.5 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
            />
          </div>
          <textarea
            rows={3}
            value={editTestForm.content || ''}
            onChange={(e) => setEditTestForm({ ...editTestForm, content: e.target.value })}
            className="w-full px-3 py-2 rounded-lg bg-[#010904] border border-white/20 text-xs text-white"
          />
          <div className="flex justify-end gap-2">
            <button onClick={() => setEditingTestId(null)} className="px-3 py-1.5 rounded-lg text-xs border border-white/20">
              Cancel
            </button>
            <button onClick={handleSaveTestEdit} className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-[#3dff8f] text-black">
              Save Changes
            </button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {data.testimonials.map((t) => (
          <div
            key={t.id}
            className="p-4 sm:p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.18)] hover:border-[#3dff8f]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all"
          >
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-sm text-[#fff1b8]">{t.name}</span>
                <span className="text-xs text-[#9fbfae]">({t.role} · {t.organization})</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0a351e] text-[#3dff8f]">
                  {t.permissionToPublish ? 'Verified & Authorized' : 'Pending Authorization'}
                </span>
                {!t.published && (
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-rose-950 text-rose-300">
                    Draft
                  </span>
                )}
              </div>
              <p className="text-xs text-[#9fbfae] mt-1.5 italic line-clamp-2">"{t.content}"</p>
            </div>

            <div className="flex items-center gap-1.5 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-white/5">
              <button
                onClick={() => setPreviewTest(t)}
                className="p-2 rounded-xl text-xs text-[#3dff8f] bg-[#3dff8f]/10 hover:bg-[#3dff8f]/20 border border-[#3dff8f]/30 transition-all cursor-pointer flex items-center gap-1"
                title="View Full Testimonial & Preview"
              >
                <Eye className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">View</span>
              </button>
              <button
                onClick={() => {
                  setEditingTestId(t.id);
                  setEditTestForm(t);
                }}
                className="p-2 rounded-xl text-xs text-[#9fbfae] bg-white/5 hover:text-[#f0b92e] hover:border-[#f0b92e]/40 border border-white/10 transition-all cursor-pointer flex items-center gap-1"
                title="Edit Testimonial"
              >
                <Edit className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">Edit</span>
              </button>
              <button
                onClick={() => setDeleteTarget({ id: t.id, name: t.name })}
                className="p-2 rounded-xl text-xs text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-all cursor-pointer flex items-center gap-1"
                title="Delete Testimonial"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="font-mono text-[11px]">Delete</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Testimonial Preview Modal */}
      {previewTest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-[#010e06] border border-[#3dff8f] p-6 space-y-4 text-[#f4fff8] relative shadow-2xl">
            <button
              onClick={() => setPreviewTest(null)}
              className="absolute top-5 right-5 text-[#9fbfae] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#3dff8f]/15 text-[#3dff8f] border border-[#3dff8f]/30">
              {previewTest.permissionToPublish ? 'Verified & Authorized Endorsement' : 'Pending Authorization'}
            </span>

            <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
              {previewTest.name}
            </h3>
            <div className="text-xs text-[#3dff8f] font-mono">
              {previewTest.role} · {previewTest.organization}
            </div>

            <p className="text-xs sm:text-sm text-[#f4fff8] leading-relaxed p-4 rounded-xl bg-[#010904] border border-white/10 italic">
              "{previewTest.content}"
            </p>

            <div className="flex items-center justify-between pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => {
                  const toDel = previewTest;
                  setPreviewTest(null);
                  setDeleteTarget({ id: toDel.id, name: toDel.name });
                }}
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30 flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const toEdit = previewTest;
                    setPreviewTest(null);
                    setEditingTestId(toEdit.id);
                    setEditTestForm(toEdit);
                  }}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-[#f0b92e] text-black cursor-pointer"
                >
                  Edit
                </button>
                <button
                  onClick={() => {
                    portfolioStorage.updateData((prev) => ({
                      ...prev,
                      testimonials: prev.testimonials.map((item) =>
                        item.id === previewTest.id ? { ...item, published: !item.published } : item
                      )
                    }));
                    setPreviewTest({ ...previewTest, published: !previewTest.published });
                    onSave('Publish status updated');
                    onRefresh();
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer ${
                    previewTest.published ? 'bg-[#3dff8f]/20 text-[#3dff8f] border border-[#3dff8f]/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}
                >
                  {previewTest.published ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                  <span>{previewTest.published ? 'Live' : 'Draft'}</span>
                </button>

                <button
                  onClick={() => setPreviewTest(null)}
                  className="px-3 py-1.5 rounded-xl text-xs font-mono border border-white/20 text-[#9fbfae]"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* In-App Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm p-6 rounded-2xl bg-[#02100a] border border-rose-500/60 shadow-[0_0_40px_rgba(244,63,94,0.35)] space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-[#fff1b8]">Delete Testimonial?</h4>
              <p className="text-xs text-[#9fbfae] mt-1 leading-relaxed">
                Are you sure you want to delete testimonial from <span className="text-rose-300 font-bold">"{deleteTarget.name}"</span>?
              </p>
            </div>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="flex-1 py-2 px-3 rounded-xl border border-white/20 text-xs text-[#9fbfae] hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  handleDelete(deleteTarget.id);
                  setDeleteTarget(null);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-600 transition-all cursor-pointer shadow-lg"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Inquiries Inbox Tab                                            */
/* -------------------------------------------------------------------------- */
const InquiriesTab: React.FC<{
  data: PortfolioDatabase;
  onSave: (msg: string) => void;
  onRefresh: () => void;
}> = ({ data, onSave, onRefresh }) => {
  const [previewInquiry, setPreviewInquiry] = useState<ContactInquiry | null>(null);

  const handleDelete = (id: string) => {
    if (confirm('Delete this client inquiry?')) {
      portfolioStorage.updateData((prev) => ({
        ...prev,
        inquiries: prev.inquiries.filter((inq) => inq.id !== id)
      }));
      if (previewInquiry?.id === id) setPreviewInquiry(null);
      onSave('Inquiry removed');
      onRefresh();
    }
  };

  const handleOpenPreview = (inq: ContactInquiry) => {
    setPreviewInquiry(inq);
    if (!inq.read) {
      portfolioStorage.updateData((prev) => ({
        ...prev,
        inquiries: prev.inquiries.map((i) => (i.id === inq.id ? { ...i, read: true } : i))
      }));
      onRefresh();
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
          Client Inquiries Inbox ({data.inquiries.length})
        </h3>
        <p className="text-xs text-[#9fbfae]">
          Messages received through the Contact & Hire Me form are securely logged here.
        </p>
      </div>

      {data.inquiries.length === 0 ? (
        <div className="p-8 rounded-2xl bg-[#010904] border border-white/10 text-center text-xs text-[#9fbfae]">
          No messages received yet. Submit a test inquiry on the Contact section!
        </div>
      ) : (
        <div className="space-y-3">
          {data.inquiries.map((inq) => (
            <div
              key={inq.id}
              className={`p-4 sm:p-5 rounded-2xl bg-[#010904] border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                inq.read ? 'border-[rgba(240,185,46,0.18)]' : 'border-[#3dff8f] shadow-[0_0_15px_-4px_#3dff8f]'
              }`}
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <strong className="text-sm text-[#fff1b8]">{inq.name}</strong>
                  <span className="text-xs text-[#3dff8f]">({inq.email})</span>
                  {inq.organization && (
                    <span className="text-xs text-[#9fbfae]">· {inq.organization}</span>
                  )}
                  {!inq.read && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#3dff8f] text-black font-bold">
                      New
                    </span>
                  )}
                </div>

                <div className="flex flex-wrap gap-2 text-[11px] font-mono mt-1.5">
                  <span className="px-2 py-0.5 rounded bg-[#0a351e] text-[#3dff8f]">
                    {inq.serviceRequired}
                  </span>
                  {inq.budgetRange && (
                    <span className="px-2 py-0.5 rounded bg-[#f0b92e]/20 text-[#fff1b8]">
                      Budget: {inq.budgetRange}
                    </span>
                  )}
                  <span className="text-[10px] text-[#9fbfae] self-center">
                    {new Date(inq.timestamp).toLocaleDateString()}
                  </span>
                </div>

                <p className="text-xs text-[#f4fff8]/80 mt-2 line-clamp-1 italic">
                  "{inq.message}"
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-white/5">
                <button
                  onClick={() => handleOpenPreview(inq)}
                  className="p-2 rounded-xl text-xs text-[#3dff8f] bg-[#3dff8f]/10 hover:bg-[#3dff8f]/20 border border-[#3dff8f]/30 transition-all cursor-pointer flex items-center gap-1"
                  title="View & Read Full Message"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span className="font-mono text-[11px]">View</span>
                </button>
                <a
                  href={`mailto:${inq.email}?subject=${encodeURIComponent(`Re: Your Project Inquiry - ${inq.serviceRequired}`)}`}
                  className="p-2 rounded-xl text-xs text-[#9fbfae] bg-white/5 hover:text-[#f0b92e] hover:border-[#f0b92e]/40 border border-white/10 transition-all cursor-pointer flex items-center gap-1"
                  title="Reply via Email"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span className="font-mono text-[11px]">Reply</span>
                </a>
                <button
                  onClick={() => handleDelete(inq.id)}
                  className="p-2 rounded-xl text-xs text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-all cursor-pointer flex items-center gap-1"
                  title="Delete Inquiry"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="font-mono text-[11px]">Delete</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Inquiry Detail Preview Modal */}
      {previewInquiry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-[#010e06] border border-[#3dff8f] p-6 space-y-4 text-[#f4fff8] relative shadow-2xl">
            <button
              onClick={() => setPreviewInquiry(null)}
              className="absolute top-5 right-5 text-[#9fbfae] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[#3dff8f]/15 text-[#3dff8f] border border-[#3dff8f]/30">
              Client Project Inquiry
            </span>

            <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
              {previewInquiry.name}
            </h3>
            <div className="text-xs text-[#3dff8f] font-mono">
              Email: {previewInquiry.email} {previewInquiry.organization ? `· ${previewInquiry.organization}` : ''}
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-3 rounded-xl bg-[#010904] border border-white/10">
                <span className="text-[#9fbfae] block text-[10px]">Service:</span>
                <span className="text-[#fff1b8] font-bold">{previewInquiry.serviceRequired}</span>
              </div>
              <div className="p-3 rounded-xl bg-[#010904] border border-white/10">
                <span className="text-[#9fbfae] block text-[10px]">Budget & Timeline:</span>
                <span className="text-[#f0b92e] font-bold">{previewInquiry.budgetRange || 'Flexible'} · {previewInquiry.preferredTimeline || 'TBD'}</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#010904] border border-white/10 space-y-1">
              <span className="text-[10px] font-mono text-[#9fbfae] block">Message:</span>
              <p className="text-xs sm:text-sm text-[#f4fff8] whitespace-pre-line leading-relaxed">
                {previewInquiry.message}
              </p>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-white/10">
              <span className="text-[10px] font-mono text-[#9fbfae]">
                {new Date(previewInquiry.timestamp).toLocaleString()}
              </span>

              <div className="flex gap-2">
                <a
                  href={`mailto:${previewInquiry.email}?subject=${encodeURIComponent(`Re: Your Project Inquiry - ${previewInquiry.serviceRequired}`)}`}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] flex items-center gap-1.5"
                >
                  <Mail className="w-3.5 h-3.5 text-[#1a1200]" />
                  <span>Send Email Reply</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Backup & Restore Tab                                           */
/* -------------------------------------------------------------------------- */
const BackupTab: React.FC<{
  data: PortfolioDatabase;
  onSave: (msg: string) => void;
  onRefresh: () => void;
}> = ({ data, onSave, onRefresh }) => {
  const fileRef = useRef<HTMLInputElement>(null);

  const handleDownloadBackup = () => {
    const jsonStr = portfolioStorage.exportData();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `boniphace-portfolio-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    onSave('Backup JSON downloaded successfully');
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (portfolioStorage.importData(content)) {
        onSave('Data successfully restored from backup file!');
        onRefresh();
      } else {
        alert('Invalid backup file. Could not restore.');
      }
    };
    reader.readAsText(file);
  };

  const handleReset = () => {
    if (confirm('Reset portfolio to initial authentic defaults? This will erase custom additions unless backed up.')) {
      portfolioStorage.resetToDefaults();
      onSave('Reset to defaults complete');
      onRefresh();
    }
  };

  return (
    <div className="space-y-6 max-w-xl">
      <div>
        <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
          Backup & Disaster Recovery
        </h3>
        <p className="text-xs text-[#9fbfae]">
          Export your entire portfolio data, images, and projects into a portable JSON file. Restore it anytime on any browser.
        </p>
      </div>

      <div className="p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.2)] space-y-3">
        <h4 className="text-sm font-bold text-[#fff1b8]">1. Export Portfolio Backup</h4>
        <p className="text-xs text-[#9fbfae]">
          Download a complete snapshot of all services, skills, projects, and bio settings.
        </p>
        <button
          onClick={handleDownloadBackup}
          className="px-4 py-2 rounded-xl text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] flex items-center gap-1.5 cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-[#1a1200]" />
          <span>Download Backup (.JSON)</span>
        </button>
      </div>

      <div className="p-5 rounded-2xl bg-[#010904] border border-[rgba(240,185,46,0.2)] space-y-3">
        <h4 className="text-sm font-bold text-[#fff1b8]">2. Restore from Backup File</h4>
        <p className="text-xs text-[#9fbfae]">
          Select a previously exported portfolio JSON file to instantly restore.
        </p>
        <input
          ref={fileRef}
          type="file"
          accept=".json"
          onChange={handleImportFile}
          className="text-xs text-[#9fbfae] file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:bg-[#0a351e] file:text-[#3dff8f] file:text-xs cursor-pointer"
        />
      </div>

      <div className="p-5 rounded-2xl bg-rose-950/20 border border-rose-900/40 space-y-3">
        <h4 className="text-sm font-bold text-rose-300">3. Reset to Verified Clean Defaults</h4>
        <p className="text-xs text-[#9fbfae]">
          Resets all sections to Boniphace Ndege's default creative portfolio schema.
        </p>
        <button
          onClick={handleReset}
          className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-900/60 text-rose-200 hover:bg-rose-900 border border-rose-500/30 flex items-center gap-1.5 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset to Clean Defaults</span>
        </button>
      </div>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/* Sub-module: Security Tab                                                   */
/* -------------------------------------------------------------------------- */
const SecurityTab: React.FC<{ onSave: (msg: string) => void }> = ({ onSave }) => {
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [error, setError] = useState('');

  const handleChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (portfolioStorage.changePasscode(currentPass, newPass)) {
      onSave('Passcode updated successfully!');
      setCurrentPass('');
      setNewPass('');
      setError('');
    } else {
      setError('Current passcode incorrect or new passcode too short (min 4 chars).');
    }
  };

  return (
    <div className="space-y-6 max-w-md">
      <div>
        <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8]">
          Admin Passcode & Security
        </h3>
        <p className="text-xs text-[#9fbfae]">
          Change the master passcode used to authenticate into this management dashboard.
        </p>
      </div>

      <form onSubmit={handleChange} className="space-y-4 p-5 rounded-2xl bg-[#010904] border border-white/10">
        <div>
          <label className="text-xs text-[#9fbfae] block mb-1">Current Passcode</label>
          <input
            type="password"
            required
            value={currentPass}
            onChange={(e) => setCurrentPass(e.target.value)}
            className="w-full px-3 py-2 rounded-lg bg-[#021008] border border-white/20 text-xs text-white"
          />
        </div>

        <div>
          <label className="text-xs text-[#9fbfae] block mb-1">New Passcode</label>
          <input
            type="password"
            required
            value={newPass}
            onChange={(e) => setNewPass(e.target.value)}
            placeholder="At least 4 characters"
            className="w-full px-3 py-2 rounded-lg bg-[#021008] border border-white/20 text-xs text-white"
          />
        </div>

        {error && <p className="text-xs text-rose-400 font-mono">{error}</p>}

        <button
          type="submit"
          className="px-5 py-2 rounded-xl text-xs font-bold bg-[#3dff8f] text-black cursor-pointer"
        >
          Update Passcode
        </button>
      </form>
    </div>
  );
};

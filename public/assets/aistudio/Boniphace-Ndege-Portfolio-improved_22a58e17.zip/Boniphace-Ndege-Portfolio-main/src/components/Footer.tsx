import React from 'react';
import { ProfileData } from '../data/portfolioStorage';
import { LOGO_DATA_URI } from '../assets/logo';
import { ArrowUp, Github, Linkedin, Instagram, Facebook, Mail, Phone, Lock, Unlock } from 'lucide-react';

interface FooterProps {
  profile: ProfileData;
  onOpenAdmin: () => void;
  isAdminAuthenticated: boolean;
}

export const Footer: React.FC<FooterProps> = ({
  profile,
  onOpenAdmin,
  isAdminAuthenticated
}) => {
  return (
    <footer className="border-t border-[rgba(240,185,46,0.28)] py-12 bg-[#010603] text-[#9fbfae] text-sm">
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-[rgba(240,185,46,0.15)]">
          {/* Brand info */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full overflow-hidden p-0.5 bg-gradient-to-br from-[#f0b92e] to-[#0f7a43] shrink-0">
              <img
                src={profile.logoPhoto || LOGO_DATA_URI}
                alt={profile.name}
                className="w-full h-full object-cover rounded-full mix-blend-screen bg-black"
              />
            </div>
            <div>
              <div className="font-serif-heading font-extrabold text-base text-[#f4fff8]">
                {profile.name}
              </div>
              <div className="text-xs text-[#3dff8f] font-mono">
                Graphic Designer · Website Designer & Developer · Digital Content Creator
              </div>
            </div>
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-3">
            {profile.socialLinks.github && (
              <a
                href={profile.socialLinks.github}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-[#02140b] border border-[rgba(240,185,46,0.25)] flex items-center justify-center text-[#9fbfae] hover:text-[#3dff8f] hover:border-[#3dff8f] transition-all"
                aria-label="GitHub profile"
              >
                <Github className="w-4 h-4" />
              </a>
            )}
            {profile.socialLinks.linkedin && (
              <a
                href={profile.socialLinks.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-[#02140b] border border-[rgba(240,185,46,0.25)] flex items-center justify-center text-[#9fbfae] hover:text-[#3dff8f] hover:border-[#3dff8f] transition-all"
                aria-label="LinkedIn profile"
              >
                <Linkedin className="w-4 h-4" />
              </a>
            )}
            {profile.socialLinks.instagram && (
              <a href={profile.socialLinks.instagram} target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-full bg-[#02140b] border border-[rgba(240,185,46,0.25)] flex items-center justify-center text-[#9fbfae] hover:text-[#3dff8f] hover:border-[#3dff8f] transition-all" aria-label="Instagram profile">
                <Instagram className="w-4 h-4" />
              </a>
            )}
            {profile.socialLinks.facebook && (
              <a href={profile.socialLinks.facebook} target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-full bg-[#02140b] border border-[rgba(240,185,46,0.25)] flex items-center justify-center text-[#9fbfae] hover:text-[#3dff8f] hover:border-[#3dff8f] transition-all" aria-label="Facebook profile">
                <Facebook className="w-4 h-4" />
              </a>
            )}
            <a
              href={`mailto:${profile.email}`}
              className="w-9 h-9 rounded-full bg-[#02140b] border border-[rgba(240,185,46,0.25)] flex items-center justify-center text-[#9fbfae] hover:text-[#f0b92e] hover:border-[#f0b92e] transition-all"
              aria-label="Send Email"
            >
              <Mail className="w-4 h-4" />
            </a>
            <a
              href={`https://wa.me/${profile.whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-9 h-9 rounded-full bg-[#02140b] border border-[rgba(240,185,46,0.25)] flex items-center justify-center text-[#9fbfae] hover:text-[#3dff8f] hover:border-[#3dff8f] transition-all"
              aria-label="WhatsApp"
            >
              <Phone className="w-4 h-4" />
            </a>
          </div>

          {/* Back to top */}
          <a
            href="#top"
            className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-[#f0b92e] hover:text-white transition-colors"
          >
            <span>Back to top</span>
            <ArrowUp className="w-4 h-4" />
          </a>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#9fbfae]">
          <div>
            © 2026 {profile.name}. All rights reserved. Creative design & responsive websites based in {profile.location}.
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-1.5 text-xs text-[#9fbfae] hover:text-[#3dff8f] font-mono cursor-pointer"
            >
              {isAdminAuthenticated ? <Unlock className="w-3.5 h-3.5 text-[#3dff8f]" /> : <Lock className="w-3.5 h-3.5 text-[#f0b92e]" />}
              <span>{isAdminAuthenticated ? 'Admin Dashboard (Active)' : 'Admin Portal Login'}</span>
            </button>
            <span className="text-white/20">•</span>
            <span className="text-[11px] font-mono text-[#3dff8f]">
              AI-Enabled Workflow
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};

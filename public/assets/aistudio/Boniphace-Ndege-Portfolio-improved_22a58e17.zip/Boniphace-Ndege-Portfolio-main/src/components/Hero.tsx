import React from 'react';
import { ProfileData } from '../data/portfolioStorage';
import { LOGO_DATA_URI } from '../assets/logo';
import {
  ArrowRight,
  Palette,
  Layout,
  Sparkles,
  MapPin,
  FileText,
  Send,
  MessageSquare,
  CheckCircle2
} from 'lucide-react';

interface HeroProps {
  profile: ProfileData;
  onExploreProjects: () => void;
  onContactClick: () => void;
  onOpenResume: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  profile,
  onExploreProjects,
  onContactClick,
  onOpenResume,
}) => {
  return (
    <section id="top" className="relative min-h-[90vh] flex items-center pt-28 pb-16 overflow-hidden">
      {/* Background radial gradient glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[720px] h-[520px] bg-gradient-to-tr from-[#0a5a31]/25 via-[#0f7a43]/15 to-transparent rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-[1240px] mx-auto px-4 sm:px-6 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          
          {/* Left Column: Hero Text & Action Buttons */}
          <div className="lg:col-span-7 flex flex-col items-start z-10">
            {/* Availability Pill */}
            <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full border border-[rgba(240,185,46,0.3)] bg-[#02180d]/85 backdrop-blur-md text-[#fff1b8] text-xs sm:text-sm font-medium mb-5 shadow-lg shadow-[#0a3d22]/30">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#3dff8f] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#3dff8f] shadow-[0_0_10px_#3dff8f]"></span>
              </span>
              <span>{profile.availability}</span>
            </div>

            {/* Main Name Heading with Gold Gradient */}
            <h1 className="text-4xl sm:text-6xl xl:text-7xl font-extrabold font-serif-heading tracking-tight leading-[1.05] mb-3">
              <span className="gold-text block drop-shadow-sm">
                {profile.name}
              </span>
            </h1>

            {/* Three Primary Titles from User Prompt */}
            <div className="text-base sm:text-xl lg:text-2xl text-[#3dff8f] font-semibold tracking-wide mb-3 drop-shadow-[0_0_16px_rgba(61,255,143,0.35)] flex flex-wrap items-center gap-x-2 gap-y-1 font-serif-heading">
              <span>Graphic Designer</span>
              <span className="text-[#f0b92e] font-sans">•</span>
              <span>Website Designer & Developer</span>
              <span className="text-[#f0b92e] font-sans">•</span>
              <span>Digital Content Creator</span>
            </div>

            {/* Main Headline */}
            <div className="text-lg sm:text-2xl font-bold font-serif-heading text-[#fff1b8] mb-4">
              "{profile.headline}"
            </div>

            {/* Location tag */}
            <div className="flex items-center gap-2 text-xs sm:text-sm text-[#9fbfae] mb-5 font-mono">
              <MapPin className="w-4 h-4 text-[#f0b92e]" />
              <span>{profile.location}</span>
              <span className="text-[#f0b92e]/40">•</span>
              <span className="text-[#3dff8f]">Creative & Digital Tech</span>
            </div>

            {/* Supporting Text */}
            <p className="text-sm sm:text-base lg:text-lg text-[#9fbfae] max-w-[600px] leading-relaxed mb-7">
              I create visual identities, modern websites, and engaging digital content by combining creative thinking, modern design tools, web technologies, and AI-assisted workflows.
            </p>

            {/* The 4 Required Buttons */}
            <div className="flex flex-wrap gap-3 items-center mb-8 w-full sm:w-auto">
              {/* 1. Explore My Projects */}
              <a
                href="#projects"
                onClick={(e) => {
                  e.preventDefault();
                  onExploreProjects();
                }}
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full font-bold text-xs sm:text-sm text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] hover:from-white hover:to-[#f0b92e] shadow-[0_0_0_1px_rgba(255,255,255,0.2)_inset,0_6px_22px_-6px_rgba(240,185,46,0.7)] hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer"
              >
                <span>Explore My Projects</span>
                <ArrowRight className="w-4 h-4 text-[#1a1200]" />
              </a>

              {/* 2. Hire Me */}
              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  onContactClick();
                }}
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full font-bold text-xs sm:text-sm text-[#3dff8f] bg-transparent border border-[#3dff8f] shadow-[0_0_18px_-8px_#3dff8f] hover:bg-[#3dff8f]/10 hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Hire Me</span>
              </a>

              {/* 3. Download My CV */}
              <button
                onClick={onOpenResume}
                className="inline-flex items-center justify-center gap-2 px-4 py-3 rounded-full text-xs sm:text-sm font-semibold text-[#f4fff8] border border-[rgba(240,185,46,0.3)] hover:border-[#f0b92e] hover:text-[#f0b92e] bg-[#02100a]/80 transition-all cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5 text-[#f0b92e]" />
                <span>Download My CV</span>
              </button>

              {/* 4. Contact Me */}
              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  onContactClick();
                }}
                className="inline-flex items-center justify-center gap-2 px-4 py-3 rounded-full text-xs sm:text-sm font-semibold text-[#9fbfae] hover:text-[#fff1b8] border border-white/10 hover:border-white/30 bg-[#02100a]/50 transition-all cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Contact Me</span>
              </a>
            </div>

            {/* Authentic Core Pillars / Highlights (No fabricated enterprise statistics) */}
            <div className="w-full pt-5 border-t border-[rgba(240,185,46,0.2)] grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-[#021208] border border-[rgba(240,185,46,0.15)] flex flex-col">
                <span className="text-xs font-mono font-bold text-[#f0b92e]">Visual Branding</span>
                <span className="text-[11px] text-[#9fbfae] mt-0.5">Logos & Style Guides</span>
              </div>
              <div className="p-3 rounded-xl bg-[#021208] border border-[rgba(240,185,46,0.15)] flex flex-col">
                <span className="text-xs font-mono font-bold text-[#3dff8f]">Responsive Web</span>
                <span className="text-[11px] text-[#9fbfae] mt-0.5">Mobile-First UI/UX</span>
              </div>
              <div className="p-3 rounded-xl bg-[#021208] border border-[rgba(240,185,46,0.15)] flex flex-col">
                <span className="text-xs font-mono font-bold text-[#f0b92e]">Digital Content</span>
                <span className="text-[11px] text-[#9fbfae] mt-0.5">Flyers, Posters & Media</span>
              </div>
              <div className="p-3 rounded-xl bg-[#021208] border border-[rgba(240,185,46,0.15)] flex flex-col">
                <span className="text-xs font-mono font-bold text-[#3dff8f]">AI Workflows</span>
                <span className="text-[11px] text-[#9fbfae] mt-0.5">Modern Tooling</span>
              </div>
            </div>
          </div>

          {/* Right Column: Creative Monogram & Profile Visual */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center relative">
            <div className="relative w-full max-w-[400px] aspect-square flex items-center justify-center">
              
              {/* Radial Neon Glow */}
              <div className="absolute w-[85%] aspect-square rounded-full bg-radial from-[#3dff8f]/25 via-[#0f7a43]/18 to-transparent blur-3xl animate-pulse-glow" />

              {/* Decorative Concentric Graphic Rings */}
              <div className="absolute inset-0 rounded-full border border-[#f0b92e]/20 border-dashed animate-[spin_60s_linear_infinite]" />
              <div className="absolute inset-4 rounded-full border border-[#3dff8f]/20" />
              
              {/* Monogram / Profile Showcase */}
              <div className="relative z-10 w-[82%] aspect-square rounded-3xl overflow-hidden p-1.5 bg-gradient-to-br from-[#f0b92e]/80 via-[#0f7a43]/60 to-[#3dff8f]/80 shadow-[0_20px_50px_rgba(0,0,0,0.85)] animate-floating group">
                <div className="w-full h-full rounded-[22px] overflow-hidden bg-[#010904] flex items-center justify-center p-3 relative">
                  <img
                    src={profile.profilePhoto || profile.logoPhoto || LOGO_DATA_URI}
                    alt={profile.name}
                    className="w-full h-full object-contain mix-blend-screen drop-shadow-[0_15px_35px_rgba(61,255,143,0.3)] transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent pointer-events-none" />
                </div>
              </div>

              {/* Floating Badges highlighting authentic creative skills */}
              <div className="absolute -top-3 -right-2 z-20 bg-[#02180d]/90 border border-[#3dff8f]/40 backdrop-blur-md rounded-2xl p-2.5 sm:p-3 shadow-xl flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#3dff8f]/10 flex items-center justify-center text-[#3dff8f]">
                  <Palette className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[10px] font-mono text-[#9fbfae]">Graphic Design</div>
                  <div className="text-xs font-bold text-[#f4fff8]">Logos & Branding</div>
                </div>
              </div>

              <div className="absolute -bottom-4 -left-2 z-20 bg-[#02180d]/90 border border-[#f0b92e]/40 backdrop-blur-md rounded-2xl p-2.5 sm:p-3 shadow-xl flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#f0b92e]/10 flex items-center justify-center text-[#f0b92e]">
                  <Layout className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[10px] font-mono text-[#9fbfae]">Modern Web</div>
                  <div className="text-xs font-bold text-[#f4fff8]">Responsive Websites</div>
                </div>
              </div>
            </div>

            {/* Quick Skills Pill Bar */}
            <div className="mt-7 flex flex-wrap items-center justify-center gap-2">
              {['Photoshop', 'Illustrator', 'Figma', 'HTML/CSS', 'JavaScript', 'React', 'AI Tools'].map((tool) => (
                <span
                  key={tool}
                  className="px-2.5 py-1 rounded-md text-xs font-mono bg-[#031c10]/80 border border-[rgba(240,185,46,0.2)] text-[#9fbfae]"
                >
                  {tool}
                </span>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

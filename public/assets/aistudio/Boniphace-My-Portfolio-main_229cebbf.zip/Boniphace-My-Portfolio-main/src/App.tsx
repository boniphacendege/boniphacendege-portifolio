/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { portfolioStorage, ProjectItem } from './data/portfolioStorage';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { Projects } from './components/Projects';
import { Skills } from './components/Skills';
import { Experience } from './components/Experience';
import { AIWorkflow } from './components/AIWorkflow';
import { Testimonials } from './components/Testimonials';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { AIAssistant } from './components/AIAssistant';
import { ResumeModal } from './components/ResumeModal';
import { ProjectModal } from './components/ProjectModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { GoogleMapModal } from './components/GoogleMapModal';

export default function App() {
  // Reactive state loaded from persistent storage
  const [data, setData] = useState(() => portfolioStorage.getData());
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(() => portfolioStorage.isAuthenticated());

  // Modal states
  const [resumeOpen, setResumeOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [activeProject, setActiveProject] = useState<ProjectItem | null>(null);
  const [mapOpen, setMapOpen] = useState(false);

  // Contact form pre-fill parameters
  const [preSelectedService, setPreSelectedService] = useState('');
  const [preFilledMessage, setPreFilledMessage] = useState('');

  // Subscribe to storage updates so UI reflects admin edits immediately
  useEffect(() => {
    const unsubscribe = portfolioStorage.subscribe(() => {
      setData({ ...portfolioStorage.getData() });
      setIsAdminAuthenticated(portfolioStorage.isAuthenticated());
    });
    return () => unsubscribe();
  }, []);

  // Keyboard shortcut (Ctrl + Shift + A) to open Admin Dashboard
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'a' || e.key === 'A')) {
        e.preventDefault();
        setAdminOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleRequestService = (serviceTitle: string) => {
    setPreSelectedService(serviceTitle);
    setPreFilledMessage(`Hello Boniphace,\n\nI would like to inquire about your "${serviceTitle}" service. Let's discuss requirements and project timing.`);
    scrollToSection('contact');
  };

  const handleInquireProject = (projectTitle: string) => {
    setPreFilledMessage(`Hello Boniphace,\n\nI reviewed your "${projectTitle}" project case study and would like to collaborate on a similar project.`);
    scrollToSection('contact');
  };

  return (
    <div className="min-h-screen bg-[#010503] text-[#f4fff8] font-sans antialiased selection:bg-[#3dff8f]/20 selection:text-[#3dff8f]">
      {/* 1. Header Navigation */}
      <Header
        profile={data.profile}
        onOpenResume={() => setResumeOpen(true)}
        onOpenAdmin={() => setAdminOpen(true)}
        onOpenChat={() => setChatOpen(true)}
        isAdminAuthenticated={isAdminAuthenticated}
        onOpenMap={() => setMapOpen(true)}
      />

      {/* Main Content Sections */}
      <main>
        {/* Section 1: Home / Hero */}
        <Hero
          profile={data.profile}
          onExploreProjects={() => scrollToSection('projects')}
          onContactClick={() => scrollToSection('contact')}
          onOpenResume={() => setResumeOpen(true)}
          onOpenMap={() => setMapOpen(true)}
        />

        {/* Section 2: About Me */}
        <About
          profile={data.profile}
          onHireMeClick={() => scrollToSection('contact')}
          onOpenResume={() => setResumeOpen(true)}
        />

        {/* Section 3: Services */}
        <Services
          services={data.services}
          onRequestService={handleRequestService}
        />

        {/* Section 4: Portfolio / Projects */}
        <Projects
          projects={data.projects}
          categories={data.categories}
          onSelectProject={(project) => setActiveProject(project)}
          onAddNewProject={() => setAdminOpen(true)}
        />

        {/* Section 5: Skills & Tools */}
        <Skills
          skills={data.skills}
          onOpenAdmin={() => setAdminOpen(true)}
        />

        {/* Section 6, 7, 8: Work Experience, Education, Certifications & Achievements */}
        <Experience
          workExperience={data.workExperience}
          education={data.education}
          certifications={data.certifications}
          achievements={data.achievements}
          onOpenAdmin={() => setAdminOpen(true)}
        />

        {/* Section 9: AI & Digital Workflow */}
        <AIWorkflow
          stages={data.workflowStages}
          onOpenChat={() => setChatOpen(true)}
        />

        {/* Section 10: Testimonials */}
        <Testimonials
          testimonials={data.testimonials}
          onOpenAdmin={() => setAdminOpen(true)}
        />

        {/* Section 12: Contact / Hire Me */}
        <Contact
          profile={data.profile}
          services={data.services}
          preSelectedService={preSelectedService}
          preFilledMessage={preFilledMessage}
          onOpenMap={() => setMapOpen(true)}
        />
      </main>

      {/* Footer */}
      <Footer
        profile={data.profile}
        onOpenAdmin={() => setAdminOpen(true)}
        isAdminAuthenticated={isAdminAuthenticated}
      />

      {/* Floating AI Assistant Drawer */}
      <AIAssistant
        isOpen={chatOpen}
        onToggle={() => setChatOpen((prev) => !prev)}
        profile={data.profile}
      />

      {/* Google GPS Map Modal for Dodoma CBD */}
      <GoogleMapModal
        isOpen={mapOpen}
        onClose={() => setMapOpen(false)}
        locationTitle={data.profile.location}
      />

      {/* Section 11: CV / Resume Builder Modal */}
      <ResumeModal
        isOpen={resumeOpen}
        onClose={() => setResumeOpen(false)}
        profile={data.profile}
        skills={data.skills}
        experience={data.workExperience}
        education={data.education}
        certifications={data.certifications}
        projects={data.projects}
      />

      {/* Project Case Study Deep-Dive Modal */}
      <ProjectModal
        project={activeProject}
        onClose={() => setActiveProject(null)}
        onInquireSimilar={handleInquireProject}
      />

      {/* Section 14: Secure Full-Featured Admin Dashboard */}
      <AdminDashboard
        isOpen={adminOpen}
        onClose={() => setAdminOpen(false)}
        data={data}
        onDataChanged={() => setData({ ...portfolioStorage.getData() })}
      />
    </div>
  );
}

import React from 'react';
import {
  ProfileData,
  SkillItem,
  WorkExperienceItem,
  EducationItem,
  CertificationItem,
  ProjectItem
} from '../data/portfolioStorage';
import {
  X,
  Printer,
  Download,
  MapPin,
  Mail,
  Phone,
  CheckCircle2,
  ExternalLink,
  Briefcase,
  GraduationCap,
  Award,
  Wrench,
  Palette
} from 'lucide-react';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: ProfileData;
  skills: SkillItem[];
  experience: WorkExperienceItem[];
  education: EducationItem[];
  certifications: CertificationItem[];
  projects: ProjectItem[];
}

export const ResumeModal: React.FC<ResumeModalProps> = ({
  isOpen,
  onClose,
  profile,
  skills,
  experience,
  education,
  certifications,
  projects
}) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const publishedSkills = skills.filter((s) => s.published);
  const publishedExp = experience.filter((e) => e.published);
  const publishedEdu = education.filter((e) => e.published);
  const publishedCerts = certifications.filter((c) => c.published);
  const featuredProjects = projects.filter((p) => p.published && p.featured).slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-[820px] max-h-[92vh] bg-[#02100a] text-[#f4fff8] border border-[#f0b92e] rounded-[24px] shadow-[0_20px_70px_rgba(0,0,0,0.95)] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Modal Top Bar */}
        <div className="px-6 py-4 bg-[#010904] border-b border-[rgba(240,185,46,0.3)] flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-mono text-[#3dff8f]">
            <span className="w-2 h-2 rounded-full bg-[#3dff8f]" />
            <span>CURRICULUM VITAE — {profile.name.toUpperCase()}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-2 rounded-xl text-[#9fbfae] hover:text-[#f0b92e] hover:bg-[#0a351e]/40 transition-colors cursor-pointer"
              title="Print / Save as PDF"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-[#9fbfae] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="Close CV"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable CV Document Body */}
        <div className="p-6 sm:p-10 overflow-y-auto space-y-7 print:p-0">
          {/* Header */}
          <div className="border-b border-[rgba(240,185,46,0.25)] pb-6">
            <h2 className="text-3xl sm:text-4xl font-extrabold font-serif-heading gold-text mb-1">
              {profile.name}
            </h2>
            <div className="text-sm sm:text-base font-semibold text-[#3dff8f] mb-3">
              {profile.titles.join(' • ')}
            </div>
            <div className="flex flex-wrap gap-y-2 gap-x-5 text-xs text-[#9fbfae] font-mono">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#f0b92e]" />
                {profile.location}
              </span>
              <span className="flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-[#f0b92e]" />
                {profile.email}
              </span>
              <span className="flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-[#f0b92e]" />
                {profile.phone}
              </span>
            </div>
          </div>

          {/* Professional Summary */}
          <div>
            <h3 className="text-xs font-mono font-bold text-[#f0b92e] uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Palette className="w-4 h-4 text-[#f0b92e]" />
              <span>Professional Summary</span>
            </h3>
            <p className="text-xs sm:text-sm text-[#9fbfae] leading-relaxed">
              {profile.intro}
            </p>
          </div>

          {/* Core Skills & Tools */}
          <div>
            <h3 className="text-xs font-mono font-bold text-[#f0b92e] uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Wrench className="w-4 h-4 text-[#f0b92e]" />
              <span>Skills, Software & Creative Tools</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {publishedSkills.map((s) => (
                <div key={s.id} className="p-3 rounded-xl bg-[#010a05] border border-white/5 space-y-1">
                  <div className="flex justify-between items-baseline">
                    <strong className="text-[#fff1b8]">{s.name}</strong>
                    {s.proficiency && (
                      <span className="text-[10px] font-mono text-[#3dff8f]">{s.proficiency}%</span>
                    )}
                  </div>
                  {s.tools && s.tools.length > 0 && (
                    <div className="text-[11px] text-[#9fbfae] font-mono">
                      {s.tools.join(', ')}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Experience */}
          <div>
            <h3 className="text-xs font-mono font-bold text-[#f0b92e] uppercase tracking-wider mb-4 flex items-center gap-1.5">
              <Briefcase className="w-4 h-4 text-[#f0b92e]" />
              <span>Work & Freelance Experience</span>
            </h3>
            <div className="space-y-5">
              {publishedExp.map((exp) => (
                <div key={exp.id} className="space-y-1.5">
                  <div className="flex flex-wrap items-baseline justify-between gap-1">
                    <div className="font-bold text-sm sm:text-base text-[#fff1b8]">
                      {exp.roleTitle} · <span className="text-[#3dff8f] font-normal">{exp.employer}</span>
                    </div>
                    <span className="text-xs font-mono text-[#f0b92e]">
                      {exp.startDate} – {exp.current ? 'Present' : exp.endDate}
                    </span>
                  </div>
                  <p className="text-xs text-[#9fbfae] leading-relaxed">
                    {exp.description}
                  </p>
                  {exp.responsibilities && exp.responsibilities.length > 0 && (
                    <ul className="space-y-1 pt-1">
                      {exp.responsibilities.map((r, i) => (
                        <li key={i} className="text-xs text-[#f4fff8] flex items-start gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#3dff8f] shrink-0 mt-0.5" />
                          <span>{r}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Education */}
          <div>
            <h3 className="text-xs font-mono font-bold text-[#f0b92e] uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <GraduationCap className="w-4 h-4 text-[#f0b92e]" />
              <span>Education</span>
            </h3>
            <div className="space-y-3">
              {publishedEdu.map((edu) => (
                <div key={edu.id} className="space-y-1 text-xs">
                  <div className="flex justify-between items-baseline">
                    <strong className="text-sm text-[#fff1b8]">{edu.qualification}</strong>
                    <span className="font-mono text-[#f0b92e]">{edu.startDate} – {edu.endDate}</span>
                  </div>
                  <div className="text-[#3dff8f] font-mono">{edu.institution}</div>
                  {edu.description && <p className="text-[#9fbfae]">{edu.description}</p>}
                </div>
              ))}
            </div>
          </div>

          {/* Certifications */}
          {publishedCerts.length > 0 && (
            <div>
              <h3 className="text-xs font-mono font-bold text-[#f0b92e] uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-[#f0b92e]" />
                <span>Certifications</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {publishedCerts.map((c) => (
                  <div key={c.id} className="p-2.5 rounded-lg bg-[#010904] border border-white/5 flex justify-between items-center">
                    <div>
                      <div className="font-bold text-[#fff1b8]">{c.title}</div>
                      <div className="text-[11px] text-[#9fbfae]">{c.issuingOrg}</div>
                    </div>
                    <span className="font-mono text-[10px] text-[#3dff8f]">{c.date}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Selected Work Portfolio Highlights */}
          {featuredProjects.length > 0 && (
            <div>
              <h3 className="text-xs font-mono font-bold text-[#f0b92e] uppercase tracking-wider mb-3">
                Selected Portfolio Projects
              </h3>
              <div className="space-y-2 text-xs">
                {featuredProjects.map((p) => (
                  <div key={p.id} className="p-2.5 rounded-lg bg-[#010904] border border-white/5">
                    <div className="font-bold text-[#fff1b8]">{p.title} ({p.category})</div>
                    <p className="text-[#9fbfae] text-[11px] mt-0.5">{p.summary}</p>
                    <div className="text-[#3dff8f] font-mono text-[10px] mt-1">Tools: {p.tools.join(', ')}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="px-6 py-4 bg-[#010904] border-t border-[rgba(240,185,46,0.3)] flex items-center justify-between">
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-mono font-bold text-[#3dff8f] border border-[#3dff8f]/40 hover:bg-[#3dff8f]/10 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Print / Save PDF</span>
          </button>
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-full font-bold text-xs sm:text-sm text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] hover:from-white hover:to-[#f0b92e] shadow-md cursor-pointer"
          >
            Close CV
          </button>
        </div>
      </div>
    </div>
  );
};

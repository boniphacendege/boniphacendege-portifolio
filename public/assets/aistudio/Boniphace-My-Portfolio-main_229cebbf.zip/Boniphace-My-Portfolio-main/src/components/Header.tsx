import React, { useState, useEffect } from 'react';
import { ProfileData } from '../data/portfolioStorage';
import {
  Menu,
  X,
  FileText,
  Lock,
  Unlock,
  Sparkles,
  Send,
  Phone,
  Mail,
  MapPin,
  ExternalLink,
  Heart,
  Briefcase,
  Layers,
  Award,
  MessageSquare,
  Calculator,
  Compass,
  ArrowRight,
  Facebook,
  Linkedin,
  Instagram,
  Github
} from 'lucide-react';
import { GoogleLocationIcon } from './GoogleLocationIcon';

interface HeaderProps {
  profile: ProfileData;
  onOpenResume: () => void;
  onOpenAdmin: () => void;
  onOpenChat: () => void;
  isAdminAuthenticated: boolean;
  onOpenMap?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  profile,
  onOpenResume,
  onOpenAdmin,
  onOpenChat,
  isAdminAuthenticated,
  onOpenMap
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [favoriteCount, setFavoriteCount] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Update favorite count for user
  useEffect(() => {
    try {
      const stored = localStorage.getItem('boniphace_favorites_map');
      if (stored) {
        const map = JSON.parse(stored);
        setFavoriteCount(Object.values(map).filter(Boolean).length);
      }
    } catch {}
  }, [sidebarOpen]);

  const navLinks = [
    { name: 'Home', href: '#top', desc: 'Welcome & Highlights' },
    { name: 'About', href: '#about', desc: 'Creative Philosophy & Bio' },
    { name: 'Services', href: '#services', desc: 'Design & Web Solutions' },
    { name: 'Projects', href: '#projects', desc: 'Portfolio Showcase' },
    { name: 'Skills', href: '#skills', desc: 'Tools & Competencies' },
    { name: 'Experience', href: '#experience', desc: 'Career & Freelance (2022–Present)' },
    { name: 'AI Workflow', href: '#workflow', desc: 'Human + AI Collaboration' },
    { name: 'Testimonials', href: '#testimonials', desc: 'Verified Client Reviews' },
    { name: 'Contact', href: '#contact', desc: 'Start a Project' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#052e1b]/95 backdrop-blur-md shadow-2xl py-2.5'
            : 'bg-[#052e1b]/88 backdrop-blur-sm shadow-lg py-3.5'
        }`}
      >
        {/* Top shining very narrow green neon line */}
        <div aria-hidden="true" className="header-neon-line top-0" />

        {/* Down (bottom) shining very narrow green neon line */}
        <div aria-hidden="true" className="header-neon-line bottom-0" />

        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 flex items-center justify-between gap-4">
          {/* LEFT: Site Name ONLY */}
          <a
            href="#top"
            className="flex items-center group focus:outline-none"
            aria-label="Boniphace Ndege"
          >
            <span className="font-serif-heading font-extrabold text-xl sm:text-2xl tracking-tight header-name-blink whitespace-nowrap select-none">
              {profile.name || 'Boniphace Ndege'}
            </span>
          </a>

          {/* FAR RIGHT EDGE: Mobile-Responsive Navigation Toggle Icon */}
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 sm:p-2.5 rounded-xl text-[#f0b92e] border border-[rgba(240,185,46,0.35)] hover:border-[#3dff8f] hover:text-[#3dff8f] bg-[#02140b] active:scale-95 transition-all cursor-pointer flex items-center justify-center shadow-[0_0_14px_rgba(240,185,46,0.18)] shrink-0 ml-auto"
            aria-label="Toggle navigation menu"
            title="Open navigation menu"
          >
            <Menu className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
        </div>
      </header>

      {/* Backdrop overlay for Sidebar */}
      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          className="fixed inset-0 z-40 bg-black/75 backdrop-blur-xs transition-opacity duration-200"
        />
      )}

      {/* RIGHT-SIDE NAVIGATION & USER FEATURES DRAWER */}
      {sidebarOpen && (
        <aside
          className="fixed inset-y-0 right-0 top-0 z-50 w-full sm:w-96 bg-[#010904]/98 border-l border-[rgba(240,185,46,0.35)] shadow-[0_0_60px_rgba(0,0,0,0.95)] overflow-y-auto flex flex-col justify-between animate-in slide-in-from-right duration-200"
          aria-label="Sidebar Navigation Menu"
        >
          {/* Sidebar Top: Profile & Close */}
          <div className="p-5 sm:p-6 space-y-5">
            <div className="flex items-center justify-between pb-4 border-b border-[rgba(240,185,46,0.25)]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl overflow-hidden bg-black border border-[#f0b92e]/40 p-0.5 shrink-0">
                  <img
                    src={profile.profilePhoto || profile.logoPhoto}
                    alt={profile.name}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
                <div>
                  <h3 className="font-serif-heading font-extrabold text-base text-[#fff1b8] leading-tight">
                    {profile.name}
                  </h3>
                  <div className="text-[10px] font-mono text-[#3dff8f] flex items-center gap-1.5 mt-0.5">
                    <span className="w-2 h-2 rounded-full bg-[#3dff8f] animate-pulse" />
                    <span>Available for Projects</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setSidebarOpen(false)}
                className="p-2 rounded-xl text-[#9fbfae] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                aria-label="Close menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Location & Contact Bar with Google Location Icon */}
            <div className="p-3.5 rounded-2xl bg-[#02140b] border border-[rgba(240,185,46,0.2)] space-y-2 text-xs">
              <button
                type="button"
                onClick={() => {
                  setSidebarOpen(false);
                  if (onOpenMap) {
                    onOpenMap();
                  } else {
                    window.open('https://www.google.com/maps/search/?api=1&query=Dodoma+CBD+Tanzania', '_blank', 'noopener,noreferrer');
                  }
                }}
                className="w-full flex items-center justify-between text-left group p-1.5 rounded-xl hover:bg-[#032a14] border border-transparent hover:border-[#3dff8f]/40 transition-all cursor-pointer"
                title="Click to view Dodoma CBD in Google GPS Map"
              >
                <div className="flex items-center gap-2 text-[#fff1b8] group-hover:text-[#3dff8f] transition-colors">
                  <GoogleLocationIcon className="w-4 h-5" />
                  <span className="font-semibold">{profile.location || 'Dodoma CBD Tanzania'}</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#0a351e] text-[#3dff8f] border border-[#3dff8f]/30 font-mono">
                  GPS MAP
                </span>
              </button>
              <p className="text-[11px] text-[#9fbfae] leading-relaxed">
                Graphic Designer, Website Designer & Developer, and Digital Content Creator combining creativity and AI workflows.
              </p>

              {/* Social Channels in Drawer */}
              <div className="flex items-center gap-2 pt-2 border-t border-[rgba(240,185,46,0.15)]">
                {profile.socialLinks?.facebook && (
                  <a
                    href={profile.socialLinks.facebook}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-7 h-7 rounded-lg bg-[#010904] border border-[rgba(240,185,46,0.25)] flex items-center justify-center text-[#9fbfae] hover:text-[#3dff8f] hover:border-[#3dff8f] transition-all"
                    aria-label="Facebook profile"
                  >
                    <Facebook className="w-3.5 h-3.5" />
                  </a>
                )}
                {profile.socialLinks?.linkedin && (
                  <a
                    href={profile.socialLinks.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-7 h-7 rounded-lg bg-[#010904] border border-[rgba(240,185,46,0.25)] flex items-center justify-center text-[#9fbfae] hover:text-[#3dff8f] hover:border-[#3dff8f] transition-all"
                    aria-label="LinkedIn profile"
                  >
                    <Linkedin className="w-3.5 h-3.5" />
                  </a>
                )}
                {profile.socialLinks?.instagram && (
                  <a
                    href={profile.socialLinks.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-7 h-7 rounded-lg bg-[#010904] border border-[rgba(240,185,46,0.25)] flex items-center justify-center text-[#9fbfae] hover:text-[#3dff8f] hover:border-[#3dff8f] transition-all"
                    aria-label="Instagram profile"
                  >
                    <Instagram className="w-3.5 h-3.5" />
                  </a>
                )}
                {profile.socialLinks?.github && (
                  <a
                    href={profile.socialLinks.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-7 h-7 rounded-lg bg-[#010904] border border-[rgba(240,185,46,0.25)] flex items-center justify-center text-[#9fbfae] hover:text-[#3dff8f] hover:border-[#3dff8f] transition-all"
                    aria-label="GitHub profile"
                  >
                    <Github className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </div>

            {/* Quick User Action Cards (All features users need) */}
            <div className="space-y-2">
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#f0b92e] font-bold block px-1">
                User Quick Actions
              </span>

              <div className="grid grid-cols-2 gap-2">
                {/* 1. Download CV */}
                <button
                  onClick={() => {
                    setSidebarOpen(false);
                    onOpenResume();
                  }}
                  className="p-3 rounded-xl bg-[#02100a] border border-[rgba(240,185,46,0.25)] hover:border-[#f0b92e] hover:bg-[#f0b92e]/10 text-left transition-all cursor-pointer group"
                >
                  <FileText className="w-4 h-4 text-[#f0b92e] mb-1.5 group-hover:scale-110 transition-transform" />
                  <div className="text-xs font-bold text-[#fff1b8]">Curriculum Vitae</div>
                  <div className="text-[10px] text-[#9fbfae]">View & Download PDF</div>
                </button>

                {/* 2. Ask AI Assistant */}
                <button
                  onClick={() => {
                    setSidebarOpen(false);
                    onOpenChat();
                  }}
                  className="p-3 rounded-xl bg-[#02100a] border border-[#3dff8f]/25 hover:border-[#3dff8f] hover:bg-[#3dff8f]/10 text-left transition-all cursor-pointer group"
                >
                  <Sparkles className="w-4 h-4 text-[#3dff8f] mb-1.5 group-hover:scale-110 transition-transform" />
                  <div className="text-xs font-bold text-[#3dff8f]">AI Portfolio Guide</div>
                  <div className="text-[10px] text-[#9fbfae]">Interactive Assistant</div>
                </button>
              </div>

              {/* 3. Direct WhatsApp & Call Buttons */}
              <div className="grid grid-cols-2 gap-2">
                <a
                  href={`https://wa.me/${(profile.whatsapp || '255765326515').replace(/[^0-9]/g, '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-xl bg-[#0a351e]/80 border border-[#3dff8f]/30 hover:border-[#3dff8f] text-[#3dff8f] text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-[#3dff8f]" />
                  <span>WhatsApp Chat</span>
                </a>

                <a
                  href={`tel:${profile.phone || '+255765326515'}`}
                  className="p-2.5 rounded-xl bg-[#010e06] border border-white/10 hover:border-[#fff1b8] text-[#fff1b8] text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                >
                  <Phone className="w-3.5 h-3.5 text-[#f0b92e]" />
                  <span>Call Directly</span>
                </a>
              </div>

              {/* 4. User Favorites quick counter link */}
              {favoriteCount > 0 && (
                <a
                  href="#projects"
                  onClick={() => setSidebarOpen(false)}
                  className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-bold flex items-center justify-between transition-all"
                >
                  <span className="flex items-center gap-1.5">
                    <Heart className="w-3.5 h-3.5 fill-rose-400 text-rose-400" />
                    <span>Your Saved Projects</span>
                  </span>
                  <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-200">
                    {favoriteCount}
                  </span>
                </a>
              )}
            </div>

            {/* Navigation Links with Descriptions */}
            <div className="space-y-1.5 pt-2">
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#f0b92e] font-bold block px-1">
                Explore Sections
              </span>

              <nav className="flex flex-col gap-1">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    onClick={() => setSidebarOpen(false)}
                    className="py-2 px-3 rounded-xl text-xs sm:text-sm text-[#f4fff8] hover:text-[#3dff8f] hover:bg-[#3dff8f]/10 border border-transparent hover:border-[#3dff8f]/20 transition-all flex items-center justify-between group"
                  >
                    <div>
                      <span className="font-semibold group-hover:text-[#3dff8f]">{link.name}</span>
                      <span className="text-[10px] text-[#9fbfae] block">{link.desc}</span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-[#f0b92e]/40 group-hover:text-[#3dff8f] group-hover:translate-x-1 transition-all" />
                  </a>
                ))}
              </nav>
            </div>
          </div>

          {/* Sidebar Bottom: Contact CTA & Admin Access */}
          <div className="p-5 sm:p-6 bg-[#021008] border-t border-[rgba(240,185,46,0.2)] space-y-3 shrink-0">
            <a
              href="#contact"
              onClick={() => setSidebarOpen(false)}
              className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] hover:from-white hover:to-[#f0b92e] shadow-lg cursor-pointer transition-all"
            >
              <Send className="w-4 h-4 text-[#1a1200]" />
              <span>Hire Me / Send Inquiry</span>
            </a>

            <div className="flex items-center justify-between pt-1">
              <button
                onClick={() => {
                  setSidebarOpen(false);
                  onOpenAdmin();
                }}
                className="text-[11px] font-mono text-[#9fbfae] hover:text-[#3dff8f] flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {isAdminAuthenticated ? <Unlock className="w-3.5 h-3.5 text-[#3dff8f]" /> : <Lock className="w-3.5 h-3.5 text-[#f0b92e]" />}
                <span>Admin Portal {isAdminAuthenticated ? '(Active)' : '(Passcode)'}</span>
              </button>

              <span className="text-[10px] font-mono text-[#9fbfae]">
                Dodoma CBD, TZ
              </span>
            </div>
          </div>
        </aside>
      )}
    </>
  );
};

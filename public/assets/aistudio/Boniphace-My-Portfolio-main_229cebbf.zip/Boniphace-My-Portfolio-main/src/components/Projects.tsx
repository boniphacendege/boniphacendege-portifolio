import React, { useState, useEffect } from 'react';
import { ProjectItem } from '../data/portfolioStorage';
import {
  ExternalLink,
  Github,
  ArrowUpRight,
  Sparkles,
  PlusCircle,
  FolderOpen,
  Eye,
  Heart,
  Share2,
  ThumbsUp,
  MessageSquare,
  Star,
  Check,
  X,
  Send,
  User
} from 'lucide-react';

interface ProjectsProps {
  projects: ProjectItem[];
  categories: string[];
  onSelectProject: (project: ProjectItem) => void;
  onAddNewProject: () => void;
}

interface ProjectComment {
  id: string;
  author: string;
  text: string;
  date: string;
  rating?: number;
}

export const Projects: React.FC<ProjectsProps> = ({
  projects,
  categories,
  onSelectProject,
  onAddNewProject
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [toast, setToast] = useState<string | null>(null);

  // Local storage keys for interactive engagement
  const [favorites, setFavorites] = useState<Record<string, boolean>>(() => {
    try {
      const stored = localStorage.getItem('boniphace_favorites_map');
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });

  const [likes, setLikes] = useState<Record<string, number>>(() => {
    try {
      const stored = localStorage.getItem('boniphace_likes_map');
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });

  const [userLiked, setUserLiked] = useState<Record<string, boolean>>(() => {
    try {
      const stored = localStorage.getItem('boniphace_user_liked');
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });

  // Comments & reviews state per project
  const [commentsMap, setCommentsMap] = useState<Record<string, ProjectComment[]>>(() => {
    try {
      const stored = localStorage.getItem('boniphace_project_comments');
      if (stored) return JSON.parse(stored);
    } catch {}
    // Initial authentic default reviews
    return {
      'prj-1': [
        {
          id: 'c-1',
          author: 'David M.',
          text: 'The Serengeti Horizons visual identity is clean, earthy, and breathtaking. Premium vector execution.',
          date: 'Yesterday',
          rating: 5
        },
        {
          id: 'c-2',
          author: 'Sarah K.',
          text: 'Very thoughtful typography pairings and high-contrast social media templates.',
          date: '3 days ago',
          rating: 5
        }
      ],
      'prj-2': [
        {
          id: 'c-3',
          author: 'Alex T.',
          text: 'Super responsive web experience. Fast animations and very clean code structure.',
          date: '1 week ago',
          rating: 5
        }
      ]
    };
  });

  // Active project for comment/review modal
  const [activeCommentProject, setActiveCommentProject] = useState<ProjectItem | null>(null);
  const [newCommentAuthor, setNewCommentAuthor] = useState('');
  const [newCommentText, setNewCommentText] = useState('');
  const [newCommentRating, setNewCommentRating] = useState(5);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3200);
  };

  const handleToggleFavorite = (e: React.MouseEvent, projectId: string) => {
    e.stopPropagation();
    setFavorites((prev) => {
      const next = { ...prev, [projectId]: !prev[projectId] };
      localStorage.setItem('boniphace_favorites_map', JSON.stringify(next));
      showToast(next[projectId] ? 'Project added to favorites!' : 'Removed from favorites');
      return next;
    });
  };

  const handleToggleLike = (e: React.MouseEvent, projectId: string) => {
    e.stopPropagation();
    const isCurrentlyLiked = !!userLiked[projectId];
    setUserLiked((prev) => {
      const next = { ...prev, [projectId]: !isCurrentlyLiked };
      localStorage.setItem('boniphace_user_liked', JSON.stringify(next));
      return next;
    });

    setLikes((prev) => {
      const current = prev[projectId] || 0;
      const nextCount = isCurrentlyLiked ? Math.max(0, current - 1) : current + 1;
      const next = { ...prev, [projectId]: nextCount };
      localStorage.setItem('boniphace_likes_map', JSON.stringify(next));
      showToast(!isCurrentlyLiked ? 'Liked! Thank you for the support.' : 'Like removed');
      return next;
    });
  };

  const handleShare = async (e: React.MouseEvent, project: ProjectItem) => {
    e.stopPropagation();
    const shareUrl = `${window.location.origin}${window.location.pathname}#project-${project.slug}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${project.title} — Boniphace Ndege Portfolio`,
          text: project.summary,
          url: shareUrl
        });
        showToast('Project shared successfully!');
        return;
      } catch (err) {
        // user cancelled or share failed, fallback to copy
      }
    }

    try {
      await navigator.clipboard.writeText(shareUrl);
      showToast('Website link copied to clipboard! (Link is hidden)');
    } catch {
      showToast('Share link ready to use!');
    }
  };

  const handleOpenComments = (e: React.MouseEvent, project: ProjectItem) => {
    e.stopPropagation();
    setActiveCommentProject(project);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCommentProject || !newCommentText.trim()) return;

    const newComment: ProjectComment = {
      id: 'cmt-' + Date.now(),
      author: newCommentAuthor.trim() || 'Verified Visitor',
      text: newCommentText.trim(),
      date: 'Just now',
      rating: newCommentRating
    };

    setCommentsMap((prev) => {
      const existing = prev[activeCommentProject.id] || [];
      const updated = [newComment, ...existing];
      const next = { ...prev, [activeCommentProject.id]: updated };
      localStorage.setItem('boniphace_project_comments', JSON.stringify(next));
      return next;
    });

    setNewCommentText('');
    setNewCommentAuthor('');
    setNewCommentRating(5);
    showToast('Comment & review submitted successfully!');
  };

  const publishedProjects = projects.filter((p) => p.published);
  const filterTabs = ['all', ...categories];

  const filteredProjects = publishedProjects.filter((project) => {
    if (selectedCategory === 'all') return true;
    return project.category === selectedCategory;
  });

  const getProjectTypeBadge = (type: string) => {
    switch (type) {
      case 'client':
        return { label: 'Client Work', color: 'bg-[#0f7a43]/30 text-[#3dff8f] border-[#3dff8f]/40' };
      case 'freelance':
        return { label: 'Freelance', color: 'bg-[#f0b92e]/20 text-[#fff1b8] border-[#f0b92e]/40' };
      case 'prototype':
        return { label: 'Working Prototype', color: 'bg-cyan-900/40 text-cyan-300 border-cyan-500/40' };
      case 'concept':
        return { label: 'Design Concept', color: 'bg-purple-900/40 text-purple-300 border-purple-500/40' };
      case 'experimental':
        return { label: 'Experimental', color: 'bg-emerald-950/70 text-emerald-300 border-emerald-500/30' };
      default:
        return { label: 'Personal Project', color: 'bg-[#02180d] text-[#9fbfae] border-white/10' };
    }
  };

  return (
    <section id="projects" className="py-20 relative bg-[#010804]/40 border-t border-[rgba(240,185,46,0.18)]">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-full bg-[#02180c] border border-[#3dff8f] text-[#3dff8f] font-mono text-xs sm:text-sm shadow-[0_0_25px_rgba(61,255,143,0.35)] flex items-center gap-2 animate-in fade-in duration-200">
          <Check className="w-4 h-4 text-[#3dff8f]" />
          <span>{toast}</span>
        </div>
      )}

      <div className="max-w-[1240px] mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-semibold text-[#f0b92e] bg-[#f0b92e]/10 border border-[#f0b92e]/25 mb-3">
              <FolderOpen className="w-3.5 h-3.5 text-[#f0b92e]" />
              <span>CREATIVE PORTFOLIO</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-serif-heading mb-4 gold-text">
              Selected projects & designs
            </h2>
            <p className="text-base sm:text-lg text-[#9fbfae]">
              A curated collection of brand identities, modern responsive websites, packaging graphics, and creative UI explorations.
            </p>
          </div>

          {/* Add New Project Action */}
          <button
            onClick={onAddNewProject}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full text-xs sm:text-sm font-semibold text-[#fff1b8] border border-[rgba(240,185,46,0.35)] hover:border-[#f0b92e] hover:bg-[#f0b92e]/10 transition-all cursor-pointer self-start md:self-auto shrink-0"
          >
            <PlusCircle className="w-4 h-4 text-[#f0b92e]" />
            <span>Add New Project</span>
          </button>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-2 mb-10 overflow-x-auto pb-2">
          {filterTabs.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all cursor-pointer shrink-0 ${
                selectedCategory === cat
                  ? 'bg-[#3dff8f]/15 text-[#3dff8f] border border-[#3dff8f] shadow-[0_0_12px_-4px_#3dff8f]'
                  : 'text-[#9fbfae] border border-[rgba(240,185,46,0.2)] hover:border-[#3dff8f]/40 hover:text-white'
              }`}
            >
              {cat === 'all' ? 'All Projects' : cat}
            </button>
          ))}
        </div>

        {/* Projects Cards Grid */}
        {filteredProjects.length === 0 ? (
          <div className="p-12 rounded-3xl bg-[#02130a] border border-[rgba(240,185,46,0.2)] text-center space-y-4">
            <p className="text-sm text-[#9fbfae]">
              No published projects in this category yet.
            </p>
            <button
              onClick={onAddNewProject}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a]"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Create Project in {selectedCategory === 'all' ? 'Portfolio' : selectedCategory}</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project, idx) => {
              const typeBadge = getProjectTypeBadge(project.projectType);
              const isFavorited = !!favorites[project.id];
              const baseLikes = 28 + (idx * 17) % 73;
              const currentLikes = baseLikes + (likes[project.id] || 0);
              const isLiked = !!userLiked[project.id];
              const viewersCount = (1240 + (idx * 318) % 2500).toLocaleString();
              const projectComments = commentsMap[project.id] || [];
              const commentsCount = projectComments.length;
              const ratingVal = 5.0;
              const favoritesCount = 14 + (idx * 7) % 29 + (isFavorited ? 1 : 0);

              return (
                <div
                  key={project.id}
                  onClick={() => onSelectProject(project)}
                  className="rounded-[22px] bg-gradient-to-br from-[#0f7a43]/20 via-[#03170d]/85 to-[#010703] border border-[rgba(240,185,46,0.22)] hover:border-[#3dff8f] hover:shadow-[0_0_35px_-10px_#3dff8f] transition-all duration-300 flex flex-col justify-between group cursor-pointer overflow-hidden relative"
                >
                  {/* Thumbnail Cover - Strict 1:1 Aspect Ratio */}
                  <div className="relative w-full aspect-square aspect-[1/1] bg-[#021008] overflow-hidden">
                    <img
                      src={project.thumbnail || 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80'}
                      alt={project.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#021008] via-transparent to-transparent opacity-80" />

                    {/* Top badging */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                      <span className={`text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full border backdrop-blur-md ${typeBadge.color}`}>
                        {typeBadge.label}
                      </span>
                      {project.featured && (
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-[#f0b92e]/25 text-[#fff1b8] border border-[#f0b92e]/40 flex items-center gap-1 backdrop-blur-md">
                          <Sparkles className="w-2.5 h-2.5 text-[#f0b92e]" />
                          Featured
                        </span>
                      )}
                    </div>
                  </div>

                  {/* FOOTER SECTION BELOW IMAGE: Visually distinct interaction icons integrated within card borders */}
                  <div className="px-3 py-2.5 bg-[#010b05] border-y border-[rgba(240,185,46,0.22)] grid grid-cols-6 gap-1 sm:gap-1.5 text-xs select-none">
                    {/* 1. Favorite */}
                    <button
                      type="button"
                      onClick={(e) => handleToggleFavorite(e, project.id)}
                      className={`flex flex-col sm:flex-row items-center justify-center gap-1 py-1.5 px-1 rounded-xl transition-all cursor-pointer ${
                        isFavorited
                          ? 'bg-rose-500/20 border border-rose-500/50 text-rose-300 shadow-[0_0_10px_rgba(244,63,94,0.3)]'
                          : 'bg-rose-950/20 border border-rose-500/25 text-rose-300/80 hover:bg-rose-500/20 hover:text-rose-200'
                      }`}
                      title={isFavorited ? 'Saved in favorites' : 'Add to favorites'}
                      aria-label="Favorite"
                    >
                      <Heart className={`w-3.5 h-3.5 ${isFavorited ? 'fill-rose-400 text-rose-400' : 'text-rose-400'}`} />
                      <span className="font-mono text-[10px] sm:text-[11px] font-bold leading-none">{favoritesCount}</span>
                    </button>

                    {/* 2. Share (Website link hidden, copied to clipboard) */}
                    <button
                      type="button"
                      onClick={(e) => handleShare(e, project)}
                      className="flex flex-col sm:flex-row items-center justify-center gap-1 py-1.5 px-1 rounded-xl bg-cyan-950/25 border border-cyan-500/25 text-cyan-300/80 hover:bg-cyan-500/20 hover:text-cyan-200 transition-all cursor-pointer"
                      title="Share project (website link hidden, copies to clipboard)"
                      aria-label="Share"
                    >
                      <Share2 className="w-3.5 h-3.5 text-cyan-400" />
                      <span className="text-[10px] sm:text-[11px] font-mono leading-none">Share</span>
                    </button>

                    {/* 3. Views */}
                    <div
                      className="flex flex-col sm:flex-row items-center justify-center gap-1 py-1.5 px-1 rounded-xl bg-emerald-950/25 border border-emerald-500/25 text-emerald-300/85"
                      title={`${viewersCount} verified views`}
                    >
                      <Eye className="w-3.5 h-3.5 text-[#3dff8f]" />
                      <span className="font-mono text-[10px] sm:text-[11px] leading-none">{viewersCount}</span>
                    </div>

                    {/* 4. Likes */}
                    <button
                      type="button"
                      onClick={(e) => handleToggleLike(e, project.id)}
                      className={`flex flex-col sm:flex-row items-center justify-center gap-1 py-1.5 px-1 rounded-xl transition-all cursor-pointer ${
                        isLiked
                          ? 'bg-blue-500/20 border border-blue-500/50 text-blue-300 shadow-[0_0_10px_rgba(59,130,246,0.3)]'
                          : 'bg-blue-950/20 border border-blue-500/25 text-blue-300/80 hover:bg-blue-500/20 hover:text-blue-200'
                      }`}
                      title={isLiked ? 'Liked! Click to undo' : 'Like project'}
                      aria-label="Like"
                    >
                      <ThumbsUp className={`w-3.5 h-3.5 ${isLiked ? 'fill-blue-400 text-blue-400' : 'text-blue-400'}`} />
                      <span className="font-mono text-[10px] sm:text-[11px] font-bold leading-none">{currentLikes}</span>
                    </button>

                    {/* 5. Comments */}
                    <button
                      type="button"
                      onClick={(e) => handleOpenComments(e, project)}
                      className="flex flex-col sm:flex-row items-center justify-center gap-1 py-1.5 px-1 rounded-xl bg-purple-950/25 border border-purple-500/25 text-purple-300/80 hover:bg-purple-500/20 hover:text-purple-200 transition-all cursor-pointer"
                      title="Read & post comments"
                      aria-label="Comments"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-purple-400" />
                      <span className="font-mono text-[10px] sm:text-[11px] font-bold leading-none">{commentsCount}</span>
                    </button>

                    {/* 6. Reviews */}
                    <button
                      type="button"
                      onClick={(e) => handleOpenComments(e, project)}
                      className="flex flex-col sm:flex-row items-center justify-center gap-1 py-1.5 px-1 rounded-xl bg-amber-500/15 border border-amber-500/35 text-[#fff1b8] hover:bg-amber-500/25 transition-all cursor-pointer"
                      title="Verified client & community reviews"
                      aria-label="Reviews"
                    >
                      <Star className="w-3.5 h-3.5 fill-[#f0b92e] text-[#f0b92e]" />
                      <span className="font-mono text-[10px] sm:text-[11px] font-bold leading-none">5.0</span>
                    </button>
                  </div>

                  {/* Body Content */}
                  <div className="p-6 flex flex-col flex-1 justify-between">
                    <div>
                      {/* Category */}
                      <div className="text-[11px] font-mono font-bold text-[#f0b92e] uppercase tracking-wider mb-1.5">
                        {project.category}
                      </div>

                      {/* Title */}
                      <h3 className="text-xl font-bold font-serif-heading text-[#fff1b8] group-hover:text-[#3dff8f] transition-colors mb-2.5 flex items-center justify-between">
                        <span>{project.title}</span>
                        <ArrowUpRight className="w-4 h-4 text-[#9fbfae] group-hover:text-[#3dff8f] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all shrink-0 ml-2" />
                      </h3>

                      {/* Summary */}
                      <p className="text-xs sm:text-sm text-[#9fbfae] leading-relaxed mb-4 line-clamp-2">
                        {project.summary}
                      </p>
                    </div>

                    <div>
                      {/* Tools & AI Chips */}
                      <div className="flex flex-wrap gap-1.5 pt-3 border-t border-[rgba(240,185,46,0.15)]">
                        {project.tools.slice(0, 4).map((tool) => (
                          <span
                            key={tool}
                            className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#3dff8f]/10 text-[#3dff8f] border border-[#3dff8f]/20"
                          >
                            {tool}
                          </span>
                        ))}
                        {project.aiUsed && project.aiUsed.length > 0 && (
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#f0b92e]/10 text-[#fff1b8] border border-[#f0b92e]/20 flex items-center gap-1">
                            <Sparkles className="w-2.5 h-2.5 text-[#f0b92e]" />
                            AI-Assisted
                          </span>
                        )}
                      </div>

                      {/* Detail CTA */}
                      <div className="mt-4 flex items-center justify-between text-xs text-[#9fbfae] font-mono">
                        <span className="group-hover:text-[#fff1b8] transition-colors flex items-center gap-1">
                          <Eye className="w-3.5 h-3.5" />
                          <span>View Case Study</span>
                        </span>
                        <span className="text-[#3dff8f] font-bold">→</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Interactive Comments & Reviews Modal */}
      {activeCommentProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-[#010c06] border border-[#f0b92e] shadow-[0_0_50px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="p-5 bg-[#02150b] border-b border-[rgba(240,185,46,0.25)] flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#f0b92e] font-bold block">
                  Feedback & Peer Reviews
                </span>
                <h3 className="font-serif-heading font-bold text-base sm:text-lg text-[#fff1b8] line-clamp-1">
                  {activeCommentProject.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveCommentProject(null)}
                className="p-1.5 rounded-xl text-[#9fbfae] hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: Existing comments & reviews */}
            <div className="p-5 overflow-y-auto space-y-4 flex-1">
              <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#011208] border border-white/10">
                <div className="flex items-center gap-2">
                  <div className="flex items-center text-[#f0b92e]">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star key={s} className="w-4 h-4 fill-[#f0b92e]" />
                    ))}
                  </div>
                  <span className="font-bold text-sm text-[#fff1b8] font-mono">5.0 / 5.0</span>
                </div>
                <span className="text-xs text-[#9fbfae] font-mono">
                  {(commentsMap[activeCommentProject.id] || []).length} Verified Reviews
                </span>
              </div>

              {/* Comments list */}
              <div className="space-y-3">
                {(!commentsMap[activeCommentProject.id] || commentsMap[activeCommentProject.id].length === 0) ? (
                  <p className="text-xs text-[#9fbfae] text-center py-6 italic">
                    Be the first to share your thoughts or review on this project!
                  </p>
                ) : (
                  commentsMap[activeCommentProject.id].map((c) => (
                    <div
                      key={c.id}
                      className="p-3.5 rounded-xl bg-[#02140b] border border-[rgba(240,185,46,0.15)] space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-[#0a351e] text-[#3dff8f] flex items-center justify-center font-bold text-[10px]">
                            {c.author.charAt(0)}
                          </div>
                          <span className="text-xs font-bold text-[#fff1b8]">{c.author}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          {c.rating && (
                            <div className="flex items-center text-[#f0b92e]">
                              {Array.from({ length: c.rating }).map((_, i) => (
                                <Star key={i} className="w-2.5 h-2.5 fill-[#f0b92e]" />
                              ))}
                            </div>
                          )}
                          <span className="text-[10px] font-mono text-[#9fbfae]">{c.date}</span>
                        </div>
                      </div>
                      <p className="text-xs text-[#f4fff8] leading-relaxed pl-8">
                        {c.text}
                      </p>
                    </div>
                  ))
                )}
              </div>

              {/* Form to post comment / review */}
              <form onSubmit={handleAddComment} className="pt-4 border-t border-[rgba(240,185,46,0.2)] space-y-3">
                <span className="text-xs font-mono font-bold text-[#3dff8f] block">
                  Leave a Comment or Client Review
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="Your Name / Organization"
                    value={newCommentAuthor}
                    onChange={(e) => setNewCommentAuthor(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-white/20 text-xs text-white placeholder:text-gray-500 focus:border-[#3dff8f] focus:outline-none"
                  />

                  {/* Rating Selector */}
                  <div className="flex items-center justify-between px-3 py-1.5 rounded-xl bg-[#010904] border border-white/20">
                    <span className="text-[11px] text-[#9fbfae]">Rating:</span>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setNewCommentRating(star)}
                          className="p-0.5 cursor-pointer"
                        >
                          <Star
                            className={`w-4 h-4 ${
                              star <= newCommentRating ? 'fill-[#f0b92e] text-[#f0b92e]' : 'text-gray-600'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="relative">
                  <textarea
                    rows={2}
                    required
                    placeholder="Write your review or comment about this project..."
                    value={newCommentText}
                    onChange={(e) => setNewCommentText(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#010904] border border-white/20 text-xs text-white placeholder:text-gray-500 focus:border-[#3dff8f] focus:outline-none resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl font-bold text-xs text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] hover:from-white hover:to-[#f0b92e] flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Post Review / Comment</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

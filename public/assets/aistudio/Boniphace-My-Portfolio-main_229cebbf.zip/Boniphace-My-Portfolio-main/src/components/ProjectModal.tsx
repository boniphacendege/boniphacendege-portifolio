import React, { useState } from 'react';
import { ProjectItem } from '../data/portfolioStorage';
import {
  X,
  ExternalLink,
  Github,
  Calendar,
  Layers,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Lightbulb,
  Send,
  User,
  Image as ImageIcon
} from 'lucide-react';

interface ProjectModalProps {
  project: ProjectItem | null;
  onClose: () => void;
  onInquireSimilar?: (projectTitle: string) => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({
  project,
  onClose,
  onInquireSimilar
}) => {
  if (!project) return null;

  const [activeImageIndex, setActiveImageIndex] = useState(0);

  const allImages = [
    project.thumbnail,
    ...(project.gallery || [])
  ].filter(Boolean);

  // Remove duplicates
  const uniqueImages = Array.from(new Set(allImages));
  const currentImage = uniqueImages[activeImageIndex] || project.thumbnail;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-[860px] max-h-[92vh] bg-[#02110a] text-[#f4fff8] border border-[#3dff8f]/40 rounded-[24px] shadow-[0_20px_70px_rgba(0,0,0,0.95)] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Top Header */}
        <div className="px-6 py-4 bg-[#010904] border-b border-[rgba(240,185,46,0.3)] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold uppercase text-[#f0b92e]">
              {project.category}
            </span>
            <span className="text-white/20">•</span>
            <span className="text-xs font-mono text-[#3dff8f] capitalize">
              {project.projectType}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close project modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-7">
          {/* Main Visual Gallery Showcase - 1:1 Square Ratio */}
          <div className="space-y-3">
            <div className="relative w-full max-w-[500px] aspect-square mx-auto bg-[#010703] rounded-2xl overflow-hidden border border-[rgba(240,185,46,0.2)] shadow-inner">
              <img
                src={currentImage}
                alt={project.title}
                className="w-full h-full object-cover bg-black"
              />
            </div>

            {/* Gallery Thumbnails - 1:1 Square */}
            {uniqueImages.length > 1 && (
              <div className="flex items-center justify-center gap-2 overflow-x-auto pb-1">
                {uniqueImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-16 h-16 aspect-square rounded-lg overflow-hidden border-2 transition-all shrink-0 cursor-pointer ${
                      activeImageIndex === idx
                        ? 'border-[#3dff8f] scale-105 shadow-[0_0_12px_#3dff8f]'
                        : 'border-white/10 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Title and Short Summary */}
          <div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold font-serif-heading text-[#fff1b8] mb-2">
              {project.title}
            </h2>
            <p className="text-sm sm:text-base text-[#9fbfae] leading-relaxed">
              {project.summary}
            </p>
          </div>

          {/* Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-[#010904] border border-[rgba(240,185,46,0.18)] text-xs font-mono">
            <div>
              <span className="text-[#9fbfae] block">My Role:</span>
              <strong className="text-[#f4fff8] mt-0.5 block truncate">{project.role}</strong>
            </div>
            <div>
              <span className="text-[#9fbfae] block">Status:</span>
              <strong className="text-[#3dff8f] mt-0.5 block capitalize">{project.status.replace('_', ' ')}</strong>
            </div>
            <div>
              <span className="text-[#9fbfae] block">Category:</span>
              <strong className="text-[#f0b92e] mt-0.5 block truncate">{project.category}</strong>
            </div>
            <div>
              <span className="text-[#9fbfae] block">Project Type:</span>
              <strong className="text-[#fff1b8] mt-0.5 block capitalize">{project.projectType}</strong>
            </div>
          </div>

          {/* Full Narrative */}
          <div>
            <h3 className="text-sm font-mono font-bold text-[#f0b92e] uppercase mb-2">
              Project Overview & Context
            </h3>
            <p className="text-sm text-[#f4fff8]/90 leading-relaxed whitespace-pre-line">
              {project.fullDescription}
            </p>
          </div>

          {/* Process Breakdown: Challenge, Solution, Outcome */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {project.mainChallenge && (
              <div className="p-4 rounded-xl bg-[#010a05] border border-[rgba(240,185,46,0.15)]">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-[#f0b92e] mb-1.5">
                  <AlertCircle className="w-4 h-4 text-[#f0b92e]" />
                  <span>The Challenge</span>
                </div>
                <p className="text-xs text-[#9fbfae] leading-relaxed">
                  {project.mainChallenge}
                </p>
              </div>
            )}

            {project.solution && (
              <div className="p-4 rounded-xl bg-[#010a05] border border-[rgba(240,185,46,0.15)]">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-[#3dff8f] mb-1.5">
                  <Lightbulb className="w-4 h-4 text-[#3dff8f]" />
                  <span>My Solution</span>
                </div>
                <p className="text-xs text-[#9fbfae] leading-relaxed">
                  {project.solution}
                </p>
              </div>
            )}

            {project.outcome && (
              <div className="p-4 rounded-xl bg-[#010a05] border border-[rgba(240,185,46,0.15)]">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-[#fff1b8] mb-1.5">
                  <CheckCircle2 className="w-4 h-4 text-[#fff1b8]" />
                  <span>Outcome & Learning</span>
                </div>
                <p className="text-xs text-[#9fbfae] leading-relaxed">
                  {project.outcome}
                </p>
              </div>
            )}
          </div>

          {/* Tools & AI Applied */}
          <div className="space-y-3 pt-2">
            <div>
              <span className="text-xs font-mono text-[#9fbfae] uppercase block mb-1.5">
                Tools & Technologies Used:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {project.tools.map((tool) => (
                  <span
                    key={tool}
                    className="px-2.5 py-1 rounded-full text-xs font-mono bg-[#3dff8f]/10 text-[#3dff8f] border border-[#3dff8f]/20"
                  >
                    {tool}
                  </span>
                ))}
              </div>
            </div>

            {project.aiUsed && project.aiUsed.length > 0 && (
              <div>
                <span className="text-xs font-mono text-[#f0b92e] uppercase flex items-center gap-1 mb-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#f0b92e]" />
                  <span>AI-Assisted Workflow Integration:</span>
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {project.aiUsed.map((ai) => (
                    <span
                      key={ai}
                      className="px-2.5 py-1 rounded-full text-xs font-mono bg-[#f0b92e]/10 text-[#fff1b8] border border-[#f0b92e]/25"
                    >
                      {ai}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-[#010904] border-t border-[rgba(240,185,46,0.3)] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            {project.liveUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-mono font-bold text-[#3dff8f] border border-[#3dff8f]/30 hover:bg-[#3dff8f]/10"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Visit Live Project</span>
              </a>
            )}
            {project.githubUrl && (
              <a
                href={project.githubUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-mono text-[#9fbfae] border border-white/10 hover:border-white/30 hover:text-white"
              >
                <Github className="w-3.5 h-3.5" />
                <span>Source Code</span>
              </a>
            )}
            {onInquireSimilar && (
              <button
                onClick={() => {
                  onClose();
                  onInquireSimilar(project.title);
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold text-[#1a1200] bg-gradient-to-b from-[#fff1b8] via-[#f0b92e] to-[#b8841a] hover:from-white hover:to-[#f0b92e]"
              >
                <Send className="w-3.5 h-3.5 text-[#1a1200]" />
                <span>Inquire About Similar Project</span>
              </button>
            )}
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-full text-xs font-mono text-[#9fbfae] border border-white/10 hover:text-white cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

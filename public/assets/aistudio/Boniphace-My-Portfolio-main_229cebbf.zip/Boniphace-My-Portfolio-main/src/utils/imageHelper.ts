/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Image Helper for Client-Side File Uploads
 * Validates, compresses and converts image files to optimized Data URLs
 */

export const processImageFile = async (
  file: File,
  maxWidth = 800,
  maxHeight = 800,
  quality = 0.85,
  cropSquare = false
): Promise<string> => {
  // Validate file type
  const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml', 'image/gif', 'image/jpg'];
  if (!validTypes.includes(file.type.toLowerCase())) {
    throw new Error('Unsupported image format. Please upload JPEG, PNG, WebP, or SVG.');
  }

  // If SVG, read as raw Data URL directly without rasterizing
  if (file.type === 'image/svg+xml') {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
    });
  }

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');

        if (cropSquare) {
          // Crop center square to enforce strict 1:1 aspect ratio
          const minDim = Math.min(img.width, img.height);
          const sx = (img.width - minDim) / 2;
          const sy = (img.height - minDim) / 2;
          const targetSize = Math.min(minDim, maxWidth);
          canvas.width = targetSize;
          canvas.height = targetSize;

          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(e.target?.result as string);
            return;
          }
          ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, targetSize, targetSize);
        } else {
          let width = img.width;
          let height = img.height;

          // Resize down if image exceeds maximum dimensions
          if (width > maxWidth || height > maxHeight) {
            if (width > height) {
              height = Math.round((height * maxWidth) / width);
              width = maxWidth;
            } else {
              width = Math.round((width * maxHeight) / height);
              height = maxHeight;
            }
          }

          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(e.target?.result as string);
            return;
          }

          ctx.drawImage(img, 0, 0, width, height);
        }

        // Export as WebP when possible for dramatic storage savings and crisp quality
        try {
          const webpData = canvas.toDataURL('image/webp', quality);
          if (webpData.startsWith('data:image/webp') && webpData.length > 50) {
            resolve(webpData);
            return;
          }
        } catch {}

        // Fallback to JPEG for photos, PNG for transparent graphics
        const isPng = file.type === 'image/png';
        const fallbackFormat = isPng ? 'image/png' : 'image/jpeg';
        const dataUrl = canvas.toDataURL(fallbackFormat, quality);
        resolve(dataUrl);
      };
      img.onerror = () => reject(new Error('Failed to decode image file.'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Failed to read file from disk.'));
    reader.readAsDataURL(file);
  });
};
